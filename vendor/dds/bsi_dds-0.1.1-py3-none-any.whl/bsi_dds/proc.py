"""Optional process-level health checks for a BSI publisher host.

No relay daemon exists (point-to-point per protocol), so "process
management" is a set of checks a supervisor or operator can run to answer:
is a publisher alive, is it fast enough, and is the subscriber seeing it?
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

from .protocol import MIN_RATE_HZ, SILENCE_TIMEOUT_S


@dataclass(frozen=True)
class StreamHealth:
    """Health snapshot of an observed intent stream.

    Attributes:
        alive: a sample arrived within ``SILENCE_TIMEOUT_S``.
        rate_hz: measured publish rate (NaN before the second interval).
        seq_gaps: number of missed seq values since the first sample.
    """

    alive: bool
    rate_hz: float
    seq_gaps: int


class StreamMonitor:
    """Tracks sample arrival on one topic from the subscriber side.

    Feed every received ``CmdDiscrete`` into :meth:`observe`; read
    :meth:`health` for a liveness/rate/gap report. ``rate_hz`` uses a
    sliding window of inter-arrival intervals and is NaN until two samples
    have been seen.
    """

    _WINDOW = 20

    def __init__(self, now: Optional[float] = None) -> None:
        self._t0: Optional[float] = now
        self._last_mono: Optional[float] = None
        self._last_seq: Optional[int] = None
        self._gaps = 0
        self._intervals: list[float] = []

    def observe(
        self, sample_seq: int, now: Optional[float] = None
    ) -> None:
        """Record one arrived sample (seq from the wire, monotonic now)."""
        mono = now if now is not None else time.monotonic()
        if self._last_mono is not None:
            self._intervals.append(mono - self._last_mono)
            del self._intervals[: -self._WINDOW]
        if self._last_seq is not None:
            expected = (self._last_seq + 1) & 0xFFFFFFFF
            if sample_seq != expected:
                # u32 wrap-aware count of skipped seq values
                self._gaps += (sample_seq - expected) & 0xFFFFFFFF
        self._last_mono = mono
        self._last_seq = sample_seq

    def health(self, now: Optional[float] = None) -> StreamHealth:
        """Liveness + measured rate vs :data:`MIN_RATE_HZ` floor."""
        mono = now if now is not None else time.monotonic()
        alive = (
            self._last_mono is not None
            and mono - self._last_mono <= SILENCE_TIMEOUT_S
        )
        if self._intervals:
            mean = sum(self._intervals) / len(self._intervals)
            rate = 1.0 / mean if mean > 0 else float("nan")
        else:
            rate = float("nan")
        return StreamHealth(alive=alive, rate_hz=rate, seq_gaps=self._gaps)
