"""Protocol constants for the BSI discrete-command stream.

Single source of truth for topic name, QoS, timing and enum values.
Mirrors idl/bsi_cmd_discrete.idl and docs/protocol.md — change all three
together. Decision record: Teleopit wayfinder bsi-dds-01 (2026-08-21).
"""

from __future__ import annotations

from dataclasses import dataclass

#: DDS domain (0 = same domain as the Unitree SDK; expose to isolate later).
DEFAULT_DOMAIN_ID = 0

#: Topic name. ``bsi/`` prefix keeps BSI topics clear of Unitree SDK topics.
TOPIC_CMD_DISCRETE = "bsi/cmd_discrete"

#: Publisher must resend the current intent at this rate or faster (Hz).
MIN_RATE_HZ = 10.0

#: QoS deadline in seconds (2x the send period at MIN_RATE_HZ).
DEADLINE_S = 0.5

#: QoS liveliness lease in seconds. Automatic kind, so the middleware
#: heartbeats on the writer's behalf — catches process/network death; a
#: stalled publish loop is still caught by the app-level silence timeout.
LIVELINESS_LEASE_S = 0.5

#: Reader treats the BSI source as lost (intent -> IDLE) after this silence.
SILENCE_TIMEOUT_S = 1.0

#: Namespace used by the IDL type names (``bsi.msg.dds_.CmdDiscrete``).
IDL_NAMESPACE = "bsi.msg.dds_"

#: Enum values — zero value is IDLE so an uninitialized / unknown value is
#: fail-safe (robot does not move). Append-only; never renumber.
CMD_IDLE = 0
CMD_FORWARD = 1
CMD_TURN_LEFT = 2
CMD_TURN_RIGHT = 3

#: Confidence value to publish when the decoder has no probability output.
CONFIDENCE_UNUSED = 1.0


@dataclass(frozen=True)
class ProtocolSpec:
    """Immutable snapshot of the protocol parameters (for diagnostics)."""

    domain_id: int = DEFAULT_DOMAIN_ID
    topic: str = TOPIC_CMD_DISCRETE
    min_rate_hz: float = MIN_RATE_HZ
    deadline_s: float = DEADLINE_S
    liveliness_lease_s: float = LIVELINESS_LEASE_S
    silence_timeout_s: float = SILENCE_TIMEOUT_S


SPEC = ProtocolSpec()
