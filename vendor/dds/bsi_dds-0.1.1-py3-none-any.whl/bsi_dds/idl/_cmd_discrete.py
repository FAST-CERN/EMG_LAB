"""idlc-equivalent binding for ``bsi.msg.dds_.CmdDiscrete``.

Layout follows the unitree_sdk2py idlc v0.11 output exactly:
``@dataclass`` + ``@annotate.final`` + ``@annotate.autoid("sequential")``
on an ``IdlStruct`` whose ``typename`` matches the IDL scoped name. The
enum subclasses ``IdlEnum`` with the same values as the IDL.
"""

from dataclasses import dataclass

import cyclonedds.idl as idl
import cyclonedds.idl.annotations as annotate
import cyclonedds.idl.types as types

from ..protocol import (
    CMD_FORWARD,
    CMD_IDLE,
    CMD_TURN_LEFT,
    CMD_TURN_RIGHT,
)


@dataclass
@annotate.final
class DiscreteCommand(idl.IdlEnum, typename="bsi.msg.dds_.DiscreteCommand"):
    """Four-state intent. ``IDLE = 0`` is the fail-safe zero value."""

    IDLE = CMD_IDLE
    FORWARD = CMD_FORWARD
    TURN_LEFT = CMD_TURN_LEFT
    TURN_RIGHT = CMD_TURN_RIGHT


@dataclass
@annotate.final
@annotate.autoid("sequential")
class CmdDiscrete(
    idl.IdlStruct, typename="bsi.msg.dds_.CmdDiscrete"
):
    stamp_ns: types.int64
    seq: types.uint32
    command: DiscreteCommand
    confidence: types.float32
