"""Hand-maintained Python binding for the BSI discrete-command topic.

Equivalent to what CycloneDDS idlc (Python backend, v0.11 template — the
same generator that produced ``unitree_sdk2py.idl``) emits from
``idl/bsi_cmd_discrete.idl``. Vendored because idlc's Python backend is
unreliable on Windows hosts (silently emits nothing; crashes on enums whose
first value is 0). If you regenerate on Linux, the output must match this
file modulo comments. Keep the IDL, docs/protocol.md and this module in
sync.
"""

from ._cmd_discrete import CmdDiscrete, DiscreteCommand

__all__ = ["CmdDiscrete", "DiscreteCommand"]
