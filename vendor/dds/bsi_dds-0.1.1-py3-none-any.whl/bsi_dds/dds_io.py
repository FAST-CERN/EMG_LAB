"""DDS publisher / subscriber for the BSI discrete-command stream.

Point-to-point: the BSI host process publishes, the Teleopit sim subscribes
in-process. No relay daemon. QoS per protocol: best-effort, deadline 0.5 s,
liveliness automatic with a 0.5 s lease — a newer intent simply overwrites
an older one.
"""

from __future__ import annotations

import time
from typing import Optional, TYPE_CHECKING

# cyclonedds MUST NOT be imported at module top level here: its C layer reads
# CYCLONEDDS_URI at import time, so apply_interface() has to run first (the
# constructors do that), then we import lazily via _cyclonedds().
from ._interface_config import apply_interface
from .protocol import (
    CONFIDENCE_UNUSED,
    DEADLINE_S,
    DEFAULT_DOMAIN_ID,
    LIVELINESS_LEASE_S,
    SILENCE_TIMEOUT_S,
    TOPIC_CMD_DISCRETE,
)

if TYPE_CHECKING:  # pragma: no cover - typing only
    from cyclonedds.core import Listener
    from cyclonedds.domain import DomainParticipant

__all__ = ["DiscreteCommandPublisher", "DiscreteCommandSubscriber"]


def _cyclonedds():
    """Import cyclonedds lazily so interface pinning wins."""
    import cyclonedds.core as core
    import cyclonedds.domain as domain
    import cyclonedds.pub as pub
    import cyclonedds.qos as qos
    import cyclonedds.sub as sub
    import cyclonedds.topic as topic
    import cyclonedds.util as util

    return core, domain, pub, qos, sub, topic, util


def _idl():
    """Import the IDL binding lazily — it imports cyclonedds.idl."""
    from . import idl as _m

    return _m.CmdDiscrete, _m.DiscreteCommand


def _cmd_discrete_qos():
    """Best-effort + deadline + automatic liveliness (0.5 s lease) per protocol;
    volatile durability, like the Unitree SDK defaults (a late-joining reader
    does not replay old intents)."""
    _, _, _, qos, _, _, util = _cyclonedds()
    return qos.Qos(
        qos.Policy.Reliability.BestEffort,
        qos.Policy.Deadline(util.duration(seconds=DEADLINE_S)),
        qos.Policy.Liveliness.Automatic(
            lease_duration=util.duration(seconds=LIVELINESS_LEASE_S)
        ),
        qos.Policy.Durability.Volatile,
    )


def make_cmd_discrete_topic(
    participant: "DomainParticipant",
    domain_id: int = DEFAULT_DOMAIN_ID,
) -> "Topic":
    """Create (or find) the ``bsi/cmd_discrete`` topic on a participant."""
    _, _, _, _, _, topic, _ = _cyclonedds()
    CmdDiscrete, _ = _idl()
    return topic.Topic(participant, TOPIC_CMD_DISCRETE, CmdDiscrete)


class DiscreteCommandPublisher:
    """Publishes the current intent at a fixed rate (>= 10 Hz).

    The caller drives the loop (``publish`` once per tick); this class only
    stamps and sequences samples. ``command`` accepts a ``DiscreteCommand``
    or its int value so mock scripts can be trivially scripted.
    """

    def __init__(
        self,
        domain_id: int = DEFAULT_DOMAIN_ID,
        participant: Optional[DomainParticipant] = None,
        interface: Optional[str] = None,
    ) -> None:
        """``interface`` pins CycloneDDS to one NIC (e.g. ``"wlan0"`` on a
        multi-homed host). Must be set before cyclonedds is first imported
        in the process — these constructors handle that via lazy import;
        ignored when a participant is passed in or ``CYCLONEDDS_URI``
        is already set."""
        if participant is None:
            apply_interface(interface)
        _, domain, pub, _, _, _, _ = _cyclonedds()
        self._owns_participant = participant is None
        self.participant = participant or domain.DomainParticipant(domain_id)
        self.topic = make_cmd_discrete_topic(self.participant, domain_id)
        _, _, pub, _, _, _, _ = _cyclonedds()
        self.writer = pub.DataWriter(
            self.participant, self.topic, qos=_cmd_discrete_qos()
        )
        self._seq = 0

    def publish(
        self,
        command: "DiscreteCommand | int",
        confidence: float = CONFIDENCE_UNUSED,
    ) -> CmdDiscrete:
        """Publish one sample of the current intent; returns the sample."""
        CmdDiscrete, DiscreteCommand = _idl()
        if isinstance(command, int):
            command = DiscreteCommand(command)
        sample = CmdDiscrete(
            stamp_ns=time.monotonic_ns(),
            seq=self._seq,
            command=command,
            confidence=confidence,
        )
        self._seq = (self._seq + 1) & 0xFFFFFFFF
        self.writer.write(sample)
        return sample

    def close(self) -> None:
        # CycloneDDS 0.10.x entities free their children on GC; there is no
        # explicit participant.close(). Drop references for determinism.
        self.writer = None
        self.topic = None
        if self._owns_participant:
            self.participant = None


class DiscreteCommandSubscriber:
    """Subscribes to the intent stream and resolves the effective intent.

    Arrival order applies (no seq-based rejection). The effective intent
    falls back to ``IDLE`` after ``SILENCE_TIMEOUT_S`` without a fresh
    sample — silence means "lost link", and idle means "stop walking",
    which decays the twist to zero on the Teleopit side.
    """

    def __init__(
        self,
        domain_id: int = DEFAULT_DOMAIN_ID,
        participant: Optional[DomainParticipant] = None,
        listener: Optional[Listener] = None,
        interface: Optional[str] = None,
    ) -> None:
        """``interface``: same semantics as the publisher's."""
        if participant is None:
            apply_interface(interface)
        _, domain, _, _, sub, _, _ = _cyclonedds()
        self._owns_participant = participant is None
        self.participant = participant or domain.DomainParticipant(domain_id)
        self.topic = make_cmd_discrete_topic(self.participant, domain_id)
        self.reader = sub.DataReader(
            self.participant,
            self.topic,
            qos=_cmd_discrete_qos(),
            listener=listener,
        )
        _, DiscreteCommand = _idl()
        self._last_command: DiscreteCommand = DiscreteCommand.IDLE
        self._last_rx_mono: Optional[float] = None
        self.last_sample: Optional[CmdDiscrete] = None

    def poll(self) -> DiscreteCommand:
        """Drain newly arrived samples and return the effective intent."""
        _, DiscreteCommand = _idl()
        for sample in self.reader.take():
            try:
                self._last_command = DiscreteCommand(sample.command.value)
            except (AttributeError, ValueError):
                # Unknown enum value on the wire -> fail-safe to IDLE.
                self._last_command = DiscreteCommand.IDLE
            self._last_rx_mono = time.monotonic()
            self.last_sample = sample
        if (
            self._last_rx_mono is None
            or time.monotonic() - self._last_rx_mono > SILENCE_TIMEOUT_S
        ):
            return DiscreteCommand.IDLE
        return self._last_command

    def close(self) -> None:
        # Same as the publisher: drop references, let GC free the entities.
        self.reader = None
        self.topic = None
        if self._owns_participant:
            self.participant = None
