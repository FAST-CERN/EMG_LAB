"""CLI tools: mock publisher, subscriber echo, and link doctor.

``mock``  — publish a scripted four-state sequence at 10 Hz (acceptance
            demo source; also the reference publisher loop for the BSI
            host team).
``echo``  — subscribe and print the effective intent (with silence
            fallback) so the Teleopit side is observable without a sim.
``doctor``— pub/sub on one host, measure end-to-end rate and gaps, verify
            the stack is usable.
"""

from __future__ import annotations

import argparse
import sys
import time
from typing import Optional, Sequence

from .protocol import (
    DEFAULT_DOMAIN_ID,
    MIN_RATE_HZ,
    SILENCE_TIMEOUT_S,
    SPEC,
    TOPIC_CMD_DISCRETE,
)

# Sequence script tokens accepted by ``mock``.
_TOKENS = {
    "idle": 0,
    "forward": 1,
    "left": 2,
    "right": 3,
}


def _parse_script(script: str) -> list[tuple[int, float]]:
    """Parse ``token:seconds,token:seconds,...`` into (command, hold) pairs."""
    out: list[tuple[int, float]] = []
    for part in script.split(","):
        token, _, hold_s = part.strip().partition(":")
        token = token.strip().lower()
        if token not in _TOKENS:
            raise SystemExit(
                f"unknown script token {token!r} (expected one of "
                f"{sorted(_TOKENS)})"
            )
        hold = float(hold_s) if hold_s else 1.0
        if hold <= 0:
            raise SystemExit(f"hold time must be > 0, got {hold}")
        out.append((_TOKENS[token], hold))
    return out


def _cmd_mock(args: argparse.Namespace) -> int:
    from .dds_io import DiscreteCommandPublisher

    seq = _parse_script(args.script)
    period = 1.0 / args.rate_hz
    pub = DiscreteCommandPublisher(
        domain_id=args.domain_id, interface=args.interface
    )
    names = {0: "IDLE", 1: "FORWARD", 2: "TURN_LEFT", 3: "TURN_RIGHT"}
    print(
        f"publishing {TOPIC_CMD_DISCRETE} on domain {args.domain_id} "
        f"at {args.rate_hz:.1f} Hz; Ctrl-C to stop"
    )
    try:
        while True:
            for command, hold in seq:
                deadline = time.monotonic() + hold
                print(f"-> {names[command]} for {hold:.1f}s", flush=True)
                while time.monotonic() < deadline:
                    pub.publish(command)
                    time.sleep(period)
    except KeyboardInterrupt:
        print("\nstopped")
    finally:
        pub.close()
    return 0


def _cmd_echo(args: argparse.Namespace) -> int:
    from .dds_io import DiscreteCommandSubscriber

    sub = DiscreteCommandSubscriber(
        domain_id=args.domain_id, interface=args.interface
    )
    print(
        f"subscribing {TOPIC_CMD_DISCRETE} on domain {args.domain_id}; "
        f"silence > {SILENCE_TIMEOUT_S}s falls back to IDLE; Ctrl-C to stop"
    )
    last: Optional[int] = None
    try:
        while True:
            cmd = sub.poll()
            if cmd.value != last:
                print(f"<- {cmd.name} (effective)", flush=True)
                last = cmd.value
            time.sleep(0.05)
    except KeyboardInterrupt:
        print("\nstopped")
    finally:
        sub.close()
    return 0


def _cmd_doctor(args: argparse.Namespace) -> int:
    from .dds_io import DiscreteCommandPublisher, DiscreteCommandSubscriber
    from .proc import StreamMonitor

    period = 1.0 / MIN_RATE_HZ
    monitor = StreamMonitor()
    sub = DiscreteCommandSubscriber(
        domain_id=args.domain_id, interface=args.interface
    )
    pub = DiscreteCommandPublisher(
        domain_id=args.domain_id, interface=args.interface
    )
    print(
        f"doctor: pub+sub {TOPIC_CMD_DISCRETE} on domain {args.domain_id}, "
        f"{args.duration_s:.0f}s at {MIN_RATE_HZ:.0f} Hz"
        + (
            f", interface {args.interface}"
            if args.interface
            else ""
        )
    )
    ok = True
    try:
        deadline = time.monotonic() + args.duration_s
        last_report = time.monotonic()
        while time.monotonic() < deadline:
            sample = pub.publish(0)
            for arrived in sub.reader.take():
                monitor.observe(arrived.seq)
            now = time.monotonic()
            if now - last_report >= 1.0:
                h = monitor.health()
                print(
                    f"  alive={h.alive} rate={h.rate_hz:.1f}Hz "
                    f"gaps={h.seq_gaps}"
                )
                last_report = now
            time.sleep(period)
    finally:
        pub.close()
        sub.close()
    h = monitor.health()
    if not h.alive:
        print("FAIL: subscriber never saw the publisher (loopback broken?)")
        ok = False
    elif h.rate_hz < MIN_RATE_HZ * 0.5:
        print(
            f"WARN: measured rate {h.rate_hz:.1f} Hz well below "
            f"{MIN_RATE_HZ:.0f} Hz"
        )
    else:
        print(f"OK: stream alive at {h.rate_hz:.1f} Hz, {h.seq_gaps} gaps")
    return 0 if ok else 1


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="bsi-dds",
        description=(
            "BSI discrete-command DDS tools "
            f"(topic {TOPIC_CMD_DISCRETE}, default domain "
            f"{DEFAULT_DOMAIN_ID})"
        ),
    )
    p.add_argument(
        "--domain-id",
        type=int,
        default=DEFAULT_DOMAIN_ID,
        help=f"DDS domain id (default {DEFAULT_DOMAIN_ID})",
    )
    p.add_argument(
        "--interface",
        default=None,
        help=(
            "pin CycloneDDS to one network interface (multi-homed hosts: "
            "e.g. wlan0 on the G1 Orin); ignored if CYCLONEDDS_URI is set"
        ),
    )
    sub = p.add_subparsers(dest="command", required=True)

    def _add_interface(sp):
        # Repeat on each subcommand so both "bsi-dds --interface X doctor"
        # and "bsi-dds doctor --interface X" work; subcommand-level wins.
        sp.add_argument(
            "--interface",
            default=argparse.SUPPRESS,  # absent at subcommand level -> keep main-level value
            help=argparse.SUPPRESS,
        )

    

    pm = sub.add_parser(
        "mock", help="publish a scripted four-state sequence"
    )
    _add_interface(pm)
    pm.add_argument(
        "--script",
        default="forward:2,idle:1,left:2,idle:1,right:2,idle:1",
        help=(
            "comma list of token[:seconds]; tokens "
            "idle|forward|left|right (default walks the full cycle)"
        ),
    )
    pm.add_argument(
        "--rate-hz", type=float, default=MIN_RATE_HZ,
        help=f"publish rate (default {MIN_RATE_HZ:.0f})",
    )
    pm.set_defaults(func=_cmd_mock)

    pe = sub.add_parser(
        "echo", help="print the effective intent from the wire"
    )
    _add_interface(pe)
    pe.set_defaults(func=_cmd_echo)

    pd = sub.add_parser(
        "doctor", help="self-test: pub+sub loopback with rate/gap report"
    )
    _add_interface(pd)
    pd.add_argument(
        "--duration-s", type=float, default=5.0, help="test duration"
    )
    pd.set_defaults(func=_cmd_doctor)
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
