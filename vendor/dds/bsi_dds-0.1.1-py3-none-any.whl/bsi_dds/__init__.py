"""bsi_dds — BSI discrete-command DDS interface (host + subscriber sides).

Quick start::

    from bsi_dds import DiscreteCommandPublisher, DiscreteCommandSubscriber

    pub = DiscreteCommandPublisher()              # BSI host side
    pub.publish(1)                                # FORWARD intent, 10 Hz loop

    sub = DiscreteCommandSubscriber()             # Teleopit side
    intent = sub.poll()                           # effective intent, IDLE on silence
"""

from .protocol import (
    CMD_FORWARD,
    CMD_IDLE,
    CMD_TURN_LEFT,
    CMD_TURN_RIGHT,
    CONFIDENCE_UNUSED,
    DEADLINE_S,
    DEFAULT_DOMAIN_ID,
    IDL_NAMESPACE,
    LIVELINESS_LEASE_S,
    MIN_RATE_HZ,
    SILENCE_TIMEOUT_S,
    TOPIC_CMD_DISCRETE,
    ProtocolSpec,
    SPEC,
)

__version__ = "0.1.0"

__all__ = [
    "CMD_FORWARD",
    "CMD_IDLE",
    "CMD_TURN_LEFT",
    "CMD_TURN_RIGHT",
    "CONFIDENCE_UNUSED",
    "DEADLINE_S",
    "DEFAULT_DOMAIN_ID",
    "IDL_NAMESPACE",
    "LIVELINESS_LEASE_S",
    "MIN_RATE_HZ",
    "SILENCE_TIMEOUT_S",
    "TOPIC_CMD_DISCRETE",
    "ProtocolSpec",
    "SPEC",
    "DiscreteCommandPublisher",
    "DiscreteCommandSubscriber",
    "__version__",
]


def __getattr__(name: str):  # pragma: no cover - trivial lazy re-export
    if name in ("DiscreteCommandPublisher", "DiscreteCommandSubscriber"):
        from . import dds_io

        return getattr(dds_io, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
