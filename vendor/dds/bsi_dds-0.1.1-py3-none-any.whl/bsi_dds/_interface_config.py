"""Process-level CycloneDDS network-interface pinning.

Multi-homed hosts (e.g. the G1 Orin: unitree-internal eth0 + WiFi wlan0 +
docker0 + rndis) make CycloneDDS auto-pick a "preferred" interface that may
not carry the BSI traffic — the SPDP discovery multicast then joins the
wrong NIC and peers never see each other. Pinning the interface fixes it.

Mechanism: ``CYCLONEDDS_URI`` is read once by CycloneDDS when the process
creates its first domain participant. We therefore set it — inline XML, no
temp file — strictly before that point, and only when the user did not
bring their own configuration.
"""

from __future__ import annotations

import os
from typing import Optional
from xml.sax.saxutils import quoteattr

__all__ = ["apply_interface"]

#: Env var CycloneDDS reads for its XML configuration.
_URI_ENV = "CYCLONEDDS_URI"

#: Set-once guard: after the first participant exists, changing the env var
#: has no effect, so a second ``apply_interface`` call must be a no-op.
_applied: Optional[str] = None


def apply_interface(interface: Optional[str]) -> bool:
    """Pin CycloneDDS to ``interface`` via ``CYCLONEDDS_URI``.

    Call before creating any ``DomainParticipant`` (the Publisher /
    Subscriber constructors do this for you). Returns True when this call
    wrote the configuration. An explicit ``interface`` is user intent and
    **overrides** an ambient ``CYCLONEDDS_URI`` (e.g. the unitree/ROS
    ``.bashrc`` export pinned to eth0 — verified live on a G1 Orin where
    the ambient config silently defeated the parameter). No-op (returns
    False) when ``interface`` is None, or when an interface was already
    pinned earlier in the process (the first participant has locked the
    config).
    """
    global _applied
    if interface is None:
        return False
    if _applied is not None:
        return False
    name = quoteattr(interface)
    os.environ[_URI_ENV] = (
        '<CycloneDDS xmlns="https://cdds.io/config">'
        "<Domain><General><Interfaces>"
        f"<NetworkInterface name={name}/>"
        "</Interfaces></General></Domain></CycloneDDS>"
    )
    _applied = interface
    return True


def _reset_for_tests() -> None:
    """Reset the once-guard so tests exercise the decision logic."""
    global _applied
    _applied = None
