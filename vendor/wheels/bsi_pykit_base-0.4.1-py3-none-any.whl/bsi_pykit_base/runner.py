"""TaskRunner:后台 asyncio 循环线程,提供"同步式写异步非阻塞"的统一机制。

任何耗时/阻塞的异步任务,都交给 TaskRunner 在后台循环线程执行:

    runner = TaskRunner()
    result = await runner.run(coro)          # qasync 主线程:await,不阻塞
    result = runner.run_sync(coro, 10.0)     # worker 线程:阻塞直到结果
    runner.submit(coro)                       # fire-and-forget:不等待
    runner.call_soon_threadsafe(callback)     # 从任意线程往后台循环塞一个回调

线程模型:
    后台一条 asyncio 循环线程,负责真正执行协程;
    调用方(main thread / worker thread)通过桥接与它通信。
    run() 的 await 不阻塞当前线程;run_sync() 会阻塞调用线程(只许 worker 线程用)。
"""

from __future__ import annotations

import asyncio
import logging
import threading
from typing import Any, Callable, Coroutine, Optional

logger = logging.getLogger(__name__)


class TaskRunner:
    """后台 asyncio 循环线程,提供"同步式写异步非阻塞"的统一机制。

    任何耗时/阻塞的异步任务都交给它在后台循环线程执行,绝不阻塞主线程。

    用法:
        runner = TaskRunner()
        result = await runner.run(coro)          # qasync 主线程:await,不阻塞
        result = runner.run_sync(coro, 10.0)     # worker 线程:阻塞直到结果
        runner.submit(coro)                       # fire-and-forget:不等待
        runner.call_soon_threadsafe(cb)           # 往后台循环塞一个小回调

    约定:
        - 每个模块各自一个 TaskRunner,不共享循环线程(隔离优先);
        - 循环只跑 async I/O 任务;阻塞/CPU 函数用 asyncio.to_thread,别塞进循环。

    Args:
        loop_name: 后台线程名(调试用,如 "BLELoop")。
    """

    def __init__(self, loop_name: str = "AsyncLoop") -> None:
        self._loop_name = loop_name
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

    # -------------------- 后台循环线程 --------------------
    def start(self) -> None:
        """启动后台 asyncio 循环线程(幂等,可重复调用)。

        一般不需要手动调用——run/run_sync/submit 内部会自动 start。
        进程退出时 daemon 线程自动回收。
        """
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._loop = asyncio.new_event_loop()
            self._thread = threading.Thread(
                target=self._run_loop, args=(self._loop,), name=self._loop_name, daemon=True
            )
            self._thread.start()

    def _run_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        asyncio.set_event_loop(loop)
        try:
            loop.run_forever()
        finally:
            loop.close()

    @property
    def is_alive(self) -> bool:
        """后台线程是否已启动且存活。"""
        return bool(self._thread is not None and self._thread.is_alive())

    @property
    def loop(self) -> Optional[asyncio.AbstractEventLoop]:
        """后台事件循环（未启动时为 None）。

        供同包内部模块（如 :class:`~bsi_pykit_base.communication.ble.BLEManager`
        的 notify 热路径）直接使用；外部调用方请走 run/run_sync/submit 桥接，
        不要依赖此属性。
        """
        return self._loop

    def stop(self) -> None:
        """停止后台循环(仅供测试/退出清理;进程退出时 daemon 线程自动回收)。"""
        with self._lock:
            loop, thread = self._loop, self._thread
            self._loop, self._thread = None, None
        if loop is None or thread is None:
            return
        try:
            loop.call_soon_threadsafe(loop.stop)
        except Exception:  # noqa: BLE001
            pass
        thread.join(timeout=3)

    # -------------------- 桥接 --------------------
    async def run(self, coro: Coroutine[Any, Any, Any]) -> Any:
        """async 版桥接:在后台循环执行 coro,当前线程 await 结果,不阻塞。

        Args:
            coro: 要在后台循环执行的协程(由调用方创建,如 `runner.run(some_coro())`)。

        Returns:
            协程的返回值。

        Note:
            - 协程在后台循环线程执行,不在当前线程;
            - await 挂起当前协程,不阻塞当前线程(适合 qasync 主线程)。
        """
        self.start()
        if self._loop is None:
            raise RuntimeError("async loop not started")
        logger.debug("[%s] run: schedule coro -> background loop (thread=%s), awaiting...",
                     threading.current_thread().name, self._thread.name if self._thread else "?")
        fut = asyncio.run_coroutine_threadsafe(coro, self._loop)
        result = await asyncio.wrap_future(fut)
        logger.debug("[%s] run: got result", threading.current_thread().name)
        return result

    def run_sync(self, coro: Coroutine[Any, Any, Any], timeout: float) -> Any:
        """同步版桥接:阻塞当前(worker)线程直到结果。请勿在 Qt 主线程调用。

        Args:
            coro: 要在后台循环执行的协程。
            timeout: 等待结果的超时(秒)。

        Returns:
            协程的返回值。

        Raises:
            asyncio.TimeoutError: 超时。此时后台任务会被取消(避免残留孤儿任务)。
        """
        self.start()
        if self._loop is None:
            raise RuntimeError("async loop not started")
        fut = asyncio.run_coroutine_threadsafe(coro, self._loop)
        try:
            return fut.result(timeout)
        except asyncio.TimeoutError:
            fut.cancel()   # 取消后台任务,清理干净
            raise

    def submit(self, coro: Coroutine[Any, Any, Any],
               on_done: Optional[Callable[[Any, Optional[BaseException]], None]] = None,
               timeout: Optional[float] = None):
        """fire-and-forget:把协程排到后台循环执行,可挂完成回调与总超时。

        任意线程可调(包括没有事件循环的 UI 主线程)——这是"无循环线程发起
        后台任务"的口,区别于 run(需调用方 await)与 run_sync(阻塞调用线程)。

        Args:
            coro: 要在后台循环执行的协程。
            on_done: 完成回调 ``on_done(result, exception)``——成功时
                exception=None;失败/超时 result=None。回调在**后台循环线程**
                触发,须快且不抛(回调内异常已隔离记日志);UI 消费须自行经
                Qt Signal 封送回主线程。
            timeout: 总超时(秒),None=不限(协程须自带内部超时)。超时会
                **真正取消**后台协程(wait_for 语义),exception 为
                asyncio.TimeoutError。

        Returns:
            concurrent.futures.Future —— 可忽略;想取消/查结果就留着它。

        Note:
            不挂 on_done 时,协程内部抛的异常默认不会出现在调用方(除非你
            等 Future 的 result())。
        """
        self.start()
        if self._loop is None:
            raise RuntimeError("async loop not started")
        if on_done is None and timeout is None:
            return asyncio.run_coroutine_threadsafe(coro, self._loop)

        async def _wrap() -> Any:
            return await coro if timeout is None else await asyncio.wait_for(coro, timeout)

        fut = asyncio.run_coroutine_threadsafe(_wrap(), self._loop)

        def _cb(f) -> None:
            ex = f.exception()
            try:
                on_done(None if ex else f.result(), ex)
            except Exception:
                logger.exception("submit 回调异常(已隔离)")

        fut.add_done_callback(_cb)
        return fut

    def call_soon_threadsafe(self, callback: Callable[..., None], *args: Any) -> None:
        """从任意线程往后台循环塞一个普通函数回调(在后台循环线程执行),不等待。

        Args:
            callback: 要执行的普通函数(不是协程)。必须是"快、不阻塞"的小动作
                      (设标志/置事件等);慢函数会卡住后台循环,请用 asyncio.to_thread。
            *args: 传给 callback 的位置参数(如 ``call_soon_threadsafe(q.put_nowait, data)``)。
        """
        self.start()
        if self._loop is None:
            raise RuntimeError("async loop not started")
        self._loop.call_soon_threadsafe(callback, *args)
