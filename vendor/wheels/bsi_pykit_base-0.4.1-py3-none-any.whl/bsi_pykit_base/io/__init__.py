"""通用 IO 工具（队列式文件写入器等）。"""

from .queue_file_writer import QueueFileWriter

__all__ = ["QueueFileWriter"]
