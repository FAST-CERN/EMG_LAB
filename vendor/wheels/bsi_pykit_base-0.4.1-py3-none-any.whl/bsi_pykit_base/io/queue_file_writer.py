"""QueueFileWriter:队列驱动的专职写线程文件写入器。

生产者（任意线程，含 UI 主线程）只调 ``put_row()`` 把一行文本入队
（微秒级，绝不阻塞调用线程）；专职 daemon 线程批量取出、拼接、写入。
``stop()`` 返回时保证队列中数据**全部落盘**并关闭文件。

相对"逐行 write + 0.1s 轮询超时"写法（各记录器的老模式）的优化：
- 批量 drain：每次唤醒把队列积压一次取尽、拼成单个字符串写一次，
  1kHz 级生产速率下系统调用次数降低一个量级；
- 停止语义干净：stop() 发哨兵唤醒 → join → flush + close，
  返回即完整（无轮询窗口、无双重停止机制）；
- 写线程内异常记日志不吞、不中断线程；
- 每轮 drain 后 flush，掉电丢数据窗口最小（一轮 drain 的间隔）。
"""

from __future__ import annotations

import logging
import queue
import threading
from pathlib import Path
from typing import IO, Union

logger = logging.getLogger(__name__)

_STOP = object()   # 停止哨兵（object() 不与任何合法行内容混淆）


class QueueFileWriter:
    """队列式文件写入器：调用线程只入队，专职线程批量落盘。

    用法::

        w = QueueFileWriter("data.csv", header="timestamp,value")
        w.start()
        for row in rows:            # 任意线程，微秒级
            w.put_row(f"{t},{v}")
        w.stop()                    # 返回时数据已全部落盘

    线程模型：
        - ``start`` 在控制线程（如记录器 start/stop）调用：打开文件、写表头
          （本地文件 open 为毫秒级操作，与各记录器现状一致），再启动写线程；
        - ``put_row`` 任意线程（含设备回调线程、UI 主线程）调用，不阻塞；
        - 行写入/flush/关闭全部发生在专职 daemon 线程。

    Args:
        path: 目标文件路径（父目录须已存在；以 ``w`` 模式新建文件）。
        header: 可选表头行（不含换行符，start 时最先写入）。
        encoding: 文件编码，默认 utf-8。
        thread_name: 写线程名（日志排查用）。

    Note:
        - ``start()`` 打开文件失败抛 :class:`OSError`（调用方决定如何上报）；
        - 未 start / 已 stop 时 ``put_row`` 静默丢弃并警告一次（数据回调线程不允许抛）；
        - ``start/stop`` 均可重复调用（幂等）；
        - 行内容不含换行符，写入时自动补 ``\\n``。
    """

    def __init__(self, path: Union[str, Path], header: str | None = None,
                 encoding: str = "utf-8", thread_name: str = "QueueFileWriter") -> None:
        self._path = Path(path)
        self._header = header
        self._encoding = encoding
        self._thread_name = thread_name
        self._queue: queue.Queue = queue.Queue()
        self._thread: threading.Thread | None = None
        self._file: IO | None = None
        self._running = False
        self._put_warned = False
        self.rows_written = 0          # 已落盘行数（stop 后可读，做日志）
        self.failure: str | None = None
        self.rows_submitted = 0
        self.rows_failed = 0
        self._state_lock = threading.Lock()
        self._lifecycle_lock = threading.Lock()

    # -------------------- 生命周期 --------------------

    def start(self) -> None:
        """打开文件（写表头）并启动写线程（幂等）。

        Raises:
            OSError: 文件打不开（路径非法/无权限/父目录不存在）。
        """
        with self._lifecycle_lock:
            if self._running:
                return
            self._file = open(self._path, "w", encoding=self._encoding, newline="\n")
            try:
                if self._header:
                    self._file.write(self._header + "\n")
            except OSError:
                self._file.close()
                self._file = None
                raise
            self.rows_written = self.rows_submitted = self.rows_failed = 0
            self.failure = None
            self._put_warned = False
            self._running = True
            self._thread = threading.Thread(
                target=self._write_loop, name=self._thread_name, daemon=True)
            self._thread.start()

    def stop(self) -> bool:
        """停止写线程：排空队列、flush、关闭文件（幂等）。

        返回 True 表示已入队数据全部成功写入并关闭；失败原因在 failure。
        多个停止调用等待同一写线程完成，不提前报告成功。
        """
        with self._lifecycle_lock:
            if self._running:
                with self._state_lock:
                    self._running = False
                    self._queue.put(_STOP)
            if self._thread is not None:
                self._thread.join()
                self._thread = None
            return self.failure is None and self.rows_written == self.rows_submitted

    # -------------------- 生产接口 --------------------

    def put_row(self, row: str) -> None:
        """入队一行文本（不含换行符；任意线程调用，不阻塞）。

        未 start / 已 stop 时静默丢弃（设备回调线程不允许抛异常）。
        """
        with self._state_lock:
            if not self._running:
                if not self._put_warned:
                    self._put_warned = True
                    logger.warning("QueueFileWriter 未运行，数据被丢弃: %s", self._path)
                return
            self.rows_submitted += 1
            self._queue.put(row)

    # -------------------- 写线程 --------------------

    def _write_loop(self) -> None:
        """专职写线程主循环：阻塞等首行 → 批量 drain → 哨兵后收尾。

        哨兵在 drain 中途出现时，先把已取出的批次写完再退出（停止不丢数据）。
        """
        assert self._file is not None
        while True:
            item = self._queue.get()
            if item is _STOP:
                break
            batch = [item]
            stopped = False
            # 批量 drain：把当前积压一次取尽，攒成一批
            while True:
                try:
                    item = self._queue.get_nowait()
                except queue.Empty:
                    break
                if item is _STOP:
                    stopped = True
                    break
                batch.append(item)
            self._flush_batch(batch)
            if stopped:
                break
        self._close_file()

    def _flush_batch(self, batch: list[str]) -> None:
        """把一批行拼接为单个字符串写入并 flush；失败丢弃本批（记日志）。"""
        if not batch or self._file is None:
            return
        try:
            self._file.write("\n".join(batch) + "\n")
            self._file.flush()
            self.rows_written += len(batch)
        except OSError as ex:
            self.failure = str(ex)
            self.rows_failed += len(batch)
            logger.error("QueueFileWriter 写入失败 %s: %s（本批 %d 行丢弃）",
                         self._path, ex, len(batch))

    def _close_file(self) -> None:
        """关闭文件（写线程收尾时调用）。"""
        if self._file is None:
            return
        try:
            self._file.flush()
            self._file.close()
        except OSError as ex:
            self.failure = str(ex)
            logger.error("QueueFileWriter 关闭文件失败 %s: %s", self._path, ex)
        finally:
            self._file = None
        logger.info("QueueFileWriter 完成 %s: 共 %d 行", self._path, self.rows_written)
