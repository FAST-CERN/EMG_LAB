"""通用硬件接口抽象（IHardware）。"""

from .i_hardware import IHardware

__all__ = ["IHardware"]
