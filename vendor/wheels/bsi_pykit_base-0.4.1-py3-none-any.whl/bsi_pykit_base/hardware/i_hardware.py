"""
    Description: interface definition for hardware
    Version: v1.0
    Author: yinyue
    Date: 20251027
"""
from abc import abstractmethod, ABC

'''
    interface of hardware
'''
class IHardware(ABC):
    '''
        Description: initial function
        Args: 
            name: unique name of this hardware
            address: the communication address of this hardware
        Returns: None
    '''
    def __init__(self, name: str, address: str, **args) -> None:
        self.name: str = name
        self.address: str = address
        self.connected: bool = False

    '''
        Description: connect hardware
        Args: None
        Returns: None
    '''
    @abstractmethod
    def connect(self) -> bool:
        pass

    '''
        Description: disconnect hardware
        Args: None
        Returns: None
    '''
    @abstractmethod
    def disconnect(self) -> bool:
        pass

    '''
        Description: configure the hardware
        Args:
            config: configurations of hardware
        Returns: None
    '''
    @abstractmethod
    def configure(self, **config) -> bool:
        pass

    '''
        Description: start the hardware function
        Args:
            args: some variables to support this operation
        Returns: None
    '''
    @abstractmethod
    def start(self, **args) -> bool:
        pass

    '''
        Description: stop the hardware function
        Args:
            args: some variables to support this operation
        Returns: None
    '''
    @abstractmethod
    def stop(self, **args) -> bool:
        pass
