"""通用事件总线（EventBus + BusData），自宿主项目复制而来。

EventBus 是对 pypubsub 的封装（进程级全局单例），跨模块/线程按主题字符串收发消息。
"""

from .bus_data import BusData
from .event_bus import EventBus

__all__ = ["EventBus", "BusData"]
