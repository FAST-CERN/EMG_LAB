"""
    Description: Definition for EventBus
    Version: v1.0
    Author: yinyue
    Date: 20251020
"""
from typing import Any, Callable
from pubsub import pub

'''
    Event bus for message sending/recieving among threads
'''
class EventBus(object):
    '''
        Description: publish a topic
        Args: 
            topic: name of message topic
            data: data to be deliverd in a message
        Returns: None
    '''
    @staticmethod
    def publish(topic: str, **data: Any) -> None:
        pub.sendMessage(topic, **data)

    '''
        Description: subscribe a listener to one topic
                     once the topic sigal received, the listener would be called
        Args: 
            topic: name of message topic
            listener: a callback function
        Returns: 
            success: if the subscribing is successful
    '''
    @staticmethod
    def subscribe(topic: str, listener: Callable[..., None]) -> bool:
        _, success = pub.subscribe(listener, topic)
        return success

    ''' 
        Description: delete a listener from one topic
        Args: 
            topic: name of message topic
            listener: a specific callable function subscribed to this topic
        Returns: 
    '''
    @staticmethod
    def unsubscribe(topic: str, listener: Callable[..., None]) -> None:
        pub.unsubscribe(listener, topic)

    '''
        Description: delete all listeners from one topic
        Args: 
            topic: name of message topic
        Returns: None
    '''
    @staticmethod
    def unsubscribe_all(topic: str) -> None:
        pub.getDefaultTopicMgr().getTopic(topic).unsubscribeAllListeners()

    '''
        Description: if the topic has listeners
        Args: 
            topic: name of message topic
        Returns: if this tpoic has listeners
    '''
    @staticmethod
    def has_listeners(topic: str) -> bool:
        return pub.getDefaultTopicMgr().getTopic(topic).hasListeners()

    '''
        Description:  delete the topic
        Args: 
            topic: name of message topic
        Returns: if the deletion is successful
    '''
    @staticmethod
    def delete_topic(topic: str) -> bool:
        return pub.getDefaultTopicMgr().delTopic(topic)