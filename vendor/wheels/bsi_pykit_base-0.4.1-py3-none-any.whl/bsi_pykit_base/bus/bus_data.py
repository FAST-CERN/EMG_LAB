"""
    Description: Definition for BusData
    Version: v1.0
    Author: yinyue
    Date: 20251020
"""
from datetime import datetime
import time
from dataclasses import dataclass
from typing import Any

'''
    data with time stamp in bus
'''
@dataclass
class BusData:
    timestamp: str
    data: Any

    '''
        Description: initial function
        Args:
            timestamp: input customized time stamp
            data: input customized data
        Returns: None
    '''
    def __init__(self, timestamp:str=None, data:Any=None) -> None:
        self.timestamp = timestamp if timestamp else datetime.now().strftime('%Y.%m.%d %H.%M.%S.%f')
        if data:
            self.data = data

    '''
        Description: for bus data copying
        Args: None
        Returns: 
            BusData with new copy
    '''
    def copy(self):
        return BusData(timestamp=self.timestamp, data=self.data)