from __future__ import annotations

import logging
import os
import sys
import threading
from logging.handlers import RotatingFileHandler
from pathlib import Path
from types import TracebackType
from typing import Any


DEBUG = logging.DEBUG
INFO = logging.INFO
WARNING = logging.WARNING
ERROR = logging.ERROR

_logger_name = "bci_logger"
_configured = False
_config_lock = threading.RLock()
_default_format = (
    "%(asctime)s.%(msecs)03d %(process)d/%(thread)d "
    "[%(name)s][%(filename)s:%(lineno)s %(funcName)s()][%(levelname)s] %(message)s"
)
_default_date_format = "%Y-%m-%d %H:%M:%S"


def _build_formatter(use_format: bool = True) -> logging.Formatter | None:
    if not use_format:
        return None
    return logging.Formatter(fmt=_default_format, datefmt=_default_date_format)


def _close_handlers(target: logging.Logger) -> None:
    for handler in list(target.handlers):
        target.removeHandler(handler)
        try:
            handler.close()
        except Exception:
            pass


def get_logger(name: str | None = None) -> logging.Logger:
    log_name = name or _logger_name
    log = logging.getLogger(log_name)
    if not log.handlers and log_name == _logger_name:
        log.addHandler(logging.NullHandler())
    return log


def configure_logging(
    log_dir: str | os.PathLike[str] = "logs",
    *,
    filename: str = "bci_runtime.log",
    level: int = INFO,
    console: bool = False,
    max_bytes: int = 10 * 1024 * 1024,
    backup_count: int = 10,
    force: bool = False,
) -> Path:
    """Configure process-wide application logging.

    This function is idempotent by default. Use ``force=True`` in tests or when
    intentionally moving log output to a new directory.
    """
    global _configured
    with _config_lock:
        root_logger = logging.getLogger()
        if _configured and not force:
            for handler in root_logger.handlers:
                if isinstance(handler, RotatingFileHandler):
                    return Path(handler.baseFilename)
            return Path(log_dir) / filename

        log_path = Path(log_dir)
        log_path.mkdir(parents=True, exist_ok=True)
        runtime_log = log_path / filename

        _close_handlers(root_logger)
        root_logger.setLevel(level)

        formatter = _build_formatter(True)
        file_handler = RotatingFileHandler(
            runtime_log,
            mode="a",
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding="utf-8",
        )
        file_handler.setLevel(level)
        if formatter:
            file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

        if console:
            console_handler = logging.StreamHandler()
            console_handler.setLevel(level)
            if formatter:
                console_handler.setFormatter(formatter)
            root_logger.addHandler(console_handler)

        legacy_logger = logging.getLogger(_logger_name)
        legacy_logger.setLevel(level)
        legacy_logger.propagate = True
        for handler in list(legacy_logger.handlers):
            if isinstance(handler, logging.NullHandler):
                legacy_logger.removeHandler(handler)

        _configured = True
        return runtime_log


def config(
    filename: str = "log.txt",
    logger_name: str = _logger_name,
    level: int = WARNING,
    format: bool = True,
    console: bool = False,
) -> logging.Logger:
    """Legacy explicit logger factory.

    Existing modules may still call this function. It no longer runs at import
    time, and it replaces handlers for the requested logger to avoid duplicate
    lines after repeated configuration.
    """
    log = logging.getLogger(logger_name)
    log.setLevel(level)
    log.propagate = False
    _close_handlers(log)

    formatter = _build_formatter(format)
    os.makedirs(os.path.dirname(os.path.abspath(filename)), exist_ok=True)
    file_handler = logging.FileHandler(filename=filename, mode="a", encoding="utf-8")
    file_handler.setLevel(level)
    if formatter:
        file_handler.setFormatter(formatter)
    log.addHandler(file_handler)

    if console:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(level)
        if formatter:
            console_handler.setFormatter(formatter)
        log.addHandler(console_handler)
    return log


logger: logging.Logger = get_logger(_logger_name)


def install_global_exception_hooks() -> None:
    def _log_exception(
        exc_type: type[BaseException],
        exc_value: BaseException,
        exc_traceback: TracebackType | None,
    ) -> None:
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        logging.getLogger(_logger_name).critical(
            "Unhandled exception",
            exc_info=(exc_type, exc_value, exc_traceback),
        )

    sys.excepthook = _log_exception

    if hasattr(threading, "excepthook"):
        def _thread_exception(args: threading.ExceptHookArgs) -> None:
            logging.getLogger(_logger_name).critical(
                "Unhandled thread exception: %s",
                getattr(args.thread, "name", "unknown"),
                exc_info=(args.exc_type, args.exc_value, args.exc_traceback),
            )

        threading.excepthook = _thread_exception

    try:
        from PySide6.QtCore import QtMsgType, qInstallMessageHandler
    except Exception:
        return

    def _qt_message_handler(mode: Any, context: Any, message: str) -> None:
        qt_logger = logging.getLogger("qt")
        context_text = ""
        file_name = getattr(context, "file", None)
        line_no = getattr(context, "line", None)
        if file_name:
            context_text = f" ({file_name}:{line_no})"

        if mode == QtMsgType.QtDebugMsg:
            qt_logger.debug("%s%s", message, context_text)
        elif mode == QtMsgType.QtInfoMsg:
            qt_logger.info("%s%s", message, context_text)
        elif mode == QtMsgType.QtWarningMsg:
            qt_logger.warning("%s%s", message, context_text)
        elif mode == QtMsgType.QtCriticalMsg:
            qt_logger.error("%s%s", message, context_text)
        elif mode == QtMsgType.QtFatalMsg:
            qt_logger.critical("%s%s", message, context_text)
        else:
            qt_logger.info("%s%s", message, context_text)

    qInstallMessageHandler(_qt_message_handler)


class TimeLogger:
    _logger: logging.Logger | None = None
    _logger_name = "timestamp"
    _fileHandler: logging.Handler | None = None
    _consoleHandler: logging.Handler | None = None
    _mutex = threading.RLock()

    @staticmethod
    def config(
        filename: str = "timestamp.txt",
        level: int = DEBUG,
        format: bool = False,
        console: bool = False,
    ) -> None:
        with TimeLogger._mutex:
            if not TimeLogger._logger:
                TimeLogger._logger = logging.getLogger(TimeLogger._logger_name)
            TimeLogger._logger.setLevel(level)
            TimeLogger._logger.propagate = False

            formatter = _build_formatter(format)
            if TimeLogger._fileHandler:
                TimeLogger._logger.removeHandler(TimeLogger._fileHandler)
                TimeLogger._fileHandler.close()

            Path(filename).parent.mkdir(parents=True, exist_ok=True)
            TimeLogger._fileHandler = logging.FileHandler(
                filename=filename,
                mode="a",
                encoding="utf-8",
            )
            TimeLogger._fileHandler.setLevel(level)
            if formatter:
                TimeLogger._fileHandler.setFormatter(formatter)
            TimeLogger._logger.addHandler(TimeLogger._fileHandler)

            if console:
                if TimeLogger._consoleHandler:
                    TimeLogger._logger.removeHandler(TimeLogger._consoleHandler)
                    TimeLogger._consoleHandler.close()
                TimeLogger._consoleHandler = logging.StreamHandler()
                TimeLogger._consoleHandler.setLevel(level)
                if formatter:
                    TimeLogger._consoleHandler.setFormatter(formatter)
                TimeLogger._logger.addHandler(TimeLogger._consoleHandler)

    @staticmethod
    def get_logger() -> logging.Logger:
        if TimeLogger._logger is None:
            raise RuntimeError("TimeLogger is not configured")
        return TimeLogger._logger

    @staticmethod
    def clear_logger() -> None:
        with TimeLogger._mutex:
            if TimeLogger._logger is None:
                return
            if TimeLogger._fileHandler:
                TimeLogger._logger.removeHandler(TimeLogger._fileHandler)
                TimeLogger._fileHandler.close()
                TimeLogger._fileHandler = None
            if TimeLogger._consoleHandler:
                TimeLogger._logger.removeHandler(TimeLogger._consoleHandler)
                TimeLogger._consoleHandler.close()
                TimeLogger._consoleHandler = None
            TimeLogger._logger = None

    @staticmethod
    def write(msg: str, *args: Any, **kwargs: Any) -> None:
        with TimeLogger._mutex:
            if TimeLogger._logger is not None:
                TimeLogger._logger.info(msg, *args, **kwargs)


if __name__ == "__main__":
    configure_logging(console=True, level=DEBUG, force=True)
    logger.error("test 1 %d %.2f", 1, 0.123)
    logger.info("test 2 %d %.2f", 2, 4.567)
    logger.warning("test 3 %d %.2f", 3, 8.901)
