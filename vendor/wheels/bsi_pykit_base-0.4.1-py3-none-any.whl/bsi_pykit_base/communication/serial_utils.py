import serial
import serial.tools.list_ports
from typing import List, Optional
from ..logger import logger

class SerialPort:
    """
    基于 pyserial 的串口通信封装类
    """
    def __init__(self):
        self._serial: Optional[serial.Serial] = None

    @staticmethod
    def get_available_ports() -> List[str]:
        """
        获取当前可用串口列表
        :return: 串口名称列表，如 ['COM1', 'COM2']
        """
        ports = serial.tools.list_ports.comports()
        return [port.device for port in ports]

    def open(self, port: str, baudrate: int = 115200, timeout: float = 0.5, **kwargs) -> bool:
        """
        打开串口
        :param port: 端口号 (e.g. "COM3")
        :param baudrate: 波特率
        :param timeout: 读取超时时间(秒)
        :param kwargs: 其他 serial.Serial 参数
        :return: 是否成功打开
        """
        try:
            if self.is_open:
                self.close()

            self._serial = serial.Serial(
                port=port, 
                baudrate=baudrate, 
                timeout=timeout, 
                **kwargs
            )
            logger.info(f"Serial port {port} opened successfully at {baudrate}.")
            return True
        except serial.SerialException as e:
            logger.error(f"Failed to open serial port {port}: {e}")
            self._serial = None
            return False

    def close(self) -> None:
        """关闭串口"""
        if self.is_open:
            try:
                self._serial.close()
                logger.info("Serial port closed.")
            except Exception as e:
                logger.error(f"Error closing serial port: {e}")
            finally:
                self._serial = None

    def send(self, data: bytes) -> int:
        """
        发送二进制数据
        :param data: bytes 数据
        :return: 发送的字节数
        """
        if not self.is_open:
            logger.warning("Serial port is not open. Cannot send data.")
            return 0
        
        try:
            return self._serial.write(data)
        except Exception as e:
            logger.error(f"Serial send error: {e}")
            return 0

    def read(self, size: int) -> bytes:
        """
        读取指定长度的数据
        :param size: 字节数
        :return: 读取到的 bytes
        """
        if not self.is_open:
            return b''
        try:
            return self._serial.read(size)
        except Exception as e:
            logger.error(f"Serial read error: {e}")
            return b''

    def read_all(self) -> bytes:
        """读取缓冲区中的所有数据"""
        if not self.is_open:
            return b''
        try:
            if self._serial.in_waiting > 0:
                return self._serial.read(self._serial.in_waiting)
            return b''
        except Exception as e:
            logger.error(f"Serial read_all error: {e}")
            return b''

    def flush(self):
        """清空输入输出缓冲区"""
        if self.is_open:
            try:
                self._serial.reset_input_buffer()
                self._serial.reset_output_buffer()
            except Exception as e:
                logger.error(f"Serial flush error: {e}")

    @property
    def is_open(self) -> bool:
        """判断串口是否已打开"""
        return self._serial is not None and self._serial.is_open

    @property
    def in_waiting(self) -> int:
        """获取接收缓冲区滞留字节数"""
        if self.is_open:
            try:
                return self._serial.in_waiting
            except Exception:
                return 0
        return 0
