"""
  Description: TCP 收发能力的轻量封装，提供线程安全的发送与监听工具
        Version: v1.0
        Author: YuShen
        Date: 2026-01-14
        APIs: TcpClient, TcpServer 类

  Example:
    1. client = TcpClient(remote_ip='192.168.1.100', remote_port=12345)
       client.connect()
       client.send("Hello, TCP!")
    2. def on_data(data: str, client_info: tuple):
            print(f"Received from {client_info}: {data}")
       server = TcpServer(local_port=12345, on_data=on_data, decode_utf8=True)
       server.start()
    3. server.stop()

"""
import socket
import threading
from typing import Callable, Optional, Union, List, Dict, Any


TcpPayload = Union[str, bytes]


class TcpClient:
    """
      Description: 轻量 TCP 客户端，维护一个长连接
      Args: 
        remote_ip: str 目标 IP
        remote_port: int 目标端口
        auto_reconnect: bool 是否自动重连（默认 True）
      APIs:
        connect() -> bool: 建立连接
        send(message: Union[str, bytes]) -> bool: 发送消息
        close() -> None: 关闭连接
    """

    def __init__(self, remote_ip: str, remote_port: int, auto_reconnect: bool = True):
        self.remote_ip = remote_ip
        self.remote_port = remote_port
        self.auto_reconnect = auto_reconnect
        self._sock: Optional[socket.socket] = None
        self._lock = threading.Lock()
        self._connected = False

    def connect(self) -> bool:
        """
          Description: 建立 TCP 连接
          Args: 无
          Returns: bool 是否连接成功
        """
        with self._lock:
            return self._connect_unsafe()

    def _connect_unsafe(self) -> bool:
        if self._connected and self._sock:
            return True
        
        # 释放旧 socket
        if self._sock:
            try:
                self._sock.close()
            except Exception:
                pass
            self._sock = None
            
        try:
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._sock.settimeout(5.0) # 连接超时
            self._sock.connect((self.remote_ip, self.remote_port))
            # 连接成功后取消超时或设置长超时
            self._sock.settimeout(None) 
            self._connected = True
            return True
        except Exception:
            self._connected = False
            if self._sock:
                self._sock.close()
                self._sock = None
            return False

    def send(self, message: Union[str, bytes]) -> bool:
        """
          Description: 发送一条消息（支持 str/bytes），支持自动重连
          Args: message: Union[str, bytes] 要发送的内容
          Returns: bool 是否发送成功
        """
        data = message.encode("utf-8", errors="ignore") if isinstance(message, str) else message
        
        with self._lock:
            # 尝试连接
            if not self._connected and self.auto_reconnect:
                if not self._connect_unsafe():
                    return False
            
            if not self._sock:
                return False

            try:
                self._sock.sendall(data)
                return True
            except Exception:
                # 发送失败，标记断开
                self._connected = False
                
                # 若开启自动重连，则尝试重连并重发一次
                if self.auto_reconnect:
                     if self._connect_unsafe():
                         try:
                             self._sock.sendall(data)
                             return True
                         except Exception:
                             self._connected = False
                             return False
                return False

    def close(self) -> None:
        """
          Description: 关闭连接，释放资源
          Args: 无
          Returns: None
        """
        with self._lock:
            if self._sock:
                try:
                    self._sock.shutdown(socket.SHUT_RDWR)
                    self._sock.close()
                except Exception:
                    pass
                self._sock = None
            self._connected = False


class TcpServer:
    """
      Description: 简单的 TCP 服务端：在单独线程中监听端口，为每个客户端连接创建接收线程
      Args: 
        local_port: int 本地监听端口
        on_data: 数据回调 (data, client_addr)，返回 str/bytes 时会自动回写客户端
        bind_ip: str 绑定 IP（默认 0.0.0.0）
        max_clients: int 最大连接数
        decode_utf8: bool 是否将收到的原始字节解码为 UTF-8 文本
        line_delimited: bool 是否按换行拆分消息
        on_client_connected: 客户端连接回调
        on_client_disconnected: 客户端断开回调
      APIs:
        start() -> None: 启动监听
        stop() -> None: 停止监听
    """

    def __init__(
        self,
        local_port: int,
        on_data: Callable[[TcpPayload, tuple], Any],
        bind_ip: str = "0.0.0.0",
        max_clients: int = 10,
        decode_utf8: bool = True,
        line_delimited: bool = False,
        on_client_connected: Optional[Callable[[tuple], None]] = None,
        on_client_disconnected: Optional[Callable[[tuple], None]] = None,
    ):
        self.local_port = local_port
        self.on_data = on_data
        self.bind_ip = bind_ip
        self.max_clients = max_clients
        self.decode_utf8 = decode_utf8
        self.line_delimited = line_delimited
        self.on_client_connected = on_client_connected
        self.on_client_disconnected = on_client_disconnected
        
        self._server_sock: Optional[socket.socket] = None
        self._accept_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        
        self._clients: List[Dict[str, Any]] = [] # [{'sock': sock, 'thread': thread, 'addr': addr}]
        self._clients_lock = threading.Lock()

    def start(self) -> None:
        """
          Description: 启动服务器监听线程
          Args: 无
          Returns: None
        """
        if self._accept_thread and self._accept_thread.is_alive():
            return
            
        self._stop_event.clear()
        self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            self._server_sock.bind((self.bind_ip, self.local_port))
            self._server_sock.listen(self.max_clients)

            self._accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
            self._accept_thread.start()
        except Exception as e:
            self.stop()
            raise RuntimeError(
                f"TCP Server failed to start on {self.bind_ip}:{self.local_port}"
            ) from e

    def stop(self) -> None:
        """
          Description: 停止监听，断开所有客户端连接
          Args: 无
          Returns: None
        """
        self._stop_event.set()
        
        # 关闭服务端 socket，中断 accept
        if self._server_sock:
            try:
                self._server_sock.close()
            except Exception:
                pass
            self._server_sock = None
            
        # 关闭所有客户端连接
        with self._clients_lock:
            for client in self._clients:
                try:
                    client['sock'].shutdown(socket.SHUT_RDWR)
                    client['sock'].close()
                except Exception:
                    pass
            self._clients.clear()
            
        # 等待监听线程结束
        if self._accept_thread and self._accept_thread.is_alive():
            self._accept_thread.join(timeout=1.0)

    def _accept_loop(self) -> None:
        """
          Description: 循环接收客户端连接
        """
        assert self._server_sock is not None
        while not self._stop_event.is_set():
            try:
                if not self._server_sock:
                    break
                client_sock, client_addr = self._server_sock.accept()
                
                if self._stop_event.is_set():
                    client_sock.close()
                    break

                # 启动客户端处理线程
                t = threading.Thread(
                    target=self._client_handler, 
                    args=(client_sock, client_addr), 
                    daemon=True
                )
                
                with self._clients_lock:
                    self._clients.append({
                        'sock': client_sock, 
                        'thread': t,
                        'addr': client_addr
                    })
                if self.on_client_connected:
                    try:
                        self.on_client_connected(client_addr)
                    except Exception:
                        pass
                t.start()
                
            except OSError:
                # Socket 关闭时退出
                break
            except Exception:
                continue

    def _client_handler(self, client_sock: socket.socket, client_addr: tuple) -> None:
        """
          Description: 客户端数据处理循环
        """
        try:
            buffer = ""
            while not self._stop_event.is_set():
                # 阻塞接收，若连接断开 recv 返回空
                data = client_sock.recv(65536)
                if not data:
                    break 
                
                if self.decode_utf8:
                    try:
                        frame: TcpPayload = data.decode("utf-8")
                    except UnicodeDecodeError:
                        continue
                else:
                    frame = data
                if self.on_data:
                    if self.line_delimited and isinstance(frame, str):
                        buffer += frame
                        while "\n" in buffer:
                            line, buffer = buffer.split("\n", 1)
                            line = line.strip()
                            if line:
                                response = self.on_data(line, client_addr)
                                self._send_response(client_sock, response)
                    else:
                        response = self.on_data(frame, client_addr)
                        self._send_response(client_sock, response)
        except Exception:
            pass
        finally:
            # 清理连接
            try:
                client_sock.close()
            except Exception:
                pass
            
            with self._clients_lock:
                self._clients = [c for c in self._clients if c['sock'] != client_sock]
            if self.on_client_disconnected:
                try:
                    self.on_client_disconnected(client_addr)
                except Exception:
                    pass

    def send_to(self, client_addr: tuple, message: TcpPayload) -> bool:
        """
          Description: 向指定客户端发送消息
          Args:
            client_addr: 客户端地址元组
            message: 消息内容
          Returns: bool 是否发送成功
        """
        data = message.encode("utf-8", errors="ignore") if isinstance(message, str) else message
        with self._clients_lock:
            clients = [c for c in self._clients if c.get('addr') == client_addr]
        for client in clients:
            try:
                client['sock'].sendall(data)
                return True
            except Exception:
                return False
        return False

    def _send_response(self, client_sock: socket.socket, response: Any) -> None:
        if response is None:
            return
        data = response.encode("utf-8", errors="ignore") if isinstance(response, str) else response
        if not isinstance(data, bytes):
            return
        client_sock.sendall(data)


__all__ = [
    "TcpClient",
    "TcpServer",
]
