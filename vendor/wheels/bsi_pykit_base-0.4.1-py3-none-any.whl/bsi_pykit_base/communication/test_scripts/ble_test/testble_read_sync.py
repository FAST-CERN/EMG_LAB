"""
Description: BLE 同步读取测试脚本，独立于整体项目，作例程参考。
Author: Yu Shen 
Version: 1.0
Date: 2025-10-27
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import List, Optional, Sequence

# 使用模块级 BLE 便捷 API（内部复用单例管理器）
from bsi_pykit_base.communication import ble

# 可选：按帧统计与延迟评估（与 oldbletest/test_sync.py 一致）
try:
    from decode import decode_stream_channels
except Exception:  # 解码不可用时，按包计数
    decode_stream_channels = None  # type: ignore


# 设备与 UUID 常量（按需修改）
ADDRESS_EEG = "EE:EE:EE:EE:EE:01"
ADDRESS_EMG = "EE:EE:EE:EE:EE:04"  # 如无设备可注释掉对应配置
ADDRESS_SCS = "EE:EE:EE:EE:EE:05"  # 如无设备可注释掉对应配置

COMMAND_ON = 0xAA
COMMAND_STOP = 0xFF

SERVICE_UUID = "8653000a-43e6-47b7-9cb0-5fc21d4ae340"
WRITE_UUID = "8653000c-43e6-47b7-9cb0-5fc21d4ae340"
NOTIFY_UUID = "8653000b-43e6-47b7-9cb0-5fc21d4ae340"
READ_UUID = "8653000d-43e6-47b7-9cb0-5fc21d4ae340"

# 解码通道数（与设备一致：16 或 32）
EEG_CHANNELS = 32

# 时序参数（与 oldbletest/test_sync.py 对齐）
CONNECT_TIMEOUT_S = 30.0
READY_TIMEOUT_S = 15.0
START_TIMEOUT_S = 5.0
CONNECT_STAGGER_S = 0.6  # 分批连接/订阅的错峰时间
QUIET_MS_AFTER_STOP = 400  # STOP 后静默阈值（ms）


def _prefixed(name: str, message: str) -> str:
    return f"[{name}] {message}"


@dataclass
class DeviceConfig:
    name: str
    address: str
    duration_s: float = 20.0
    channels: int = EEG_CHANNELS


@dataclass
class DeviceTestResult:
    name: str
    notify_packets: int
    frames_received: int
    frames_sent: int


class SyncDeviceSession:
    def __init__(self, config: DeviceConfig, start_event: threading.Event) -> None:
        self.config = config
        self._start_event = start_event

        self._connect_gate = threading.Event()
        self._stop_event = threading.Event()
        self._ready_event = threading.Event()
        self._started_event = threading.Event()
        self._completed_event = threading.Event()
        self._connected_event = threading.Event()

        self._lock = threading.Lock()
        self._last_rx_ns = 0
        self._notify_count = 0
        self._frame_count = 0

        self._notify_active = False
        self._connected = False
        self.result: Optional[DeviceTestResult] = None
        self.error: Optional[BaseException] = None

        self._thread = threading.Thread(target=self._run, name=f"SyncSession-{config.name}", daemon=True)

    # 控制接口
    def start(self) -> None:
        self._thread.start()

    def allow_connect(self) -> None:
        self._connect_gate.set()

    def wait_ready(self, timeout: float) -> bool:
        return self._ready_event.wait(timeout)

    def wait_started(self, timeout: float) -> bool:
        return self._started_event.wait(timeout)

    def wait_connected(self, timeout: float) -> bool:
        return self._connected_event.wait(timeout)

    def request_stop(self) -> None:
        self._stop_event.set()

    def join(self) -> None:
        self._completed_event.wait()
        self._thread.join()

    # 内部逻辑
    def _on_notify(self, address: str, char_uuid: str, data: bytes) -> None:
        with self._lock:
            self._notify_count += 1
            self._last_rx_ns = time.perf_counter_ns()
        # 可选：按帧解码并累计（保持回调轻量，解码成本低可直接做）
        if decode_stream_channels is not None:
            try:
                frames = decode_stream_channels(data, self.config.channels)
            except Exception:
                frames = []
            if frames:
                with self._lock:
                    self._frame_count += len(frames)

    def _quiet_for_ms(self, ms: float) -> bool:
        with self._lock:
            ts = self._last_rx_ns
        if ts == 0:
            return False
        return (time.perf_counter_ns() - ts) / 1e6 >= ms

    def _run(self) -> None:
        name = self.config.name
        address = self.config.address
        try:
            # 等待许可：分批连接/订阅，降低栈压力
            self._connect_gate.wait()

            if not ble.connect(address, try_time=3, timeout=10.0):
                raise RuntimeError(_prefixed(name, "Connect failed."))
            self._connected = True
            print(_prefixed(name, f"Connected to {address}"))
            self._connected_event.set()

            if not ble.start_notify(address, NOTIFY_UUID, self._on_notify, timeout=10.0):
                raise RuntimeError(_prefixed(name, "Start notify failed."))
            self._notify_active = True
            print(_prefixed(name, "Started notify."))
            self._ready_event.set()

            # 等待广播“开始”
            if not self._start_event.wait(START_TIMEOUT_S):
                raise TimeoutError(_prefixed(name, "Start signal timeout."))

            # 发送开始命令
            if not ble.write_characteristic(address, WRITE_UUID, bytes([COMMAND_ON]), response=False, timeout=5.0):
                raise RuntimeError(_prefixed(name, "Send ON failed."))
            print(_prefixed(name, "Sent ON."))
            self._started_event.set()

            # 运行指定时长
            self._stop_event.wait(timeout=self.config.duration_s)

            # 发送停止命令
            if not ble.write_characteristic(address, WRITE_UUID, bytes([COMMAND_STOP]), response=False, timeout=5.0):
                raise RuntimeError(_prefixed(name, "Send STOP failed."))
            print(_prefixed(name, "Sent STOP."))

            # STOP 后保持订阅直到静默/超时，尽量收齐尾包
            waited = 0.0
            while not self._quiet_for_ms(QUIET_MS_AFTER_STOP) and waited < 3.0:
                time.sleep(0.02)
                waited += 0.02

            # 读取设备报告的总帧数（若支持）
            sent_bytes = ble.read_characteristic(address, READ_UUID, timeout=3.0)
            total_sent = int.from_bytes(sent_bytes, "little") if sent_bytes else -1

            with self._lock:
                packets = self._notify_count
                frames = self._frame_count if self._frame_count > 0 else packets

            self.result = DeviceTestResult(
                name=name,
                notify_packets=packets,
                frames_received=frames,
                frames_sent=total_sent,
            )

        except BaseException as exc:
            self.error = exc
            print(_prefixed(name, f"Error: {exc}"))
        finally:
            try:
                if self._notify_active:
                    try:
                        ble.stop_notify(address, NOTIFY_UUID, timeout=5.0)
                    except Exception:
                        pass
                if self._connected:
                    try:
                        ble.disconnect(address)
                    except Exception:
                        pass
            finally:
                print(_prefixed(name, "Closed."))
                self._completed_event.set()


def run_sync_test(devices: Sequence[DeviceConfig]) -> List[DeviceTestResult]:
    if not devices:
        return []

    start_event = threading.Event()
    sessions = [SyncDeviceSession(cfg, start_event) for cfg in devices]
    results: List[DeviceTestResult] = []

    for s in sessions:
        s.start()
    try:
        # 逐个放行连接与订阅，并设置错峰
        for i, s in enumerate(sessions):
            s.allow_connect()
            if not s.wait_connected(CONNECT_TIMEOUT_S):
                raise TimeoutError(_prefixed(s.config.name, "Connect timeout"))
            if i < len(sessions) - 1:
                time.sleep(CONNECT_STAGGER_S)

        for s in sessions:
            if not s.wait_ready(READY_TIMEOUT_S):
                raise TimeoutError(_prefixed(s.config.name, "Notify setup timeout"))

        print("All devices ready. Broadcasting start.")
        start_event.set()

        for s in sessions:
            if not s.wait_started(START_TIMEOUT_S):
                raise TimeoutError(_prefixed(s.config.name, "Start ack timeout"))

        # 等待执行完成
        collected: List[DeviceTestResult] = []
        for s in sessions:
            s.join()
            if s.error is not None:
                raise RuntimeError(_prefixed(s.config.name, f"Run failed: {s.error}"))
            if s.result is not None:
                collected.append(s.result)
        results = collected
    finally:
        # 兜底清理
        start_event.set()
        for s in sessions:
            try:
                s.request_stop()
                s.join()
            except Exception:
                pass
    return results


def main() -> None:
    # 选择你的设备集合（若某设备不在线，可注释掉对应行）
    devices = [
        DeviceConfig(name="EEG", address=ADDRESS_EEG, duration_s=20.0, channels=EEG_CHANNELS),
        # DeviceConfig(name="EMG", address=ADDRESS_EMG, duration_s=10.0, channels=EEG_CHANNELS),
        # DeviceConfig(name="SCS", address=ADDRESS_SCS, duration_s=10.0, channels=EEG_CHANNELS),
    ]

    results = run_sync_test(devices)
    for r in results:
        print(
            _prefixed(
                r.name,
                f"notify_packets={r.notify_packets}, frames_received={r.frames_received}, frames_sent={r.frames_sent}",
            )
        )


if __name__ == "__main__":
    main()

