"""
Description: 多设备并发写入/接收测试脚本，独立于整体项目，作例程参考。
Author: Yu Shen
Version: 1.0
Date: 2025-10-27
"""

from __future__ import annotations

"""
多设备并发写入/接收测试（使用 utils.communication.ble 轮子）

场景:
- EEG 设备：订阅 notify，按固定时长接收数据并统计帧数/丢帧。
- 刺激器/外骨骼设备：按 10 Hz 写入 16 字节时间戳（little-endian 64bit 微秒，重复两次构成 16B）。

流程:
1) 各设备分别在线程中连接；EEG 完成 start_notify 作为“就绪”。
2) 等待全部连接（EEG 还需就绪）。
3) 同步开始：EEG 发送 ON；写入设备按 10 Hz 写入。
4) 到达测试时长后，EEG 发送 STOP；各会话清理并汇报统计。
"""
import threading
import time
from dataclasses import dataclass
from queue import SimpleQueue
from time import sleep
from typing import List, Optional, Sequence, Tuple
#运行目录设置为 ms_bci_laboratory 根目录，以便导入 utils.communication.ble
from sys import path
import os
path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../..")))
from bsi_pykit_base.communication import ble
from decode import decode_stream_channels



# 固件命令
COMMAND_ON = 0xAA
COMMAND_STOP = 0xFF

# GATT UUID
SERVICE_UUID = "8653000a-43e6-47b7-9cb0-5fc21d4ae340"
WRITE_UUID = "8653000c-43e6-47b7-9cb0-5fc21d4ae340"
NOTIFY_UUID = "8653000b-43e6-47b7-9cb0-5fc21d4ae340"
READ_UUID = "8653000d-43e6-47b7-9cb0-5fc21d4ae340"

# 超时与频率
CONNECT_TIMEOUT_S = 30.0
READY_TIMEOUT_S = 15.0
START_TIMEOUT_S = 5.0
WRITE_HZ = 10.0  # 10Hz 写入
CONNECT_STAGGER_S = 0.6

# EEG 通道数（按需修改 16/32）
EEG_CHANNELS = 32

# 写入目标开关
ENABLE_STIM_WRITE = True
ENABLE_EXO_WRITE = True


def _prefixed(name: str, message: str) -> str:
    return f"[{name}] {message}"


@dataclass
class DeviceConfig:
    name: str
    address: str


@dataclass
class EegResult:
    name: str
    total_received: int
    total_sent: int
    lost_frames: List[int]


@dataclass
class WriterResult:
    name: str
    writes_attempted: int
    writes_ok: int
    last_error: Optional[str]
    read_counter: Optional[int]


class EegReceiverSession:
    """EEG 订阅接收：连/订/开始/停止/统计（帧计数与丢帧）。"""

    def __init__(self, config: DeviceConfig, start_event: threading.Event, duration_s: float) -> None:
        self.config = config
        self._start_event = start_event
        self._connect_gate = threading.Event()
        self._stop_event = threading.Event()
        self._connected_event = threading.Event()
        self._ready_event = threading.Event()
        self._started_event = threading.Event()
        self._completed_event = threading.Event()
        self._first_frame_event = threading.Event()
        self._lock = threading.Lock()
        self._payload_queue: "SimpleQueue[Optional[bytes]]" = SimpleQueue()
        self._worker_done = threading.Event()

        self._total_received = 0
        self._lost_frames: List[int] = []
        self._last_sequence = 0
        self._duration_s = duration_s

        self._notify_active = False
        self._connected = False
        self.result: Optional[EegResult] = None
        self.error: Optional[BaseException] = None

        self._worker_thread = threading.Thread(
            target=self._process_notifications,
            name=f"EEGWorker-{config.name}",
            daemon=True,
        )
        self._thread = threading.Thread(target=self._run, name=f"EEGSession-{config.name}", daemon=True)

    def start(self) -> None:
        self._worker_thread.start()
        self._thread.start()

    def allow_connect(self) -> None:
        self._connect_gate.set()

    def wait_connected(self, timeout: float) -> bool:
        return self._connected_event.wait(timeout)

    def wait_ready(self, timeout: float) -> bool:
        return self._ready_event.wait(timeout)

    def wait_started(self, timeout: float) -> bool:
        return self._started_event.wait(timeout)

    def join(self) -> None:
        self._completed_event.wait()
        self._thread.join()

    def _notify_cb(self, address: str, char_uuid: str, data: bytes) -> None:
        # 回调轻量：入队，首帧到达时通知
        try:
            self._payload_queue.put_nowait(bytes(data))
        except Exception:
            pass

    def _wait_for_first_frame(self, timeout_s: float = 5.0) -> None:
        if not self._first_frame_event.wait(timeout=timeout_s):
            raise TimeoutError(_prefixed(self.config.name, "No frames received after start."))

    def _run(self) -> None:
        address = self.config.address
        try:
            self._connect_gate.wait()
            print(_prefixed(self.config.name, "Connecting..."))
            if not ble.connect(address, try_time=3, timeout=20.0):
                raise RuntimeError("Connect failed")
            self._connected = True
            self._connected_event.set()

            if not ble.start_notify(address, NOTIFY_UUID, self._notify_cb, timeout=10.0):
                raise RuntimeError("Start notify failed")
            self._notify_active = True
            print(_prefixed(self.config.name, "Subscribed."))
            self._ready_event.set()

            # 同步开始
            self._start_event.wait()
            if self._stop_event.is_set():
                return

            # EEG 发送开启
            ble.write_characteristic(address, WRITE_UUID, bytes([COMMAND_ON]), response=False)
            print(_prefixed(self.config.name, "Sent ON."))
            self._started_event.set()

            self._wait_for_first_frame()
            self._stop_event.wait(timeout=self._duration_s)

            # EEG 发送停止
            ble.write_characteristic(address, WRITE_UUID, bytes([COMMAND_STOP]), response=False)
            print(_prefixed(self.config.name, "Sent STOP."))
            sleep(0.5)

            sent_bytes = ble.read_characteristic(address, READ_UUID, timeout=3.0)
            total_sent = int.from_bytes(sent_bytes or b"\x00\x00\x00\x00", "little")

            with self._lock:
                total_received = self._total_received
                lost_copy = list(self._lost_frames)

            self.result = EegResult(
                name=self.config.name,
                total_received=total_received,
                total_sent=total_sent,
                lost_frames=lost_copy,
            )
        except BaseException as exc:
            if self.error is None:
                self.error = exc
            print(_prefixed(self.config.name, f"Test failed: {exc}"))
        finally:
            try:
                if self._notify_active:
                    try:
                        ble.stop_notify(address, NOTIFY_UUID, timeout=5.0)
                    except Exception:
                        pass
            finally:
                if self._connected:
                    try:
                        ble.disconnect(address)
                    except Exception:
                        pass
                print(_prefixed(self.config.name, "Disconnected."))
                self._payload_queue.put(None)
                self._worker_done.wait()
                self._completed_event.set()

    def _process_notifications(self) -> None:
        try:
            while True:
                payload = self._payload_queue.get()
                if payload is None:
                    break
                if decode_stream_channels is None:
                    # 无解码器时，按“每包=1 帧”计数，不做丢帧
                    with self._lock:
                        self._total_received += 1
                    if not self._first_frame_event.is_set():
                        self._first_frame_event.set()
                    continue
                frames = decode_stream_channels(payload, EEG_CHANNELS)
                with self._lock:
                    for frame in frames:
                        self._total_received += 1
                        expected = self._last_sequence + 1
                        if frame.sequence > expected:
                            self._lost_frames.extend(range(expected, frame.sequence))
                        self._last_sequence = frame.sequence
                if not self._first_frame_event.is_set() and frames:
                    self._first_frame_event.set()
        except BaseException as exc:
            self.error = exc
        finally:
            self._worker_done.set()


class WriterSession:
    """Writer：连接后等待开始信号，随后按 10 Hz 写入 16 字节时间戳。"""

    def __init__(self, config: DeviceConfig, start_event: threading.Event, duration_s: float) -> None:
        self.config = config
        self._start_event = start_event
        self._connect_gate = threading.Event()
        self._stop_event = threading.Event()
        self._connected_event = threading.Event()
        self._ready_event = threading.Event()
        self._completed_event = threading.Event()
        self._duration_s = duration_s

        self._connected = False
        self.writes_attempted = 0
        self.writes_ok = 0
        self.last_error: Optional[str] = None
        self.read_counter: Optional[int] = None
        self._start_ref_ns: Optional[int] = None

        self._thread = threading.Thread(target=self._run, name=f"WriterSession-{config.name}", daemon=True)

    def start(self) -> None:
        self._thread.start()

    def allow_connect(self) -> None:
        self._connect_gate.set()

    def wait_connected(self, timeout: float) -> bool:
        return self._connected_event.wait(timeout)

    def wait_ready(self, timeout: float) -> bool:
        return self._ready_event.wait(timeout)

    def join(self) -> None:
        self._completed_event.wait()
        self._thread.join()

    def _payload(self) -> bytes:
        # 16 字节：将微秒时间戳重复两次（兼容 16B 要求）
        if self._start_ref_ns is None:
            self._start_ref_ns = time.perf_counter_ns()
            elapsed_us = 0
        else:
            elapsed_us = int((time.perf_counter_ns() - self._start_ref_ns) / 1000)
        p8 = int(elapsed_us).to_bytes(8, "little")
        return p8 + p8

    def _run(self) -> None:
        address = self.config.address
        try:
            self._connect_gate.wait()
            print(_prefixed(self.config.name, "Connecting..."))
            ble.connect(address, try_time=3, timeout=20.0)
            self._connected = True
            self._connected_event.set()

            # 写入设备不需要 notify，连接即就绪
            self._ready_event.set()

            # 等待统一开始
            self._start_event.wait()
            if self._stop_event.is_set():
                return

            # 记录写入基准时间
            self._start_ref_ns = time.perf_counter_ns()

            # 10Hz 定时写入
            period = 1.0 / WRITE_HZ
            t0 = time.perf_counter()
            n = 0
            while (time.perf_counter() - t0) < self._duration_s and not self._stop_event.is_set():
                try:
                    self.writes_attempted += 1
                    ok = ble.write_characteristic(address, WRITE_UUID, self._payload(), response=False)
                    if ok:
                        self.writes_ok += 1
                except Exception as exc:
                    self.last_error = str(exc)
                # 相位校正睡眠
                n += 1
                next_t = t0 + n * period
                now = time.perf_counter()
                sleep_dur = max(0.0, next_t - now)
                if sleep_dur > 0:
                    time.sleep(sleep_dur)
            # 读取对端累计计数（若有：例如 2 字节计数）
            read_bytes = ble.read_characteristic(address, READ_UUID, timeout=3.0)
            if read_bytes:
                self.read_counter = int.from_bytes(read_bytes[:2], "little")
        except BaseException as exc:
            self.last_error = str(exc)
            print(_prefixed(self.config.name, f"Writer failed: {exc}"))
        finally:
            if self._connected:
                try:
                    ble.disconnect(address)
                except Exception:
                    pass
            print(_prefixed(self.config.name, "Disconnected."))
            self._completed_event.set()


def run_write_test(duration_s: float = 10.0) -> Tuple[Optional[EegResult], List[WriterResult]]:
    # 设备地址：EEG: ...:01, 刺激器: ...:04, 外骨骼: ...:05
    eeg = DeviceConfig(name="bio-eeg", address="EE:EE:EE:EE:EE:01")
    stim = DeviceConfig(name="stim", address="EE:EE:EE:EE:EE:04")
    exo = DeviceConfig(name="exo", address="EE:EE:EE:EE:EE:05")

    start_event = threading.Event()

    eeg_session = EegReceiverSession(eeg, start_event, duration_s)
    writer_sessions: List[WriterSession] = []
    if ENABLE_STIM_WRITE:
        writer_sessions.append(WriterSession(stim, start_event, duration_s))
    if ENABLE_EXO_WRITE:
        writer_sessions.append(WriterSession(exo, start_event, duration_s))

    # 启动线程
    eeg_session.start()
    for ws in writer_sessions:
        ws.start()

    try:
        # 按顺序节流建立连接（EEG 完成订阅）
        eeg_session.allow_connect()
        if not eeg_session.wait_connected(CONNECT_TIMEOUT_S):
            raise TimeoutError(_prefixed(eeg.name, "EEG did not connect in time."))
        time.sleep(CONNECT_STAGGER_S)

        for ws in writer_sessions:
            ws.allow_connect()
            if not ws.wait_connected(CONNECT_TIMEOUT_S):
                raise TimeoutError(_prefixed(ws.config.name, "Writer did not connect in time."))
            time.sleep(CONNECT_STAGGER_S)

        # EEG 订阅就绪
        if not eeg_session.wait_ready(READY_TIMEOUT_S):
            raise TimeoutError(_prefixed(eeg.name, "EEG notify setup timed out."))

        # 写入线程无需订阅，已就绪
        for ws in writer_sessions:
            if not ws.wait_ready(READY_TIMEOUT_S):
                raise TimeoutError(_prefixed(ws.config.name, "Writer not ready."))

        print("All devices ready. Broadcasting start signal.")
        start_event.set()

        # 确认 EEG 已开始
        if not eeg_session.wait_started(START_TIMEOUT_S):
            raise TimeoutError(_prefixed(eeg.name, "EEG did not acknowledge start."))

        # 等待全部结束
        eeg_session.join()
        for ws in writer_sessions:
            ws.join()

        eeg_result = eeg_session.result
        writer_results = [
            WriterResult(
                name=ws.config.name,
                writes_attempted=ws.writes_attempted,
                writes_ok=ws.writes_ok,
                last_error=ws.last_error,
                read_counter=ws.read_counter,
            )
            for ws in writer_sessions
        ]
        return eeg_result, writer_results
    finally:
        # 兜底：若有线程未退出，发出停止并尽量回收
        start_event.set()


def main() -> None:
    duration_s = 60.0
    eeg_result, writer_results = run_write_test(duration_s=duration_s)

    if eeg_result is not None:
        print(
            _prefixed(
                eeg_result.name,
                f"received={eeg_result.total_received}, sent={eeg_result.total_sent}, lost={len(eeg_result.lost_frames)}",
            )
        )
    for wr in writer_results:
        print(
            _prefixed(
                wr.name,
                f"writes_ok/attempted={wr.writes_ok}/{wr.writes_attempted}, read_counter={wr.read_counter}, last_error={wr.last_error}",
            )
        )


if __name__ == "__main__":
    main()

