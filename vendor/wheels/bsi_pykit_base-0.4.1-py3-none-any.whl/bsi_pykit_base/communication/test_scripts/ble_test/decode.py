"""
数据帧格式（单个逻辑帧）：
    [t0..t3]  = timestamp_us (uint32 LE)  # 时间戳精确到微秒
    [s0..s3]  = frame_sequence (uint32 LE)
    [后续   ] = 32 x int16 LE 通道采样
总字节数：8 + 32*2 = 72 字节。
设备每次 Notification 会连续打包 5 帧（若流停止时剩余不足 5 帧，则为 1~4 帧）。
说明：返回的 Frame 包含字段 `timestamp_us`（微秒），同时提供兼容属性 `timestamp` 返回相同值，便于旧代码依赖 `timestamp` 名称。
"""
from __future__ import annotations
from dataclasses import dataclass
from struct import unpack_from

HEADER_SIZE = 8
CHANNEL_COUNT = 32
PAYLOAD_SIZE = CHANNEL_COUNT * 2
FRAME_SIZE = HEADER_SIZE + PAYLOAD_SIZE

@dataclass(slots=True)
class Frame:
    timestamp_us: int
    sequence: int
    samples: list[int]

    @property
    def timestamp(self) -> int:
        return self.timestamp_us

def decode_frame_channels(frame: bytes, channels: int) -> Frame:
    """按32通道数解码单帧数据。"""
    if len(frame) != HEADER_SIZE + channels * 2:
        raise ValueError("帧大小不正确")

    timestamp_us, sequence = unpack_from("<II", frame, 0)
    samples = list(unpack_from(f"<{channels}h", frame, HEADER_SIZE))
    return Frame(timestamp_us=timestamp_us, sequence=sequence, samples=samples)


def decode_stream_channels(data: bytes, channels: int) -> list[Frame]:
    """按32通道数解码连续数据流。"""
    frame_size = HEADER_SIZE + channels * 2
    if len(data) % frame_size != 0:
        raise ValueError("数据长度非帧大小整数倍")

    frames: list[Frame] = []
    for offset in range(0, len(data), frame_size):
        frames.append(decode_frame_channels(data[offset : offset + frame_size], channels))
    return frames
