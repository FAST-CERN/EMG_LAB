"""
  Description: UDP 收发能力的轻量封装，提供线程安全的发送与监听工具
        Version: v1.0
        Author: YuShen
        Date: 2025-10-23
        APIs: UdpSender, UdpReceiver 类

  Example:
    1. sender = UdpSender(remote_ip='192.168.1.100', remote_port=12345)
         sender.send("Hello, UDP!")
    2. def on_frame(frame: str, port: int):
            print(f"Received on port {port}: {frame}")
            receiver = UdpReceiver(local_port=12345, on_frame=on_frame)
            receiver.start()
    3. receiver.stop()

"""
import socket
import threading
from typing import Callable, Optional, Union



class UdpSender:
    """
      Description: 轻量 UDP 发送器，复用一个 socket，直接 sendto 到目标 IP/端口
      Args: 
        remote_ip: str 目标 IP
        remote_port: int 目标端口
      APIs:
        send(message: Union[str, bytes]) -> None: 发送一条消息（支持 str/bytes）
        close() -> None: 关闭内部 socket，释放系统资源
    """

    def __init__(self, remote_ip: str, remote_port: int):
        """
          Description: 初始化发送器，记录目标地址并预创建 socket
          Args: remote_ip: str 目标 IP; remote_port: int 目标端口
          Returns: None
        """

        self.remote_ip = remote_ip
        self.remote_port = remote_port
        self._sock: Optional[socket.socket] = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._lock = threading.Lock()

    def send(self, message: Union[str, bytes]) -> None:
        """
          Description: 发送一条消息（支持 str/bytes），内部自动处理编码与 socket 重建
          Args: message: Union[str, bytes] 要发送的内容
          Returns: None
        """
        if not self._sock:
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        data = message.encode("utf-8", errors="ignore") if isinstance(message, str) else message
        try:
            with self._lock:
                self._sock.sendto(data, (self.remote_ip, self.remote_port))
        except Exception:
            # 发送异常忽略，避免打断主循环
            pass

    def close(self) -> None:
        """
          Description: 关闭内部 socket，释放系统资源
          Args: 无
          Returns: None
        """
        try:
            if self._sock:
                self._sock.close()
        finally:
            self._sock = None


class UdpReceiver:
    """
      Description: 简单的 UDP 监听器：在单独线程中阻塞接收，每次回调传入文本帧
      Args: 
        local_port: int 本地监听端口
        on_frame: Callable[[str, int], None] 数据帧回调（frame, port）
        bind_ip: str 绑定 IP（默认 0.0.0.0）
      APIs:
        start() -> None: 启动监听线程
        stop() -> None: 停止监听线程
    """

    def __init__(self, local_port: int, on_frame: Callable[[str, int], None], bind_ip: str = "0.0.0.0"):
        """
          Description: 初始化监听器，指定本地端口、回调与绑定地址
          Args: local_port: int 本地监听端口; on_frame: Callable[[str, int], None] 数据帧回调（frame, port）; bind_ip: str 绑定 IP（默认 0.0.0.0）
          Returns: None
        """

        self.local_port = local_port
        self.on_frame = on_frame
        self.bind_ip = bind_ip
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

    def start(self) -> None:
        """
          Description: 启动监听线程，若线程已存在则忽略
          Args: 无
          Returns: None
        """
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # 允许端口快速复用
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((self.bind_ip, self.local_port))
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """
          Description: 停止监听线程，并等待线程退出
          Args: 无
          Returns: None
        """
        self._stop.set()
        try:
            if self._sock:
                self._sock.close()
        finally:
            self._sock = None
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)

    def _run(self) -> None:
        """
          Description: 线程入口：持续接收数据并触发回调
          Args: 无
          Returns: None
        """
        assert self._sock is not None
        while not self._stop.is_set():
            try:
                data, addr = self._sock.recvfrom(65536)
                frame = data.decode("utf-8", errors="ignore")
                if self.on_frame:
                    self.on_frame(frame, self.local_port)
            except OSError:
                # 套接字关闭时退出
                break
            except Exception:
                # 吞掉解析异常，继续接收
                continue


__all__ = [
    "UdpSender",
    "UdpReceiver",
]

