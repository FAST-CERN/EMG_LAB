"""
  Description: BLE 通信封装（基于 bleak），支持多设备并发、顺序读写、通知订阅与重试。
               API 设计尽量同步友好，内部通过后台事件循环线程调度异步任务。
        Version: v1.0
        Author: YuShen
        Date: 2025-10-23
"""

from __future__ import annotations

import asyncio
import inspect
from ..logger import logger
from ..runner import TaskRunner
import platform
from concurrent.futures import TimeoutError as FutureTimeoutError
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Coroutine, Dict, Iterable, List, Optional, Set, Tuple, Union, cast

import bleak
from bleak import BleakClient, BleakScanner
from bleak.backends.device import BLEDevice
from bleak.backends.scanner import AdvertisementData
from bleak.exc import BleakError


"""
  Description: 通知回调类型定义
  args: address: str 设备地址; 
        char_uuid: str 特征 UUID; 
        payload: bytes 通知数据
  returns: None 或 Coroutine
"""
NotifyCallback = Callable[[str, str, bytes], Union[None, Awaitable[None]]]


@dataclass
class ScannedDetailed:
    """
      Description: 详细扫描结果（含广播内容），供需要厂商数据/服务 UUID 的上层使用
        Attributes:
            address: str 设备地址; name: Optional[str] 设备名; rssi: int 信号强度
            manufacturer_data: Dict[int, bytes] 厂商自定义数据 {厂商ID: payload}
            service_uuids: List[str] 广播中出现的 service UUID
    """
    address: str
    name: Optional[str]
    rssi: int
    manufacturer_data: Dict[int, bytes]
    service_uuids: List[str]

    def manufacturer(self, manufacturer_id: int) -> Optional[bytes]:
        """
          Description: 取指定厂商 ID 的自定义广播数据
          Args: manufacturer_id: int 厂商 ID（如 0xFFFF）
          Returns: Optional[bytes] 对应 payload，无则 None
        """
        return self.manufacturer_data.get(manufacturer_id)


def _to_detailed(device: BLEDevice, adv: Optional[AdvertisementData]) -> ScannedDetailed:
    """(BLEDevice, AdvertisementData|None) → ScannedDetailed；无广播详情时相应字段置空。"""
    return ScannedDetailed(
        address=device.address,
        name=device.name,
        rssi=adv.rssi if adv is not None else 0,
        manufacturer_data={int(k): bytes(v) for k, v in (adv.manufacturer_data or {}).items()}
        if adv is not None else {},
        service_uuids=[str(u) for u in (adv.service_uuids or [])] if adv is not None else [],
    )


@dataclass
class _NotifyEntry:
    char_uuid: str
    callback: NotifyCallback
    wrapper: Callable[[Any, bytearray], None]
    # High-frequency notify handling: per-subscription queue + single consumer task
    queue: "asyncio.Queue[bytes]"
    task: Optional[asyncio.Task[Any]]


def _format_bt_addr64(addr64: int) -> str:
    """
      Description: 将 Windows BluetoothAdapter.bluetooth_address (u64) 转换为 MAC 字符串
      Args: addr64: int 低 48bit 保存蓝牙地址的 64 位整数（little-endian）
      Returns: str MAC 地址字符串（大写，冒号分隔）
    """
    b = addr64.to_bytes(8, byteorder="little")
    mac = b[:6]
    return ":".join(f"{x:02X}" for x in mac[::-1])


@dataclass
class _ClientCtx:
    client: BleakClient
    rw_lock: asyncio.Lock  # 序列化同一设备的读/写，避免数据乱序
    connect_lock: asyncio.Lock  # 避免并发连接/重连
    notify_handlers: Dict[str, _NotifyEntry]


class BLEManager:
    """
      Description: BLE 管理器，提供后台事件循环与多设备并发安全封装，暴露同步友好的调用接口
        Args:
            loop_name: str 后台事件循环线程名称,用于调试识别
            auto_reconnect_attempts: int 自动重连尝试次数，0 表示不重连
            auto_reconnect_interval: float 自动重连尝试间隔（秒）
            auto_reconnect_timeout: float 自动重连连接超时（秒）

        Methods:
            start() -> None: 启动后台事件循环线程
            shutdown() -> None: 关闭后台事件循环并释放所有 BLE 连接
            connect(address: str, try_time: int = 3, timeout: float = 10.0) -> bool: 连接指定地址设备（带重试）
            is_connected(address: str) -> bool: 查询指定设备是否已连接
            disconnect(address: str) -> None: 断开与指定设备的连接并清理通知
            get_characteristics(address: str) -> List[Dict[str, Any]]: 拉取指定设备的 GATT 服务与特征概览
            read_characteristic(address: str, char_uuid: str, timeout: float = 10.0) -> Optional[bytes]: 读取指定特征的值
            write_characteristic(address: str, char_uuid: str, payload: Union[bytes, bytearray, List[int], str], response: bool = True, timeout: float = 10.0) -> bool: 写入指定特征的值
            start_notify(address: str, char_uuid: str, callback: NotifyCallback, timeout: float = 10.0) -> bool: 开启指定特征的通知订阅
            stop_notify(address: str, char_uuid: str, timeout: float = 10.0) -> bool: 关闭指定特征的通知订阅

    """

    def __init__(
        self,
        loop_name: str = "BLELoop",
        auto_reconnect_attempts: int = 0, # Disabled by default
        auto_reconnect_interval: float = 1.0,
        auto_reconnect_timeout: float = 5.0,
    ) -> None:
        self._runner = TaskRunner(loop_name=loop_name)   # 后台循环线程统一走 TaskRunner
        self._clients: Dict[str, _ClientCtx] = {}
        self._disconnecting: Set[str] = set()
        self._shutting_down = False
        self._auto_reconnect_attempts = max(0, auto_reconnect_attempts)
        self._auto_reconnect_interval = max(0.0, auto_reconnect_interval)
        self._auto_reconnect_timeout = max(0.1, auto_reconnect_timeout)
        # 扫描控制
        self._scan_cancel_event: Optional[asyncio.Event] = None
        self._scan_running: bool = False

    def _normalize_address(self, address: str) -> str:
        normalized = address.strip()
        if ":" in normalized:
            normalized = normalized.upper()
        return normalized

    @staticmethod
    def _normalize_char_uuid(char_uuid: str) -> str:
        return char_uuid.strip().lower()

    def start(self) -> None:
        """
          Description: 启动后台事件循环线程（幂等，委托 TaskRunner）
        """
        self._runner.start()

    @property
    def is_started(self) -> bool:
        """后台循环线程是否已启动且存活（等价于旧的 _started 检查）。"""
        return self._runner.is_alive

    def shutdown(self) -> None:
        """
          Description: 关闭后台事件循环并释放所有 BLE 连接
                       （停止后再次调用任意操作会惰性重启循环，TaskRunner 语义）
        """
        if not self._runner.is_alive:
            return
        self._shutting_down = True
        try:
            fut = self._runner.submit(self._shutdown_async())
            fut.result(timeout=10)
        finally:
            self._runner.stop()
            self._shutting_down = False

    async def _shutdown_async(self) -> None:
        # 断开所有连接
        for addr in list(self._clients.keys()):
            try:
                ctx = self._clients.get(addr)
                if not ctx:
                    continue
                for entry in list(ctx.notify_handlers.values()):
                    try:
                        # cancel consumer task if present
                        task = entry.task
                        if task is not None:
                            try:
                                task.cancel()
                            except Exception:
                                pass
                        await ctx.client.stop_notify(entry.char_uuid)
                    except Exception:
                        pass
                ctx.notify_handlers.clear()
                self._disconnecting.add(addr)
                try:
                    if ctx.client.is_connected:
                        await ctx.client.disconnect()
                finally:
                    self._disconnecting.discard(addr)
            except Exception:
                pass
        self._clients.clear()

    def _submit(self, coro: Coroutine[Any, Any, Any]):
        return self._runner.submit(coro)   # 内部自动启动后台循环

    def _handle_client_disconnect(self, address_norm: str, client: Optional[BleakClient] = None) -> None:
        ctx = self._clients.get(address_norm)
        if client is not None and ctx and ctx.client is not client:
            return
        if (
            self._shutting_down
            or address_norm in self._disconnecting
            or not self._runner.is_alive
        ):
            return
        logger.warning("BLE client disconnected unexpectedly: %s. Auto-reconnect is disabled.", address_norm)
        
        # 意外断开时，直接清理通知订阅，彻底放弃自动重连
        # 由上层业务决定何时重新 connect() 以及 start_notify()
        if ctx:
            ctx.notify_handlers.clear()

    # async def _auto_reconnect(self, address_norm: str) -> None:
    #     ... (Removed/Disabled)

    async def _restore_notifications(self, address_norm: str, ctx: _ClientCtx) -> None:
        if not ctx.notify_handlers:
            return
        for entry in ctx.notify_handlers.values():
            try:
                await ctx.client.start_notify(entry.char_uuid, entry.wrapper)
                logger.info("Resubscribed notify for %s %s", address_norm, entry.char_uuid)
            except Exception:
                logger.exception(
                    "Failed to resubscribe notify for %s %s", address_norm, entry.char_uuid
                )

    def _make_notify_wrapper(
        self, address_norm: str, char_uuid_display: str, q: "asyncio.Queue[bytes]"
    ) -> Callable[[Any, bytearray], None]:
        # Fast, thread-safe enqueue into the manager's loop; avoid per-packet task creation
        def _inner(_: Any, data: bytearray) -> None:
            try:
                loop = self._runner.loop
                if loop is not None and loop.is_running():
                    loop.call_soon_threadsafe(q.put_nowait, bytes(data))
                else:
                    # Fallback (shouldn't happen in normal flow): best-effort enqueue using a temp loop
                    q.put_nowait(bytes(data))
            except Exception:
                logger.exception(
                    "Failed to enqueue notify for %s %s", address_norm, char_uuid_display
                )

        return _inner

    # -------------------- 工具方法 --------------------
    async def _scan_until_cancel_or_timeout(
        self, timeout: float = 5.0
    ) -> List[Tuple[BLEDevice, Optional[AdvertisementData]]]:
        """
        使用显式 start/stop 的方式进行扫描，以便支持外部停止。
        在超时到达或收到 stop_scan() 触发后提前结束扫描。
        返回 (设备, 广播详情) 列表；旧版 bleak 无广播详情时该位为 None。
        """
        if self._scan_running:
            # 已有扫描在进行中：重置并继续复用取消事件（幂等处理）
            cancel_event = self._scan_cancel_event
            if cancel_event is None:
                cancel_event = asyncio.Event()
                self._scan_cancel_event = cancel_event
        else:
            cancel_event = asyncio.Event()
            self._scan_cancel_event = cancel_event
        self._scan_running = True

        scanner = BleakScanner()
        results: List[Tuple[BLEDevice, Optional[AdvertisementData]]] = []
        try:
            await scanner.start()
            start_t = asyncio.get_running_loop().time()
            # 以小步轮询取消事件，兼顾响应性与性能
            interval = 0.1
            while True:
                if cancel_event.is_set():
                    break
                now = asyncio.get_running_loop().time()
                if now - start_t >= max(0.0, timeout):
                    break
                await asyncio.sleep(interval)
        finally:
            try:
                await scanner.stop()
                print("Scanner stopped.")
            except Exception:
                logger.exception("Failed to stop scanner")
            
            # 收集结果
            try:
                # 尝试获取包含 RSSI 的数据 (Bleak >= 0.14)
                if hasattr(scanner, "discovered_devices_and_advertisement_data"):
                    data_map = scanner.discovered_devices_and_advertisement_data
                    for device, adv_data in data_map.values():
                        results.append((device, adv_data))
                elif hasattr(scanner, "get_discovered_devices"):
                    _devs = scanner.get_discovered_devices()
                    if asyncio.iscoroutine(_devs):
                        try:
                            _devs = await _devs
                        except Exception:
                             pass
                    if _devs:
                        for d in _devs:
                            results.append((d, None))
                else:
                    _devs = list(getattr(scanner, "discovered_devices", []) or [])
                    for d in _devs:
                        results.append((d, None))
            except Exception:
                logger.exception("Error collecting scan results")
                results = []

            # 清理扫描状态
            self._scan_running = False
            self._scan_cancel_event = None

        return results

    def scan_sync(self, timeout: float = 5.0) -> List[Tuple[str, Optional[str], int]]:
        """
          Description: 同步扫描附近 BLE 设备
          Args: timeout: float 扫描超时时间（秒）
          Returns: List[Tuple[str, Optional[str], int]] 设备信息列表 (address, name, rssi)
        """
        fut = self._submit(self._scan_until_cancel_or_timeout(timeout))
        scanned = fut.result(timeout=timeout + 5)
        return [(d.address, d.name, a.rssi if a is not None else 0) for d, a in scanned]

    def scan_detail_sync(self, timeout: float = 5.0) -> List[ScannedDetailed]:
        """
          Description: 同步扫描（详细版）：在地址/名称/RSSI 之外，还返回广播厂商数据与服务 UUID
          Args: timeout: float 扫描超时时间（秒）
          Returns: List[ScannedDetailed] 详细设备信息列表
        """
        fut = self._submit(self._scan_until_cancel_or_timeout(timeout))
        scanned = fut.result(timeout=timeout + 5)
        return [_to_detailed(d, a) for d, a in scanned]

    def scan_async(self, timeout: float = 5.0):
        """
          Description: 异步启动一次扫描（放在后台事件循环），返回一个 Future，可被 stop_scan() 提前打断。
          Args: timeout: float 扫描最长持续时间（秒）
          Returns: concurrent.futures.Future，完成后结果为 List[Tuple[str, Optional[str], int]] -> (address, name, rssi)
        """
        if self._scan_running:
            raise RuntimeError("A BLE scan is already running")

        async def _do_pairs() -> List[Tuple[str, Optional[str], int]]:
            scanned = await self._scan_until_cancel_or_timeout(timeout)
            return [(d.address, d.name, a.rssi if a is not None else 0) for d, a in scanned]

        return self._submit(_do_pairs())

    def scan_detail_async(self, timeout: float = 5.0):
        """
          Description: 异步详细扫描（含广播厂商数据/服务 UUID），返回 Future，可被 stop_scan() 提前打断
          Args: timeout: float 扫描最长持续时间（秒）
          Returns: concurrent.futures.Future，完成后结果为 List[ScannedDetailed]
        """
        if self._scan_running:
            raise RuntimeError("A BLE scan is already running")

        async def _do_detail() -> List[ScannedDetailed]:
            scanned = await self._scan_until_cancel_or_timeout(timeout)
            return [_to_detailed(d, a) for d, a in scanned]

        return self._submit(_do_detail())

    async def _scan_continuous_async(self, callback: Callable[[str, Optional[str], int], None]) -> None:
        """
        后台连续扫描协程，通过 callback 实时回调发现的设备。
        直到 stop_scan()被调用。
        """
        if self._scan_running:
             logger.warning("Scan already running, ignoring start_continuous_scan")
             return

        self._scan_running = True
        self._scan_cancel_event = asyncio.Event()

        # 定义 BleakScanner 的 detection_callback
        def _cb(device: BLEDevice, advertisement_data: AdvertisementData):
            if callback:
                try:
                    # 注意：此回调在 BLELoop 线程执行
                    callback(device.address, device.name, advertisement_data.rssi)
                except Exception:
                    logger.exception("Error in continuous scan callback")

        scanner = BleakScanner(detection_callback=_cb)
        try:
            await scanner.start()
            # 等待取消信号，无超时限制
            await self._scan_cancel_event.wait()
        finally:
            try:
                await scanner.stop()
            except Exception:
                logger.exception("Failed to stop continuous scanner")
            
            self._scan_running = False
            self._scan_cancel_event = None

    def start_continuous_scan(self, callback: Callable[[str, Optional[str], int], None]) -> None:
        """
        启动连续扫描，发现设备时立即调用 callback(address, name, rssi)。
        如果已有扫描在运行，会先尝试停止它。
        需要手动调用 stop_scan() 停止。
        """
        async def _do():
            if self._scan_running:
                logger.info("Scan already running, stopping it before restart...")
                self.stop_scan()
                # 等待前一个扫描彻底结束（flag被清除）
                for _ in range(50): # 最多等待5秒
                    if not self._scan_running:
                        break
                    await asyncio.sleep(0.1)
                else:
                    logger.error("Could not stop previous scan, aborting start.")
                    return
            
            await self._scan_continuous_async(callback)

        self._submit(_do())

    def stop_scan(self) -> bool:
        """
        description: 停止当前扫描操作（如果有的话）。
        return: bool 是否成功停止扫描
        """
        loop = self._runner.loop
        if not self._runner.is_alive or loop is None:
            return False
        if not self._scan_running or self._scan_cancel_event is None:
            return False

        def _set():
            try:
                if self._scan_cancel_event is not None:
                    self._scan_cancel_event.set()
            except Exception:
                pass

        try:
            loop.call_soon_threadsafe(_set)
            return True
        except Exception:
            return False

    def _create_client(self, address_norm: str) -> BleakClient:
        try:
            # 尝试在构造时传入断开回调（bleak >= 0.20.0）
            client = BleakClient(
                address_norm,
                disconnected_callback=lambda _client: self._handle_client_disconnect(address_norm, _client),
            )
        except TypeError:
            client = BleakClient(address_norm)
            setter = getattr(client, "set_disconnected_callback", None)
            if callable(setter):
                try:
                    # 不同版本签名差异，用可变参数避免不匹配
                    setter(lambda *_a, **_k: self._handle_client_disconnect(address_norm, client))
                except Exception:
                    logger.debug("Failed to set disconnect callback for %s", address_norm)
            else:
                logger.debug("Bleak client has no set_disconnected_callback for %s", address_norm)
        return client

    def _get_or_create_ctx(self, address: str) -> _ClientCtx:
        address_norm = self._normalize_address(address)
        ctx = self._clients.get(address_norm)
        if ctx is None:
            client = self._create_client(address_norm)
            ctx = _ClientCtx(
                client=client,
                rw_lock=asyncio.Lock(),
                connect_lock=asyncio.Lock(),
                notify_handlers={},
            )
            self._clients[address_norm] = ctx
        return ctx

    async def _ensure_connected(self, address: str, try_time: int = 1, timeout: float = 10.0) -> BleakClient:
        address_norm = self._normalize_address(address)
        ctx = self._get_or_create_ctx(address_norm)
        # 快路径：已连接则直接返回
        if ctx.client.is_connected:
            return ctx.client
        async with ctx.connect_lock:
            if ctx.client.is_connected:
                return ctx.client

            # 在手动连接/重试前，如果当前未连接，强制重建 client 实例
            ctx.client = self._create_client(address_norm)

            # 未连接，进行重试连接
            last_err: Optional[Exception] = None
            for _ in range(max(1, try_time)):
                try:
                    await ctx.client.connect(timeout=timeout)
                    if ctx.client.is_connected:
                        logger.info("Connected to %s", address_norm)
                        # 手动重新连接，不再自动恢复之前的通知订阅，交由上层重新 start_notify
                        # if ctx.notify_handlers:
                        #     await self._restore_notifications(address_norm, ctx)
                        return ctx.client
                except Exception as e:
                    last_err = e
                    logger.warning("Connect attempt failed for %s: %s", address_norm, e)
                    # bleak 通常允许对同一个未连接的实例重试 connect。
                    # 这里保持原样，仅在最开始重建一次。
                # 小间隔后再试
                await asyncio.sleep(0.2)
            # 连接失败
            if last_err:
                raise last_err
            raise RuntimeError(f"Connect to {address_norm} failed")

    # -------------------- 对外 API --------------------
    def connect(self, address: str, try_time: int = 3, timeout: float = 10.0) -> bool:
        """
          Description: 连接指定地址设备（带重试）
          Args: address: str 设备地址; try_time: int 重试次数; timeout: float 单次连接超时（秒）
          Returns: bool 是否连接成功
        """
        # try:
        #     _ = self.scan(timeout=2.0)
        # except Exception:
        #     pass

        fut = self._submit(self._ensure_connected(address, try_time=try_time, timeout=timeout))
        try:
            fut.result(timeout=timeout + 5)
            return True
        except FutureTimeoutError:
            fut.cancel()
            logger.warning("Connect timeout for %s", address)
        except Exception:
            logger.exception("Connect failed for %s", address)
        return False

    def is_connected(self, address: str) -> bool:
        """
          Description: 查询指定设备是否已连接
          Args: address: str 设备地址
          Returns: bool 连接状态
        """
        ctx = self._clients.get(self._normalize_address(address))
        return bool(ctx and ctx.client.is_connected)

    def disconnect(self, address: str) -> None:
        """
          Description: 断开与指定设备的连接并清理通知
          Args: address: str 设备地址
          Returns: None
        """
        address_norm = self._normalize_address(address)
        self._disconnecting.add(address_norm)

        async def _do() -> None:
            ctx = self._clients.get(address_norm)
            if not ctx:
                return
            try:
                for entry in list(ctx.notify_handlers.values()):
                    try:
                        # cancel consumer task if present
                        task = entry.task
                        if task is not None:
                            try:
                                task.cancel()
                            except Exception:
                                pass
                        await ctx.client.stop_notify(entry.char_uuid)
                    except Exception:
                        pass
                ctx.notify_handlers.clear()
                if ctx.client.is_connected:
                    await ctx.client.disconnect()
                    logger.info("Disconnected from %s", address_norm)
            finally:
                # 清理上下文，下一次会重建
                self._clients.pop(address_norm, None)
                self._disconnecting.discard(address_norm)

        fut = self._submit(_do())
        try:
            fut.result(timeout=10)
        finally:
            self._disconnecting.discard(address_norm)

    def get_characteristics(self, address: str) -> List[Dict[str, Any]]:
        """
          Description: 拉取指定设备的 GATT 服务与特征概览
          Args: address: str 设备地址
          Returns: List[Dict[str, Any]] 服务 UUID 与特征列表
        """

        async def _do() -> List[Dict[str, Any]]:
            address_norm = self._normalize_address(address)
            client = await self._ensure_connected(address_norm)
            # bleak 版本兼容：可能有 await client.get_services() 或 client.services
            services_collection = None
            get_services = getattr(client, "get_services", None)
            if callable(get_services):
                maybe = get_services()
                if asyncio.iscoroutine(maybe):
                    services_collection = await maybe
                else:
                    services_collection = maybe
            else:
                services_collection = getattr(client, "services", None)
                if services_collection is None:
                    raise RuntimeError(
                        "Bleak client has no services available; ensure connected and supported version."
                    )

            # 归一化为可迭代
            services_iter: Iterable[Any]
            if hasattr(services_collection, "__iter__"):
                services_iter = cast(Iterable[Any], services_collection)
            else:
                inner = getattr(services_collection, "services", None)
                if inner is not None and hasattr(inner, "__iter__"):
                    services_iter = cast(Iterable[Any], inner)
                else:
                    raise RuntimeError(
                        "Services collection is not iterable; unsupported bleak backend/version."
                    )

            result: List[Dict[str, Any]] = []
            for svc in services_iter:
                chars = [
                    {
                        "uuid": ch.uuid,
                        "description": ch.description,
                        "properties": list(ch.properties),
                    }
                    for ch in svc.characteristics
                ]
                result.append({"service_uuid": svc.uuid, "characteristics": chars})
            logger.info("Fetched %d services for %s", len(result), address_norm)
            return result

        fut = self._submit(_do())
        try:
            return fut.result(timeout=20)
        except FutureTimeoutError:
            fut.cancel()
            logger.warning("Get characteristics timeout for %s", address)
        except BleakError:
            logger.exception("Get characteristics failed for %s", address)
        except Exception:
            logger.exception("Unexpected error getting characteristics for %s", address)
        return []

    def read_characteristic(self, address: str, char_uuid: str, timeout: float = 10.0) -> Optional[bytes]:
        """
          Description: 读取指定特征的值
          Args: address: str 设备地址; char_uuid: str 特征 UUID; timeout: float 读取超时（秒）
          Returns: Optional[bytes] 读取到的字节数据，失败返回 None
        """

        async def _do() -> bytes:
            address_norm = self._normalize_address(address)
            client = await self._ensure_connected(address_norm)
            ctx = self._clients[address_norm]
            async with ctx.rw_lock:
                data = await client.read_gatt_char(char_uuid)
                logger.info("Read %d bytes from %s %s", len(data), address_norm, char_uuid)
                return data

        fut = self._submit(_do())
        try:
            return fut.result(timeout=timeout + 5)
        except FutureTimeoutError:
            fut.cancel()
            logger.warning("Read characteristic timeout for %s %s", address, char_uuid)
        except BleakError:
            logger.exception("Read characteristic failed for %s %s", address, char_uuid)
        except Exception:
            logger.exception("Unexpected error reading %s %s", address, char_uuid)
        return None

    def write_characteristic(
        self,
        address: str,
        char_uuid: str,
        payload: Union[bytes, bytearray, List[int], str],
        response: bool = True,
        timeout: float = 10.0,
    ) -> bool:
        """
          Description: 写入指定特征的值
          Args: address: str 设备地址; char_uuid: str 特征 UUID; payload: 写入数据（bytes/bytearray/list[int]/十六进制字符串）; response: bool 是否需要响应; timeout: float 写入超时（秒）
          Returns: bool 是否写入成功
        """

        async def _do() -> bool:
            address_norm = self._normalize_address(address)
            client = await self._ensure_connected(address_norm)
            ctx = self._clients[address_norm]
            # 统一转换 payload
            data: bytes
            if isinstance(payload, (bytes, bytearray)):
                data = bytes(payload)
            elif isinstance(payload, list):
                data = bytes(payload)
            elif isinstance(payload, str):
                # 支持 "01 02 0A" 和"01020A" 形式的十六进制字符串
                s = payload.replace(" ", "").replace("-", "").replace(":", "")
                if len(s) % 2 != 0:
                    raise ValueError("Hex string length must be even")
                data = bytes.fromhex(s)
            else:
                raise TypeError("payload must be bytes/bytearray/list[int]/hex str")

            async with ctx.rw_lock:
                await client.write_gatt_char(char_uuid, data, response=response)
            return True

        fut = self._submit(_do())
        try:
            fut.result(timeout=timeout + 5)
            return True
        except FutureTimeoutError:
            fut.cancel()
            logger.warning("Write characteristic timeout for %s %s", address, char_uuid)
        except BleakError:
            logger.exception("Write characteristic failed for %s %s", address, char_uuid)
        except Exception:
            logger.exception("Unexpected error writing %s %s", address, char_uuid)
        return False

    def start_notify(
        self,
        address: str,
        char_uuid: str,
        callback: NotifyCallback,
        timeout: float = 10.0,
    ) -> bool:
        """
          Description: 开启指定特征的通知订阅
          Args: address: str 设备地址; char_uuid: str 特征 UUID; callback: 回调函数 (address, char_uuid, payload)->None/Coroutine; timeout: float 超时（秒）
          Returns: bool 是否订阅成功
        """
        if not callable(callback):
            raise TypeError("callback must be callable")

        async def _do() -> bool:
            address_norm = self._normalize_address(address)
            char_uuid_clean = char_uuid.strip()
            char_key = self._normalize_char_uuid(char_uuid_clean)
            client = await self._ensure_connected(address_norm)
            ctx = self._clients[address_norm]
            if char_key in ctx.notify_handlers:
                raise ValueError(f"Notification already active for {char_uuid_clean}")
            # Per-subscription queue and single consumer task reduce overhead under high rate
            q: asyncio.Queue[bytes] = asyncio.Queue()
            wrapper = self._make_notify_wrapper(address_norm, char_uuid_clean, q)

            async def _consumer() -> None:
                while True:
                    payload = await q.get()
                    try:
                        try:
                            result = callback(address_norm, char_uuid_clean, payload)
                            if inspect.isawaitable(result):
                                await cast(Awaitable[Any], result)
                        except Exception:
                            logger.exception(
                                "Notification handler failed for %s %s",
                                address_norm,
                                char_uuid_clean,
                            )
                    finally:
                        # Mark one item done; protects against queue.join misuse
                        try:
                            q.task_done()
                        except Exception:
                            pass

            await client.start_notify(char_uuid_clean, wrapper)
            task = asyncio.create_task(_consumer())
            ctx.notify_handlers[char_key] = _NotifyEntry(
                char_uuid=char_uuid_clean,
                callback=callback,
                wrapper=wrapper,
                queue=q,
                task=task,
            )
            logger.info("Started notify on %s %s", address_norm, char_uuid_clean)
            return True

        fut = self._submit(_do())
        try:
            fut.result(timeout=timeout + 5)
            return True
        except FutureTimeoutError:
            fut.cancel()
            logger.warning("Start notify timeout for %s %s", address, char_uuid)
        except (BleakError, ValueError):
            logger.exception("Start notify failed for %s %s", address, char_uuid)
        except Exception:
            logger.exception("Unexpected error starting notify %s %s", address, char_uuid)
        return False

    def stop_notify(self, address: str, char_uuid: str, timeout: float = 10.0) -> bool:
        """
          Description: 关闭指定特征的通知订阅
          Args: address: str 设备地址; char_uuid: str 特征 UUID; timeout: float 超时（秒）
          Returns: bool 是否关闭成功
        """

        async def _do() -> bool:
            address_norm = self._normalize_address(address)
            ctx = self._clients.get(address_norm)
            if not ctx:
                return False
            char_uuid_clean = char_uuid.strip()
            char_key = self._normalize_char_uuid(char_uuid_clean)
            entry = ctx.notify_handlers.pop(char_key, None)
            if entry is None:
                return False
            # Stop the consumer task first
            task = entry.task
            if task is not None:
                try:
                    task.cancel()
                except Exception:
                    pass
            if ctx.client.is_connected:
                try:
                    await ctx.client.stop_notify(entry.char_uuid)
                except Exception:
                    logger.exception(
                        "Failed to stop notify for %s %s", address_norm, entry.char_uuid
                    )
            logger.info("Stopped notify on %s %s", address_norm, entry.char_uuid)
            return True

        fut = self._submit(_do())
        try:
            return fut.result(timeout=timeout + 5)
        except FutureTimeoutError:
            fut.cancel()
            logger.warning("Stop notify timeout for %s %s", address, char_uuid)
        except Exception:
            logger.exception("Unexpected error stopping notify %s %s", address, char_uuid)
        return False


# -------------------- 系统配对（仅 Windows，WinRT）--------------------

def _mac_to_u64(address: str) -> int:
    """MAC 字符串 → Windows BluetoothAddress（u64）。"""
    return int(address.replace(":", "").replace("-", ""), 16)


def pair_status(address: str) -> Optional[bool]:
    """
      Description: 查询系统与指定 BLE 设备的配对(bond)状态
      Args: address: str 设备 MAC
      Returns: Optional[bool] True=已配对；False=未配对；None=设备不可达/无法判定
      Note: 阻塞调用线程（内建事件循环跑 WinRT 异步）；worker 线程或初始化阶段用
    """
    if platform.system() != "Windows":
        logger.warning("pair_status 仅支持 Windows")
        return None

    async def _impl() -> Optional[bool]:
        from winrt.windows.devices.bluetooth import BluetoothLEDevice
        device = await BluetoothLEDevice.from_bluetooth_address_async(_mac_to_u64(address))
        try:
            info = device.device_information
            return bool(info.pairing.is_paired) if info is not None else None
        finally:
            device.close()

    return asyncio.run(_impl())


def pair(address: str, pin: str) -> bool:
    """
      Description: 与指定 BLE 设备做系统级配对（Passkey Entry：代码提交 PIN，
                   对应参照端 PAIRING_VARIANT=0 + setPin 流程）
      Args: address: str 设备 MAC; pin: str 配对口令（如动态 6 位）
      Returns: bool 是否配对成功（已配对直接返回 True）
      Note: 阻塞调用线程；设备须在广播/可达。经 BluetoothLEDevice→DeviceInformation
            →Pairing.Custom(ProvidePin) 实现，事件回调自动提交 PIN，无需系统弹窗
    """
    if platform.system() != "Windows":
        logger.error("pair 仅支持 Windows")
        return False

    async def _impl() -> bool:
        from winrt.windows.devices.bluetooth import BluetoothLEDevice
        from winrt.windows.devices.enumeration import DevicePairingKinds, DevicePairingResultStatus
        device = await BluetoothLEDevice.from_bluetooth_address_async(_mac_to_u64(address))
        try:
            info = device.device_information
            if info is None:
                logger.error("pair: 无法获取设备信息（设备不可达？）")
                return False
            pairing = info.pairing
            if pairing.is_paired:
                logger.info("pair: %s 已配对，跳过", address)
                return True
            if not pairing.can_pair:
                logger.error("pair: %s 不可配对", address)
                return False
            custom = pairing.custom

            def _on_requested(_sender, args):
                deferral = args.get_deferral()
                try:
                    if args.pairing_kind == DevicePairingKinds.PROVIDE_PIN:
                        # 注：本 winrt 投影把 Accept(String) 重载改名为 accept_with_pin
                        args.accept_with_pin(pin)
                        logger.info("pair: 已提交 PIN")
                    else:
                        args.accept()         # 确认式兜底
                finally:
                    deferral.complete()

            token = custom.add_pairing_requested(_on_requested)
            try:
                kinds = DevicePairingKinds.PROVIDE_PIN | DevicePairingKinds.CONFIRM_ONLY
                result = await custom.pair_async(kinds)
            finally:
                custom.remove_pairing_requested(token)
            ok = result.status == DevicePairingResultStatus.PAIRED
            (logger.info if ok else logger.error)("pair: %s 配对%s（status=%s）",
                                                  address, "成功" if ok else "失败", result.status)
            return ok
        finally:
            device.close()

    return asyncio.run(_impl())


def unpair(address: str) -> bool:
    """
      Description: 移除系统与指定 BLE 设备的配对(bond)——设置页找不到设备时的清除手段
      Args: address: str 设备 MAC
      Returns: bool True=已清除或本就未配对
      Note: 阻塞调用线程；不影响已建立的连接（断连由上层处理）
    """
    if platform.system() != "Windows":
        logger.error("unpair 仅支持 Windows")
        return False

    async def _impl() -> bool:
        from winrt.windows.devices.bluetooth import BluetoothLEDevice
        from winrt.windows.devices.enumeration import DeviceUnpairingResultStatus
        device = await BluetoothLEDevice.from_bluetooth_address_async(_mac_to_u64(address))
        try:
            info = device.device_information
            if info is None:
                logger.error("unpair: 无法获取设备信息（设备不可达？）")
                return False
            pairing = info.pairing
            if not pairing.is_paired:
                logger.info("unpair: %s 本就未配对", address)
                return True
            result = await pairing.unpair_async()
            ok = result.status == DeviceUnpairingResultStatus.UNPAIRED
            (logger.info if ok else logger.error)("unpair: %s 解除配对%s（status=%s）",
                                                  address, "成功" if ok else "失败", result.status)
            return ok
        finally:
            device.close()

    return asyncio.run(_impl())


# -------------------- 使用便捷实例 --------------------
_default_manager: Optional[BLEManager] = None


def _mgr() -> BLEManager:
    global _default_manager
    if _default_manager is None:
        _default_manager = BLEManager()
        _default_manager.start()
    return _default_manager


def connect(address: str, try_time: int = 3, timeout: float = 10.0) -> bool:
    """
      Description: 连接指定地址设备（带重试）
      Args: address: str 设备地址; try_time: int 重试次数; timeout: float 超时（秒）
      Returns: bool 是否连接成功
    """
    return _mgr().connect(address, try_time=try_time, timeout=timeout)


def is_connected(address: str) -> bool:
    """
      Description: 查询指定设备是否已连接
      Args: address: str 设备地址
      Returns: bool 连接状态
    """
    return _mgr().is_connected(address)


def disconnect(address: str) -> None:
    """
      Description: 断开与指定设备的连接并清理通知
      Args: address: str 设备地址
      Returns: None
    """
    _mgr().disconnect(address)


def get_characteristics(address: str) -> List[Dict[str, Any]]:
    """
      Description: 拉取指定设备的 GATT 服务与特征概览
      Args: address: str 设备地址
      Returns: List[Dict[str, Any]] 服务 UUID 与特征列表
    """
    return _mgr().get_characteristics(address)


def read_characteristic(address: str, char_uuid: str, timeout: float = 10.0) -> Optional[bytes]:
    """
      Description: 读取指定特征的值
      Args: address: str 设备地址; char_uuid: str 特征 UUID; timeout: float 超时（秒）
      Returns: Optional[bytes] 读取到的字节数据，失败返回 None
    """
    return _mgr().read_characteristic(address, char_uuid, timeout=timeout)


def write_characteristic(
    address: str,
    char_uuid: str,
    payload: Union[bytes, bytearray, List[int], str],
    response: bool = True,
    timeout: float = 10.0,
) -> bool:
    """
      Description: 写入指定特征的值
      Args: address: str 设备地址; char_uuid: str 特征 UUID; payload: 写入数据（bytes/bytearray/list[int]/十六进制字符串）; response: bool 是否需要响应; timeout: float 超时（秒）
      Returns: bool 是否写入成功
    """
    return _mgr().write_characteristic(address, char_uuid, payload, response=response, timeout=timeout)


def start_notify(
    address: str,
    char_uuid: str,
    callback: NotifyCallback,
    timeout: float = 10.0,
) -> bool:
    """
      Description: 开启指定特征的通知订阅
      Args: address: str 设备地址; char_uuid: str 特征 UUID; callback: 回调函数 (address, char_uuid, payload)->None/Coroutine; timeout: float 超时（秒）
      Returns: bool 是否订阅成功
    """
    return _mgr().start_notify(address, char_uuid, callback, timeout=timeout)


def stop_notify(address: str, char_uuid: str, timeout: float = 10.0) -> bool:
    """
      Description: 关闭指定特征的通知订阅
      Args: address: str 设备地址; char_uuid: str 特征 UUID; timeout: float 超时（秒）
      Returns: bool 是否关闭成功
    """
    return _mgr().stop_notify(address, char_uuid, timeout=timeout)

def scan(timeout: float = 10.0):
        """
            Description: 异步扫描附近 BLE 设备（唯一公开的扫描入口）。
            Args: timeout: float 扫描最长持续时间（秒）
            Returns: concurrent.futures.Future，结果为 List[Tuple[str, Optional[str]]] -> (address, name)
            Example:  
                fut = scan(5.0)           # 需要赋值到一个变量
                pairs = fut.result()      # 用.result()阻塞等待结果，通常较快
                devices = [{"address": a, "name": n} for a, n in pairs]
                print("Nearby devices:", devices)
                # 注意：以上流程中可随时用stop_scan()提前停止扫描,且fut.result()会返回已扫描到的结果。
        """
        return _mgr().scan_async(timeout=timeout)


def scan_detail(timeout: float = 10.0):
        """
            Description: 异步详细扫描附近 BLE 设备（含广播厂商数据/服务 UUID，唯一公开的详细扫描入口）。
            Args: timeout: float 扫描最长持续时间（秒）
            Returns: concurrent.futures.Future，结果为 List[ScannedDetailed]
            Example:
                fut = scan_detail(5.0)
                detailed = fut.result()
                nonce = detailed[0].manufacturer(0xFFFF)   # 取厂商 ID 0xFFFF 的自定义数据
        """
        return _mgr().scan_detail_async(timeout=timeout)


def stop_scan() -> bool:
        """
            Description: 停止当前正在进行的 BLE 扫描（若存在）。
            Returns: bool 是否成功请求停止
        """
        return _mgr().stop_scan()

def start_continuous_scan(callback: Callable[[str, Optional[str], int], None]) -> None:
    """
    启动连续扫描，发现设备时立即调用 callback(address, name, rssi)。
    需要手动调用 stop_scan() 停止。
    """
    _mgr().start_continuous_scan(callback)

__all__ = [
    "BLEManager",
    "ScannedDetailed",
    "scan_detail",
    "pair",
    "pair_status",
    "unpair",
    "connect",
    "is_connected",
    "disconnect",
    "get_characteristics",
    "read_characteristic",
    "write_characteristic",
    "start_notify",
    "stop_notify",
    "scan",
    "stop_scan",
    "start_continuous_scan",
]


# if __name__ == "__main__":
#     # 测试停止扫描能否工作
#     from time import sleep
#     fut = scan(10)
#     sleep(3)
#     stop_scan()
#     print("Scan stopped.")
#     pairs = fut.result()
#     devices = [{"address": a, "name": n} for a, n in pairs]
#     print("Scan result:", devices)
