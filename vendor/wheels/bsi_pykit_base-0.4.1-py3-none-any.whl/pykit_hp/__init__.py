"""pykit_hp:Python 基础库(内部基准库)。

提供"同步式写异步非阻塞"的统一机制:后台 asyncio 循环线程 + 跨线程桥接。
任何耗时/阻塞的异步任务都通过 TaskRunner 在后台循环线程执行,
主线程 await(run)或 worker 线程阻塞(run_sync)都不卡 UI。
后续其他 Python 基础功能(日志/配置/工具函数等)也会放进来。

已有模块:
- pykit_hp.runner.TaskRunner: 异步桥(后台 asyncio 循环线程 + 跨线程桥接)
- pykit_hp.bus.EventBus / BusData: 通用事件总线(封装 pypubsub)
- pykit_hp.hardware.IHardware: 通用硬件接口抽象

用法:
    from pykit_hp import TaskRunner

    runner = TaskRunner()
    result = await runner.run(some_coro())       # qasync 主线程 await
    result = runner.run_sync(some_coro(), 10.0)  # worker 线程阻塞
"""

from .runner import TaskRunner
from .bus import BusData, EventBus
from .hardware import IHardware

__version__ = "0.2.0"

__all__ = ["TaskRunner", "EventBus", "BusData", "IHardware"]
