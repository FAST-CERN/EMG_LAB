"""TaskRunner:后台 asyncio 循环线程,提供"同步式写异步非阻塞"的统一机制。

任何耗时/阻塞的异步任务,都交给 TaskRunner 在后台循环线程执行:

    runner = TaskRunner()
    result = await runner.run(coro)          # qasync 主线程:await,不阻塞
    result = runner.run_sync(coro, 10.0)     # worker 线程:阻塞直到结果
    runner.submit(coro)                       # fire-and-forget:不等待
    runner.call_soon_threadsafe(callback)     # 从任意线程往后台循环塞一个回调

线程模型:
    后台一条 asyncio 循环线程,负责真正执行协程;
    调用方(main thread / worker thread)通过桥接与它通信。
    run() 的 await 不阻塞当前线程;run_sync() 会阻塞调用线程(只许 worker 线程用)。
"""

from __future__ import annotations

import asyncio
import logging
import threading
from typing import Any, Callable, Coroutine, Optional

logger = logging.getLogger(__name__)


class TaskRunner:
    """后台 asyncio 循环线程,提供"同步式写异步非阻塞"的统一机制。

    任何耗时/阻塞的异步任务都交给它在后台循环线程执行,绝不阻塞主线程。

    用法:
        runner = TaskRunner()
        result = await runner.run(coro)          # qasync 主线程:await,不阻塞
        result = runner.run_sync(coro, 10.0)     # worker 线程:阻塞直到结果
        runner.submit(coro)                       # fire-and-forget:不等待
        runner.call_soon_threadsafe(cb)           # 往后台循环塞一个小回调

    约定:
        - 每个模块各自一个 TaskRunner,不共享循环线程(隔离优先);
        - 循环只跑 async I/O 任务;阻塞/CPU 函数用 asyncio.to_thread,别塞进循环。

    Args:
        loop_name: 后台线程名(调试用,如 "BLELoop")。
    """

    def __init__(self, loop_name: str = "AsyncLoop") -> None:
        self._loop_name = loop_name
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

    # -------------------- 后台循环线程 --------------------
    def start(self) -> None:
        """启动后台 asyncio 循环线程(幂等,可重复调用)。

        一般不需要手动调用——run/run_sync/submit 内部会自动 start。
        进程退出时 daemon 线程自动回收。
        """
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._loop = asyncio.new_event_loop()
            self._thread = threading.Thread(
                target=self._run_loop, args=(self._loop,), name=self._loop_name, daemon=True
            )
            self._thread.start()

    def _run_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        asyncio.set_event_loop(loop)
        try:
            loop.run_forever()
        finally:
            loop.close()

    @property
    def is_alive(self) -> bool:
        """后台线程是否已启动且存活。"""
        return bool(self._thread is not None and self._thread.is_alive())

    def stop(self) -> None:
        """停止后台循环(仅供测试/退出清理;进程退出时 daemon 线程自动回收)。"""
        with self._lock:
            loop, thread = self._loop, self._thread
            self._loop, self._thread = None, None
        if loop is None or thread is None:
            return
        try:
            loop.call_soon_threadsafe(loop.stop)
        except Exception:  # noqa: BLE001
            pass
        thread.join(timeout=3)

    # -------------------- 桥接 --------------------
    async def run(self, coro: Coroutine[Any, Any, Any]) -> Any:
        """async 版桥接:在后台循环执行 coro,当前线程 await 结果,不阻塞。

        Args:
            coro: 要在后台循环执行的协程(由调用方创建,如 `runner.run(some_coro())`)。

        Returns:
            协程的返回值。

        Note:
            - 协程在后台循环线程执行,不在当前线程;
            - await 挂起当前协程,不阻塞当前线程(适合 qasync 主线程)。
        """
        self.start()
        if self._loop is None:
            raise RuntimeError("async loop not started")
        logger.debug("[%s] run: schedule coro -> background loop (thread=%s), awaiting...",
                     threading.current_thread().name, self._thread.name if self._thread else "?")
        fut = asyncio.run_coroutine_threadsafe(coro, self._loop)
        result = await asyncio.wrap_future(fut)
        logger.debug("[%s] run: got result", threading.current_thread().name)
        return result

    def run_sync(self, coro: Coroutine[Any, Any, Any], timeout: float) -> Any:
        """同步版桥接:阻塞当前(worker)线程直到结果。请勿在 Qt 主线程调用。

        Args:
            coro: 要在后台循环执行的协程。
            timeout: 等待结果的超时(秒)。

        Returns:
            协程的返回值。

        Raises:
            asyncio.TimeoutError: 超时。此时后台任务会被取消(避免残留孤儿任务)。
        """
        self.start()
        if self._loop is None:
            raise RuntimeError("async loop not started")
        fut = asyncio.run_coroutine_threadsafe(coro, self._loop)
        try:
            return fut.result(timeout)
        except asyncio.TimeoutError:
            fut.cancel()   # 取消后台任务,清理干净
            raise

    def submit(self, coro: Coroutine[Any, Any, Any]):
        """fire-and-forget:把协程排到后台循环,不等待结果,立即返回。

        Args:
            coro: 要在后台循环执行的协程。

        Returns:
            concurrent.futures.Future —— 可忽略;想查结果/异常就留着它。

        Note:
            协程内部抛的异常默认不会出现在调用方(除非你等 Future 的 result())。
            只用于"不该大声失败"的后台任务。
        """
        self.start()
        if self._loop is None:
            raise RuntimeError("async loop not started")
        return asyncio.run_coroutine_threadsafe(coro, self._loop)

    def call_soon_threadsafe(self, callback: Callable[[], None]) -> None:
        """从任意线程往后台循环塞一个普通函数回调(在后台循环线程执行),不等待。

        Args:
            callback: 要执行的普通函数(不是协程)。必须是"快、不阻塞"的小动作
                      (设标志/置事件等);慢函数会卡住后台循环,请用 asyncio.to_thread。
        """
        self.start()
        if self._loop is None:
            raise RuntimeError("async loop not started")
        self._loop.call_soon_threadsafe(callback)
