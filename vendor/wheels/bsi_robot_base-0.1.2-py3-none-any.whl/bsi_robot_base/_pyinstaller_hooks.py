"""PyInstaller hook 目录发现入口（pyinstaller40/hook-dirs entry point）。

PyInstaller 在每次构建时通过 importlib.metadata 读取本包的 `pyinstaller40`
entry point `hook-dirs`，在隔离子进程里调用 get_hook_dirs() 拿到 hook 目录，
从而自动加载 `hooks/hook-bsi_robot_base.py` —— 因此宿主打包 exe 时
不需要针对 bsi_robot_base 的任何额外配置，assets 自动进包。
"""

from pathlib import Path


def get_hook_dirs() -> list[str]:
    return [str(Path(__file__).resolve().parent / "hooks")]
