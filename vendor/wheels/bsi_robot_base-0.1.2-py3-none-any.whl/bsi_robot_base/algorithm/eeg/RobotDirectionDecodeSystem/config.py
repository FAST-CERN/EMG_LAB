"""Configuration for the robot-only classification decoder."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .contracts import DIRECTION_LABELS, ROBOT_DIRECTION_TASK_TYPE


@dataclass
class RobotDecoderConfig:
    model_dir: str
    task_type: str = ROBOT_DIRECTION_TASK_TYPE
    n_channels: int = 32
    sampling_rate: float = 500.0
    window_length: float = 0.8
    window_step: float = 0.05
    use_filter: bool = False
    use_highpass: bool = True
    use_lowpass: bool = True
    use_notch: bool = True
    selected_channels: list[int] | None = None
    filter_param_path: str = r"resource\algorithm\eeg\GaitDecodeSystem\config\filter_parameter_500hz.mat"

    @property
    def time_len(self) -> int:
        return max(1, int(round(self.window_length * self.sampling_rate)))

    @property
    def step_size(self) -> int:
        return max(1, int(round(self.window_step * self.sampling_rate)))

    @classmethod
    def from_inference_config(cls, model_dir: str, config: Mapping[str, Any]) -> "RobotDecoderConfig":
        selected = config.get("ROBOT_DEC_selected_channels")
        if isinstance(selected, str):
            selected = [int(item) for item in selected.split(",") if item.strip()]
        return cls(
            model_dir=model_dir,
            task_type=str(config.get("ROBOT_DEC_task_type", ROBOT_DIRECTION_TASK_TYPE)),
            n_channels=int(config.get("ROBOT_DEC_n_channels", 32)),
            sampling_rate=float(config.get("ROBOT_DEC_sampling_rate", 500.0)),
            window_length=float(config.get("ROBOT_DEC_window_length", 0.8)),
            window_step=float(config.get("ROBOT_DEC_window_step", 0.05)),
            use_filter=bool(config.get("ROBOT_DEC_use_filter", False)),
            use_highpass=bool(config.get("ROBOT_DEC_highpass", True)),
            use_lowpass=bool(config.get("ROBOT_DEC_lowpass", True)),
            use_notch=bool(config.get("ROBOT_DEC_notch", True)),
            selected_channels=selected,
            filter_param_path=str(config.get("ROBOT_DEC_filter_param_path", cls.filter_param_path)),
        )


@dataclass
class RobotStateMachineConfig:
    history_length: int = 5
    enter_probability: float = 0.60
    enter_frames: int = 3
    rest_frames: int = 3
    stale_timeout: float = 1.0
    command_cooldown: float = 0.0
    heartbeat_period: float = 0.5
    label_order: tuple[str, ...] = DIRECTION_LABELS

    def __post_init__(self) -> None:
        self.enter_frames = max(1, int(self.enter_frames))
        self.rest_frames = max(1, int(self.rest_frames))
        self.history_length = max(int(self.history_length), self.enter_frames, self.rest_frames)
        self.enter_probability = min(1.0, max(0.0, float(self.enter_probability)))
        self.stale_timeout = max(0.1, float(self.stale_timeout))
        self.command_cooldown = max(0.0, float(self.command_cooldown))
        self.heartbeat_period = max(0.0, float(self.heartbeat_period))

    @classmethod
    def from_inference_config(cls, config: Mapping[str, Any]) -> "RobotStateMachineConfig":
        return cls(
            history_length=max(1, int(config.get("ROBOT_SM_history_length", 5))),
            enter_probability=float(config.get("ROBOT_SM_enter_probability", 0.60)),
            enter_frames=max(1, int(config.get("ROBOT_SM_enter_frames", 3))),
            rest_frames=max(1, int(config.get("ROBOT_SM_rest_frames", 3))),
            stale_timeout=max(0.1, float(config.get("ROBOT_SM_stale_timeout", 1.0))),
            command_cooldown=max(0.0, float(config.get("ROBOT_SM_command_cooldown", 0.0))),
            heartbeat_period=max(0.0, float(config.get("ROBOT_SM_heartbeat_period", 0.5))),
        )
