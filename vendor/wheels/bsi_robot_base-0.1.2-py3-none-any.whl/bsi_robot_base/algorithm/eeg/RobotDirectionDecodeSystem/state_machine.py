"""Safe four-class command filter for humanoid robot movement."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Sequence

from .config import RobotStateMachineConfig
from .contracts import DirectionCommand, validate_probabilities


@dataclass(frozen=True)
class StateMachineResult:
    command: DirectionCommand
    reason: str
    changed: bool


class RobotDirectionStateMachine:
    """Debounces predictions; a movement command must be confirmed before it is issued or switched."""

    def __init__(self, config: RobotStateMachineConfig | None = None) -> None:
        self.config = config or RobotStateMachineConfig()
        self.reset()

    def reset(self) -> None:
        self.command = DirectionCommand.REST
        self._candidate: DirectionCommand | None = None
        self._candidate_frames = 0
        self._history: deque[DirectionCommand] = deque(maxlen=self.config.history_length)
        self._last_timestamp: float | None = None
        self._last_transition_timestamp: float | None = None

    def _can_transition(self, timestamp: float | None) -> bool:
        if self.config.command_cooldown <= 0 or timestamp is None or self._last_transition_timestamp is None:
            return True
        return timestamp - self._last_transition_timestamp >= self.config.command_cooldown

    def _transition(self, command: DirectionCommand, timestamp: float | None) -> None:
        self.command = command
        if timestamp is not None:
            self._last_transition_timestamp = timestamp

    def _set_candidate(self, candidate: DirectionCommand) -> int:
        self._candidate = candidate
        # Count only the trailing run inside the bounded history.  Thus the
        # ``history_length`` setting has a real safety effect: an observation
        # cannot remain eligible for confirmation indefinitely.
        frames = 0
        for item in reversed(self._history):
            if item != candidate:
                break
            frames += 1
        self._candidate_frames = frames
        return frames

    def update(
        self,
        raw_class: int | DirectionCommand,
        probabilities: Sequence[float],
        timestamp: float | None,
        *,
        active: bool = True,
    ) -> StateMachineResult:
        values = validate_probabilities(probabilities)
        raw = DirectionCommand.from_value(raw_class)
        self._history.append(raw)
        self._last_timestamp = timestamp
        previous = self.command

        if not active:
            self._transition(DirectionCommand.REST, timestamp)
            self._candidate = None
            self._candidate_frames = 0
            return StateMachineResult(self.command, "任务非活动段", previous != self.command)

        confidence = values[int(raw)]
        if confidence < self.config.enter_probability:
            self._candidate = None
            self._candidate_frames = 0
            return StateMachineResult(self.command, "置信度不足", False)

        frames = self._set_candidate(raw)
        if self.command == DirectionCommand.REST:
            if raw != DirectionCommand.REST and frames >= self.config.enter_frames:
                if not self._can_transition(timestamp):
                    return StateMachineResult(self.command, "命令冷却", False)
                self._transition(raw, timestamp)
                self._candidate = None
                self._candidate_frames = 0
                return StateMachineResult(self.command, "已下发", True)
            if raw == DirectionCommand.REST:
                return StateMachineResult(self.command, "休息保持", False)
            return StateMachineResult(self.command, "等待运动确认", False)

        if raw == self.command:
            return StateMachineResult(self.command, "运动保持", False)
        if raw == DirectionCommand.REST and frames >= self.config.rest_frames:
            self._transition(DirectionCommand.REST, timestamp)
            self._candidate = None
            self._candidate_frames = 0
            return StateMachineResult(self.command, "已回到休息", True)
        if raw != DirectionCommand.REST:
            if frames >= self.config.enter_frames:
                if not self._can_transition(timestamp):
                    return StateMachineResult(self.command, "命令冷却", False)
                self._transition(raw, timestamp)
                self._candidate = None
                self._candidate_frames = 0
                return StateMachineResult(self.command, "已切换", True)
            return StateMachineResult(self.command, "等待切换确认", False)
        return StateMachineResult(self.command, "等待休息确认", False)

    def stale(self, timestamp: float | None) -> StateMachineResult | None:
        if timestamp is None or self._last_timestamp is None:
            return None
        if timestamp - self._last_timestamp <= self.config.stale_timeout:
            return None
        previous = self.command
        self._transition(DirectionCommand.REST, timestamp)
        self._candidate = None
        self._candidate_frames = 0
        return StateMachineResult(self.command, "EEG超时", previous != self.command)

    def force_rest(self, reason: str = "停止") -> StateMachineResult:
        previous = self.command
        self._transition(DirectionCommand.REST, None)
        self._candidate = None
        self._candidate_frames = 0
        return StateMachineResult(self.command, reason, previous != self.command)
