"""Stable contracts shared by robot UI, recording and online decoding."""
from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Any, Mapping, Sequence


ROBOT_DIRECTION_TASK_TYPE = "ROBOT_DIRECTION_4CLASS"
ROBOT_DIRECTION_SCHEMA_VERSION = 1


class DirectionCommand(IntEnum):
    REST = 0
    LEFT = 1
    RIGHT = 2
    FORWARD = 3

    @property
    def command_name(self) -> str:
        return {
            DirectionCommand.REST: "rest",
            DirectionCommand.LEFT: "left",
            DirectionCommand.RIGHT: "right",
            DirectionCommand.FORWARD: "forward",
        }[self]

    @property
    def display_name(self) -> str:
        return {
            DirectionCommand.REST: "休息",
            DirectionCommand.LEFT: "左转",
            DirectionCommand.RIGHT: "右转",
            DirectionCommand.FORWARD: "前进",
        }[self]

    @classmethod
    def from_value(cls, value: Any) -> "DirectionCommand":
        if isinstance(value, cls):
            return value
        if isinstance(value, str):
            normalized = value.strip().lower()
            by_name = {item.command_name: item for item in cls}
            if normalized in by_name:
                return by_name[normalized]
        return cls(int(value))


DIRECTION_LABELS = tuple(item.command_name for item in DirectionCommand)
DIRECTION_DISPLAY_LABELS = tuple(item.display_name for item in DirectionCommand)


def validate_probabilities(probabilities: Sequence[float]) -> list[float]:
    values = [float(value) for value in probabilities]
    if len(values) != len(DirectionCommand):
        raise ValueError(f"机器人解码必须包含 {len(DirectionCommand)} 个类别概率，实际为 {len(values)}")
    return values


def validate_model_metadata(metadata: Mapping[str, Any]) -> None:
    task_type = metadata.get("task_type") or metadata.get("TaskType")
    n_classes = metadata.get("n_classes") or metadata.get("NClasses")
    labels = (
        metadata.get("class_labels")
        or metadata.get("class_order")
        or metadata.get("ClassLabels")
    )
    if task_type != ROBOT_DIRECTION_TASK_TYPE:
        raise ValueError(f"模型任务类型不兼容: {task_type!r}")
    if int(n_classes) != len(DirectionCommand):
        raise ValueError(f"机器人模型必须为 {len(DirectionCommand)} 分类")
    if labels is not None and list(labels) != list(DIRECTION_LABELS):
        raise ValueError(f"机器人模型类别顺序不兼容: {labels!r}")
    class_mapping = metadata.get("class_mapping")
    if class_mapping is not None:
        expected = {str(int(item)): item.command_name for item in DirectionCommand}
        normalized = {str(key): str(value) for key, value in dict(class_mapping).items()}
        if normalized != expected:
            raise ValueError(f"机器人模型类别映射不兼容: {class_mapping!r}")


@dataclass(frozen=True)
class RobotCommandEvent:
    timestamp: float | None
    raw_class: DirectionCommand
    probabilities: list[float]
    filtered_class: DirectionCommand
    reason: str
    active: bool
    sequence: int
    target_class: DirectionCommand | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "decoder_kind": "robot_direction",
            "timestamp": self.timestamp,
            "eeg_timestamp": self.timestamp,
            "raw_class": int(self.raw_class),
            "raw_command": self.raw_class.command_name,
            "probabilities": list(self.probabilities),
            "class_prob": list(self.probabilities),
            "filtered_class": int(self.filtered_class),
            "issued_command": self.filtered_class.command_name,
            "command_reason": self.reason,
            "active": self.active,
            "sequence": self.sequence,
            "target_class": int(self.target_class) if self.target_class is not None else None,
        }
