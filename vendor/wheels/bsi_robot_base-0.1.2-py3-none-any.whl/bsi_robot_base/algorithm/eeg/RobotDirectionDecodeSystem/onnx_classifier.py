"""ONNX inference for a four-class robot classifier only."""
from __future__ import annotations

import os
from pathlib import Path
import numpy as np

from .contracts import DirectionCommand


class RobotDirectionOnnxClassifier:
    def __init__(self, model_dir: str, n_channels: int, time_len: int) -> None:
        self.model_dir = Path(model_dir)
        self.n_channels = int(n_channels)
        self.time_len = int(time_len)
        self.session = None
        self.mean = None
        self.std = None

    def _find_model(self) -> Path:
        candidates = (
            self.model_dir / "onnx" / "best_classification_model.onnx",
            self.model_dir / "best_classification_model.onnx",
        )
        for candidate in candidates:
            if candidate.exists():
                return candidate
        raise FileNotFoundError(f"未找到机器人分类 ONNX 模型: {candidates[0]}")

    def load_model(self) -> None:
        try:
            import onnxruntime
        except ImportError as exc:
            raise RuntimeError("缺少 onnxruntime，无法运行机器人模型") from exc
        providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
        self.session = onnxruntime.InferenceSession(str(self._find_model()), providers=providers)

    def load_mean_std(self) -> None:
        candidates = (
            self.model_dir / "ResultData" / "mean_std.csv",
            self.model_dir / "mean_std.csv",
        )
        for candidate in candidates:
            if candidate.exists():
                arr = np.loadtxt(candidate, delimiter=",")
                arr = np.asarray(arr, dtype=np.float32)
                if arr.ndim == 1:
                    arr = arr.reshape((-1, 2))
                if arr.shape == (self.n_channels, 2):
                    self.mean = arr[:, 0].reshape((self.n_channels, 1))
                    self.std = arr[:, 1].reshape((self.n_channels, 1))
                    return
                if arr.shape == (self.n_channels * self.time_len, 2):
                    self.mean = arr[:, 0].reshape((self.n_channels, self.time_len))
                    self.std = arr[:, 1].reshape((self.n_channels, self.time_len))
                    return
                raise ValueError(f"mean_std.csv 维度不匹配: {arr.shape}")
        raise FileNotFoundError("未找到机器人模型 mean_std.csv")

    def infer(self, eeg_window: np.ndarray) -> tuple[DirectionCommand, list[float]]:
        if self.session is None or self.mean is None or self.std is None:
            raise RuntimeError("机器人 ONNX 模型尚未初始化")
        x = np.asarray(eeg_window, dtype=np.float32)
        if x.shape != (self.n_channels, self.time_len):
            raise ValueError(f"EEG 窗口维度不匹配: {x.shape}")
        x = ((x - self.mean) / (self.std + 1e-8))[None, ...]
        input_name = self.session.get_inputs()[0].name
        output = np.asarray(self.session.run(None, {input_name: x})[0], dtype=np.float32)
        if output.ndim != 2 or output.shape[1] != len(DirectionCommand):
            raise ValueError(f"机器人 ONNX 输出必须为四分类概率，实际为 {output.shape}")
        logits = output[0]
        # Training exports logits.  Convert deterministically here so every
        # consumer (UI, state machine, runtime log) receives probabilities.
        shifted = logits - np.max(logits)
        probabilities = (np.exp(shifted) / np.exp(shifted).sum()).tolist()
        return DirectionCommand(int(np.argmax(probabilities))), probabilities
