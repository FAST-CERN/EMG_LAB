"""EventBus based real-time decoder for robot-direction models."""
from __future__ import annotations

import threading
import time
from typing import Any

import numpy as np

from bsi_robot_base.algorithm.topics import (
    ROBOT_DIRECTION_COMMAND_TOPIC,
    ROBOT_DIRECTION_DECODED_TOPIC,
)
from bsi_robot_base.hardware.topics import EEG_DATA_TOPIC
from bsi_pykit_base.bus.bus_data import BusData
from bsi_pykit_base.bus.event_bus import EventBus

from .config import RobotDecoderConfig, RobotStateMachineConfig
from .contracts import DirectionCommand, RobotCommandEvent
from .onnx_classifier import RobotDirectionOnnxClassifier
from .state_machine import RobotDirectionStateMachine


class RobotDirectionDecoder:
    def __init__(
        self,
        config: RobotDecoderConfig,
        state_config: RobotStateMachineConfig | None = None,
    ) -> None:
        self.config = config
        self.state_machine = RobotDirectionStateMachine(state_config)
        self.event_bus = EventBus()
        self._model: RobotDirectionOnnxClassifier | None = None
        self._buffer: np.ndarray | None = None
        self._lock = threading.Lock()
        self._running = False
        self._initialized = False
        self._active = True
        self._gate_reason = "开放模式"
        self._samples_since_inference = 0
        self._sequence = 0
        self._target_class: DirectionCommand | None = None
        self._last_eeg_timestamp: float | None = None
        self._last_eeg_wall_time: float | None = None
        self._stale_emitted = False
        self._last_heartbeat_wall_time = 0.0
        self._stop_event = threading.Event()
        self._watchdog_thread: threading.Thread | None = None

    @property
    def running(self) -> bool:
        return self._running

    def initialize(self) -> bool:
        try:
            channels = len(self.config.selected_channels or []) or self.config.n_channels
            self._model = RobotDirectionOnnxClassifier(self.config.model_dir, channels, self.config.time_len)
            self._model.load_model()
            self._model.load_mean_std()
            self._buffer = np.zeros((channels, self.config.time_len), dtype=np.float32)
            self._initialized = True
            return True
        except Exception:
            self._initialized = False
            raise

    def start(self) -> bool:
        if not self._initialized:
            self.initialize()
        if not self._running:
            self._stop_event.clear()
            self.event_bus.subscribe(EEG_DATA_TOPIC, self.on_eeg_data)
            self._running = True
            self._watchdog_thread = threading.Thread(
                target=self._watchdog_loop,
                daemon=True,
                name="RobotDirectionEEGWatchdog",
            )
            self._watchdog_thread.start()
        return True

    def stop(self) -> bool:
        self._stop_event.set()
        if self._running:
            self.event_bus.unsubscribe(EEG_DATA_TOPIC, self.on_eeg_data)
            self._running = False
        if self._watchdog_thread is not None:
            self._watchdog_thread.join(timeout=1.0)
            self._watchdog_thread = None
        self.state_machine.force_rest("停止")
        self._publish_command(
            raw=DirectionCommand.REST,
            probabilities=[1.0, 0.0, 0.0, 0.0],
            timestamp=None,
            filtered=DirectionCommand.REST,
            reason="停止",
            active=False,
        )
        return True

    def reset(self) -> None:
        with self._lock:
            if self._buffer is not None:
                self._buffer.fill(0.0)
            self._samples_since_inference = 0
            self.state_machine.reset()

    def set_gate(self, active: bool, reason: str) -> None:
        self._active = bool(active)
        self._gate_reason = str(reason)
        if not self._active:
            result = self.state_machine.force_rest("任务非活动段")
            self._publish_command(
                raw=DirectionCommand.REST,
                probabilities=[1.0, 0.0, 0.0, 0.0],
                timestamp=None,
                filtered=result.command,
                reason=result.reason,
                active=False,
            )

    def set_target_class(self, target_class: int | DirectionCommand | None) -> None:
        self._target_class = (
            None if target_class is None else DirectionCommand.from_value(target_class)
        )

    def on_eeg_data(self, data: BusData) -> None:
        if not self._running:
            return
        payload = getattr(data, "data", {}) or {}
        samples = payload.get("data") if isinstance(payload, dict) else None
        timestamp = payload.get("timestamp") if isinstance(payload, dict) else None
        if samples is None:
            return
        eeg = np.asarray(samples, dtype=np.float32)
        if eeg.ndim != 2:
            return
        if self.config.selected_channels is not None:
            eeg = eeg[self.config.selected_channels, :]
        if self._buffer is None or eeg.shape[0] != self._buffer.shape[0]:
            return
        self._last_eeg_timestamp = timestamp
        self._last_eeg_wall_time = time.monotonic()
        self._stale_emitted = False
        with self._lock:
            count = eeg.shape[1]
            if count >= self.config.time_len:
                self._buffer[:] = eeg[:, -self.config.time_len:]
                self._samples_since_inference = self.config.step_size
            else:
                self._buffer = np.roll(self._buffer, -count, axis=1)
                self._buffer[:, -count:] = eeg
                self._samples_since_inference += count
            if self._samples_since_inference < self.config.step_size:
                return
            self._samples_since_inference = 0
            window = self._buffer.copy()
        try:
            assert self._model is not None
            raw, probabilities = self._model.infer(self._preprocess(window))
            state = self.state_machine.update(raw, probabilities, timestamp, active=self._active)
            self._publish_command(raw, probabilities, timestamp, state.command, state.reason, self._active)
        except Exception as exc:
            state = self.state_machine.force_rest("模型错误")
            self._publish_command(
                DirectionCommand.REST,
                [1.0, 0.0, 0.0, 0.0],
                timestamp,
                state.command,
                f"模型错误: {exc}",
                False,
            )

    def _watchdog_loop(self) -> None:
        """Use local monotonic time to make a stale EEG stream safe.

        Device timestamps remain the only timestamps used for decoding and
        label alignment.  They may use arbitrary epochs, so they must not be
        compared with the workstation clock for timeout detection.
        """
        poll_seconds = min(max(self.state_machine.config.stale_timeout / 4.0, 0.05), 0.25)
        while not self._stop_event.wait(poll_seconds):
            now = time.monotonic()
            if (
                self._last_eeg_wall_time is not None
                and now - self._last_eeg_wall_time >= self.state_machine.config.stale_timeout
                and not self._stale_emitted
            ):
                self._stale_emitted = True
                result = self.state_machine.force_rest("EEG超时")
                self._publish_command(
                    raw=DirectionCommand.REST,
                    probabilities=[1.0, 0.0, 0.0, 0.0],
                    timestamp=self._last_eeg_timestamp,
                    filtered=result.command,
                    reason=result.reason,
                    active=False,
                )
                continue

            # Decoded events are normal heartbeats.  This additional event
            # keeps a held movement observable even when an inference window
            # arrives slowly relative to the configured heartbeat period.
            if (
                self._last_eeg_wall_time is not None
                and self._active
                and self.state_machine.command != DirectionCommand.REST
                and now - self._last_heartbeat_wall_time >= self.state_machine.config.heartbeat_period
            ):
                command = self.state_machine.command
                self._publish_command(
                    raw=command,
                    probabilities=[1.0 if index == int(command) else 0.0 for index in range(4)],
                    timestamp=self._last_eeg_timestamp,
                    filtered=command,
                    reason="心跳",
                    active=True,
                )

    def _preprocess(self, window: np.ndarray) -> np.ndarray:
        """Apply the optional online filtering settings without touching legacy decoders."""
        if not self.config.use_filter:
            return window
        try:
            from scipy.signal import butter, iirnotch, sosfiltfilt, tf2sos

            result = np.asarray(window, dtype=np.float32).copy()
            nyquist = self.config.sampling_rate / 2.0
            if self.config.use_highpass and nyquist > 1.0:
                sos = butter(3, 1.0, btype="highpass", fs=self.config.sampling_rate, output="sos")
                result = sosfiltfilt(sos, result, axis=1)
            if self.config.use_lowpass and nyquist > 5.0:
                sos = butter(3, min(200.0, nyquist * 0.90), btype="lowpass", fs=self.config.sampling_rate, output="sos")
                result = sosfiltfilt(sos, result, axis=1)
            if self.config.use_notch and 50.0 < nyquist:
                b, a = iirnotch(50.0, 30.0, fs=self.config.sampling_rate)
                result = sosfiltfilt(tf2sos(b, a), result, axis=1)
            return result.astype(np.float32, copy=False)
        except Exception:
            # A short warm-up buffer cannot always be zero-phase filtered;
            # inference remains available and the event log still identifies
            # the active configuration.
            return window

    def _publish_command(
        self,
        raw: DirectionCommand,
        probabilities: list[float],
        timestamp: float | None,
        filtered: DirectionCommand,
        reason: str,
        active: bool,
    ) -> None:
        self._last_heartbeat_wall_time = time.monotonic()
        self._sequence += 1
        event = RobotCommandEvent(
            timestamp, raw, probabilities, filtered, reason, active, self._sequence,
            self._target_class,
        ).to_dict()
        self.event_bus.publish(ROBOT_DIRECTION_DECODED_TOPIC, data=BusData(data=event))
        self.event_bus.publish(ROBOT_DIRECTION_COMMAND_TOPIC, data=BusData(data=event))
