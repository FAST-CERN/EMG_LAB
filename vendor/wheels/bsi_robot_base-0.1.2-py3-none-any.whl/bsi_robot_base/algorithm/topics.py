"""
统一的算法结果主题常量定义
"""

# EEG data decoding result
EEG_DECODED_DATA_TOPIC = "eeg.decoded_data"

# Mujoco Feedback data
MUJOCO_FEEDBACK_DATA_TOPIC = "mujoco.feedback_data"

MUJOCO_VIBRATOR_DATA_TOPIC = "mujoco.vibrator_data"

# Mujoco / CSP 范式状态（供 NeuralSynthesizer 订阅，生成伪脑电）
# 由 BrainControlInterface.update_3D_file() / update_coarse_file() 在写标签文件时同步发布
MUJOCO_PARADIGM_STATE_TOPIC = "mujoco.paradigm_state"

# CSP-Like 解码结果数据
CSP_DECODED_DATA_TOPIC = "csp.decoded_data"

# CSP反馈（目标强度 + 解码强度）
CSP_FEEDBACK_DATA_TOPIC = "csp.feedback_data"

# 人形机器人四分类解码、最终命令和范式时间段。
# 旧 EEG/Gait 主题保持不变；机器人消费者只订阅以下主题。
ROBOT_DIRECTION_DECODED_TOPIC = "robot_direction.decoded"
ROBOT_DIRECTION_COMMAND_TOPIC = "robot_direction.command"
ROBOT_DIRECTION_PARADIGM_TOPIC = "robot_direction.paradigm"
ROBOT_DIRECTION_HARDWARE_TOPIC = "robot_direction.hardware"
