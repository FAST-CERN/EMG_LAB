"""Unitree humanoid-robot adapter: one-way UDP direction stream.

Forwards the decoded direction state (REST/LEFT/RIGHT/FORWARD) to the
robot-side receiver as JSON frames at the decoder's publish rate (~20 Hz).
Each frame is an absolute "current state" update, so a lost frame needs no
retry — the next frame supersedes it. The robot keeps executing the latest
state and rests when the stream goes silent (task end, crash, or network
loss); therefore there is no ack, heartbeat, or session signalling on
either side — the host only sends.

Wire format (provisional, pending robot-side confirmation) is isolated in
``_encode_message``: ``{"kind": "direction", "filtered_class": n}`` with
0=REST 1=LEFT 2=RIGHT 3=FORWARD.
"""
from __future__ import annotations

import json
from typing import Any, Optional

from bsi_robot_base.algorithm.topics import ROBOT_DIRECTION_COMMAND_TOPIC
from bsi_pykit_base.bus.bus_data import BusData
from bsi_pykit_base.bus.event_bus import EventBus
from bsi_pykit_base.communication.udp import UdpSender

from .humanoid_robot_adapter import HumanoidRobotAdapter


class UnitreeUdpHumanoidRobotAdapter(HumanoidRobotAdapter):
    """UDP transport for the physical Unitree robot.

    - ``robot_ip`` / ``robot_port``: destination of the robot-side receiver
      (direction frames are sent here, fire-and-forget).
    """

    def __init__(self, robot_ip: str = "", robot_port: int = 0) -> None:
        super().__init__(name="unitree_udp_robot", address=f"{robot_ip}:{robot_port}")
        self.robot_ip = str(robot_ip or "")
        self.robot_port = int(robot_port or 0)

        self._sender: Optional[UdpSender] = None
        self._event_bus = EventBus()
        self._subscribed = False

        self._send_count = 0
        self.last_error = ""

    # ---- IHardware lifecycle ---------------------------------------------

    def configure(self, **config) -> bool:
        if self.connected:
            self.last_error = "设备已连接，无法修改配置"
            return False
        self.robot_ip = str(config.get("robot_ip", config.get("ip", self.robot_ip)) or "")
        self.robot_port = int(config.get("robot_port", config.get("port", self.robot_port)) or 0)
        self.last_error = ""
        return True

    def connect(self) -> bool:
        if self.connected:
            return True
        if not self.robot_ip or self.robot_port <= 0:
            self.last_error = "未配置机器人 IP/端口"
            return False
        try:
            self._sender = UdpSender(self.robot_ip, self.robot_port)
        except Exception as exc:
            self.last_error = f"UDP 通道创建失败: {exc}"
            self._sender = None
            return False
        self.connected = True
        self.last_error = ""
        return True

    def disconnect(self) -> bool:
        self.stop()
        self.connected = False
        if self._sender is not None:
            try:
                self._sender.close()
            except Exception:
                pass
            self._sender = None
        return True

    def start(self, **args) -> bool:
        if not self.connected:
            self.connect()
        if not self.connected:
            return False
        if not self._subscribed:
            self._event_bus.subscribe(ROBOT_DIRECTION_COMMAND_TOPIC, self._on_command)
            self._subscribed = True
        return True

    def stop(self, **args) -> bool:
        if self._subscribed:
            self._event_bus.unsubscribe(ROBOT_DIRECTION_COMMAND_TOPIC, self._on_command)
            self._subscribed = False
        return True

    # ---- HumanoidRobotAdapter contract -----------------------------------

    def send_direction(self, command_event: dict[str, Any]) -> bool:
        """Forward only the decoded class; the stream itself is the session."""
        filtered = int((command_event or {}).get("filtered_class", 0) or 0)
        return self._send("direction", {"filtered_class": filtered})

    def get_status(self) -> dict[str, Any]:
        return {
            "connected": self.connected,
            "transport": "udp",
            "target": f"{self.robot_ip}:{self.robot_port}" if self.robot_port else None,
            "send_count": self._send_count,
            "last_error": self.last_error,
        }

    # ---- internal ---------------------------------------------------------

    def _send(self, kind: str, payload: dict[str, Any]) -> bool:
        sender = self._sender
        if sender is None:
            return False
        sender.send(self._encode_message(kind, payload))
        self._send_count += 1
        return True

    def _on_command(self, data: BusData) -> None:
        payload = getattr(data, "data", {}) or {}
        self.send_direction(payload)

    # Protocol isolation point: adjust here once the robot-side format is set.
    def _encode_message(self, kind: str, payload: dict[str, Any]) -> str:
        return json.dumps({"kind": kind, **payload}, ensure_ascii=False)
