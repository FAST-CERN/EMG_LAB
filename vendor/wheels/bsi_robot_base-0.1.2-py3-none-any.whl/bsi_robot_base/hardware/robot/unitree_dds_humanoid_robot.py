"""Unitree humanoid-robot adapter: DDS intent stream via ``bsi_dds``.

Publishes the decoded direction state (REST/LEFT/RIGHT/FORWARD) on the
``bsi/cmd_discrete`` DDS topic through the robot team's ``bsi_dds`` package
(CycloneDDS, domain 0). The stream shape mirrors the wire protocol: the
current intent is republished at the decoder's rate (~20 Hz, above the
required 10 Hz), best-effort, and the robot falls back to IDLE after 1 s of
silence — so the host still only sends, never receives, and there is no
ack/heartbeat/session message on either side.

``bsi_dds`` has been a declared dependency of the library since 0.1.2 (its
wheel ships with the host's ``vendor/dds`` — it is not on any public index).
``bsi_dds``/``cyclonedds`` are still imported lazily inside ``connect()`` so
importing this module never loads cyclonedds at import time; a broken
install is reported through ``last_error``.

Enum mapping (host ``DirectionCommand`` -> wire ``DiscreteCommand``) is the
safety-critical line of this adapter — the two enums do NOT share a layout:

    REST(0) -> IDLE(0)          LEFT(1)   -> TURN_LEFT(2)
    RIGHT(2) -> TURN_RIGHT(3)   FORWARD(3) -> FORWARD(1)

``confidence`` carries ``max(probabilities)`` when the decoded event provides
probabilities, else 1.0 per protocol.
"""
from __future__ import annotations

from typing import Any, Optional

from bsi_robot_base.algorithm.topics import ROBOT_DIRECTION_COMMAND_TOPIC
from bsi_pykit_base.bus.bus_data import BusData
from bsi_pykit_base.bus.event_bus import EventBus

from .humanoid_robot_adapter import HumanoidRobotAdapter

#: 宿主四分类 -> 线上枚举。两边布局不同（宿主 LEFT=1/FORWARD=3，线上
#: FORWARD=1/TURN_LEFT=2），映射错一行就是"想左转却前进"级别的事故；
#: 未知值一律落 0（IDLE，故障安全，与协议 §2 一致）。
_WIRE_COMMAND = {0: 0, 1: 2, 2: 3, 3: 1}

#: 解码事件无概率字段时的 confidence（协议规定"不用则恒 1.0"）。
_CONFIDENCE_UNUSED = 1.0


class UnitreeDdsHumanoidRobotAdapter(HumanoidRobotAdapter):
    """DDS transport for the physical Unitree robot (bsi_dds / CycloneDDS).

    - ``domain_id``: DDS domain (0 = 与 unitree SDK 同域，协议默认)。
    - ``interface``: 钉住的网卡名（"" = 自动选择）。仅在进程内首个 DDS
      participant 创建之前生效；多网卡主机发现不通时用它补救。
    """

    def __init__(self, domain_id: int = 0, interface: str = "") -> None:
        super().__init__(name="unitree_dds_robot", address=f"dds:{domain_id}")
        self.domain_id = int(domain_id or 0)
        self.interface = str(interface or "")

        self._publisher: Optional[Any] = None
        self._event_bus = EventBus()
        self._subscribed = False

        self._send_count = 0
        self.last_error = ""

    # ---- IHardware lifecycle ---------------------------------------------

    def configure(self, **config) -> bool:
        if self.connected:
            self.last_error = "设备已连接，无法修改配置"
            return False
        self.domain_id = int(config.get("domain", config.get("domain_id", self.domain_id)) or 0)
        self.interface = str(config.get("interface", self.interface) or "")
        self.last_error = ""
        return True

    def connect(self) -> bool:
        if self.connected:
            return True
        try:
            from bsi_dds.dds_io import DiscreteCommandPublisher
        except ImportError as exc:
            self.last_error = f"缺少 bsi_dds 包（机器人侧接口库）: {exc}"
            return False
        try:
            self._publisher = DiscreteCommandPublisher(
                domain_id=self.domain_id,
                interface=self.interface or None,
            )
        except Exception as exc:
            self.last_error = f"DDS 通道创建失败: {exc}"
            self._publisher = None
            return False
        self.connected = True
        self.last_error = ""
        return True

    def disconnect(self) -> bool:
        self.stop()
        self.connected = False
        if self._publisher is not None:
            try:
                self._publisher.close()
            except Exception:
                pass
            self._publisher = None
        return True

    def start(self, **args) -> bool:
        if not self.connected:
            self.connect()
        if not self.connected:
            return False
        if not self._subscribed:
            self._event_bus.subscribe(ROBOT_DIRECTION_COMMAND_TOPIC, self._on_command)
            self._subscribed = True
        return True

    def stop(self, **args) -> bool:
        if self._subscribed:
            self._event_bus.unsubscribe(ROBOT_DIRECTION_COMMAND_TOPIC, self._on_command)
            self._subscribed = False
        return True

    # ---- HumanoidRobotAdapter contract -----------------------------------

    def send_direction(self, command_event: dict[str, Any]) -> bool:
        """Map the decoded class onto the wire enum and publish one sample."""
        publisher = self._publisher
        if publisher is None:
            return False
        event = command_event or {}
        wire_command = _WIRE_COMMAND.get(int(event.get("filtered_class", 0) or 0), 0)
        probabilities = event.get("probabilities")
        try:
            confidence = float(max(probabilities)) if probabilities else _CONFIDENCE_UNUSED
        except (TypeError, ValueError):
            confidence = _CONFIDENCE_UNUSED
        try:
            publisher.publish(wire_command, confidence=confidence)
        except Exception as exc:
            # best-effort 流：发布失败不重试，下一样本自然覆盖。
            self.last_error = f"DDS 发布失败: {exc}"
            return False
        self._send_count += 1
        return True

    def get_status(self) -> dict[str, Any]:
        return {
            "connected": self.connected,
            "transport": "dds",
            "domain": self.domain_id,
            "interface": self.interface or None,
            "send_count": self._send_count,
            "last_error": self.last_error,
        }

    # ---- internal ---------------------------------------------------------

    def _on_command(self, data: BusData) -> None:
        payload = getattr(data, "data", {}) or {}
        self.send_direction(payload)
