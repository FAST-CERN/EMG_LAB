"""Stable hardware boundary for humanoid-robot adapters."""
from __future__ import annotations

from abc import abstractmethod
from typing import Any

from bsi_pykit_base.hardware.i_hardware import IHardware


class HumanoidRobotAdapter(IHardware):
    def __init__(self, name: str = "humanoid_robot", address: str = "reserved") -> None:
        super().__init__(name, address)

    @abstractmethod
    def send_direction(self, command_event: dict[str, Any]) -> bool:
        pass

    @abstractmethod
    def get_status(self) -> dict[str, Any]:
        pass
