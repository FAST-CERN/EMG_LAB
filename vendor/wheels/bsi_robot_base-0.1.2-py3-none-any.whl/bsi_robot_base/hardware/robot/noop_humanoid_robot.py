"""Non-networked placeholder used until a physical robot is available."""
from __future__ import annotations

from typing import Any

from bsi_robot_base.algorithm.topics import ROBOT_DIRECTION_COMMAND_TOPIC, ROBOT_DIRECTION_HARDWARE_TOPIC
from bsi_pykit_base.bus.bus_data import BusData
from bsi_pykit_base.bus.event_bus import EventBus

from .humanoid_robot_adapter import HumanoidRobotAdapter


class NoopHumanoidRobotAdapter(HumanoidRobotAdapter):
    def __init__(self) -> None:
        super().__init__(name="humanoid_robot_reserved", address="reserved://noop")
        self.events: list[dict[str, Any]] = []
        self._event_bus = EventBus()
        self._subscribed = False

    def configure(self, **config) -> bool:
        return True

    def connect(self) -> bool:
        self.connected = True
        return True

    def disconnect(self) -> bool:
        self.connected = False
        return True

    def start(self, **args) -> bool:
        if not self.connected:
            self.connect()
        if not self._subscribed:
            self._event_bus.subscribe(ROBOT_DIRECTION_COMMAND_TOPIC, self._on_command)
            self._subscribed = True
        return True

    def stop(self, **args) -> bool:
        if self._subscribed:
            self._event_bus.unsubscribe(ROBOT_DIRECTION_COMMAND_TOPIC, self._on_command)
            self._subscribed = False
        return True

    def send_direction(self, command_event: dict[str, Any]) -> bool:
        self.events.append({"event": "send_direction", "command": dict(command_event or {})})
        self._emit_hardware_event("send_direction", command=dict(command_event or {}))
        return True

    def get_status(self) -> dict[str, Any]:
        return {"connected": self.connected, "transport": "reserved", "event_count": len(self.events)}

    def _on_command(self, data: BusData) -> None:
        payload = getattr(data, "data", {}) or {}
        self.send_direction(payload)

    def _emit_hardware_event(self, event: str, **details: Any) -> None:
        self._event_bus.publish(
            ROBOT_DIRECTION_HARDWARE_TOPIC,
            data=BusData(data={
                "hardware_adapter": "noop_humanoid_robot",
                "hardware_event": event,
                **details,
            }),
        )
