"""
统一的硬件主题常量定义
"""

# EEG data stream
EEG_DATA_TOPIC = "eeg.data"

# EEG electrode impedance
EEG_IMPEDANCE_TOPIC = "eeg.impedance"

# EEG status check
EEG_STATUS_CHECK_TOPIC = "eeg.status.check"

# EEG SN check
EEG_SN_CHECK_TOPIC = "eeg.sn.check"

# Stimulator impedance
STIM_IMPEDANCE_TOPIC = "stim.impedance"

# Stimulator configuration
STIM_CONFIGURATION_TOPIC = "stim.configuration"
STIM_AMP_PCT_TOPIC = "stim.amplitude.percent"

# Stimulator status check
STIM_STATUS_CHECK_TOPIC = "stim.status.check"

# Stimulator SN check
STIM_SN_CHECK_TOPIC = "stim.sn.check"

# BSI heatbeat topic
BSI_HEARTBEAT_TOPIC = "bsi.heartbeat"
EEG_HEARTBEAT_TOPIC = "eeg.heartbeat"
STIM_HEARTBEAT_TOPIC = "stim.heartbeat"

# EMG data stream
EMG_DATA_TOPIC = "emg.data"

# EXOSKELETON data stream
EXOSKELETON_DATA_TOPIC = "exoskeleton.data"

# MOTION data stream
MOTION_DATA_TOPIC = "motion.data"
MOTION_FORCE_TOPIC = "motion.force"
MOTION_ANALOG_TOPIC = "motion.analog"

# INSOLE data stream
INSOLE_DATA_TOPIC = "insole.data"

# DOTs IMU data stream
DOT_IMU_DATA_TOPIC = "dot.imu.data"

__all__ = [
    "EEG_DATA_TOPIC",
    "EEG_IMPEDANCE_TOPIC",
    "STIM_IMPEDANCE_TOPIC",
    "EMG_DATA_TOPIC",
    "EXOSKELETON_DATA_TOPIC",
    "MOTION_DATA_TOPIC",
    "MOTION_FORCE_TOPIC",
    "MOTION_ANALOG_TOPIC",
    "INSOLE_DATA_TOPIC",
    "DOT_IMU_DATA_TOPIC",
]
