import pytest

# 本测试依赖宿主 ms_bci_laboratory 的 config 模块；独立打包后自动跳过，
# 宿主迁移（使用 bsi_pykit_base / bsi_robot_base）后再启用。
pytest.importorskip("config.general")
pytest.importorskip("config.mapping")

from config.general import TreatDefaultParam
from config.mapping import get_available_algorithm_types, mapping_AlgoType_to_TaskType


def test_humanoid_robot_mapping_is_explicit_and_does_not_reindex_old_types():
    robot_type = TreatDefaultParam.TREAT_TYPE[7]
    robot_algorithm = TreatDefaultParam.ALGORITHM_TYPE7[0]
    assert get_available_algorithm_types(robot_type) == [robot_algorithm]
    assert mapping_AlgoType_to_TaskType(robot_type, robot_algorithm) == "ROBOT_DIRECTION_4CLASS"
