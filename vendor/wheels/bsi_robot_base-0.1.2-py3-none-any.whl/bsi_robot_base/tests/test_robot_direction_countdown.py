"""Countdown cue tests: runtime digit textures, injected scene XML, presenter planes."""
import importlib.resources
from pathlib import Path

import pytest

from bsi_robot_base.simulator.robot_direction.command import DirectionCommand

_ASSETS = Path(str(importlib.resources.files("bsi_robot_base.simulator.robot_direction"))) / "assets"
_SCENE_XML = _ASSETS / "model" / "scene_direction_labelling.xml"


# ---------------------------------------------------------------- 贴图生成


def test_countdown_digits_set():
    from bsi_robot_base.simulator.robot_direction.countdown_textures import countdown_digits

    assert countdown_digits(3.0) == [0, 1, 2, 3]
    assert countdown_digits(2.5) == [0, 1, 2, 3]  # ceil(2.5) == 3
    assert countdown_digits(0.5) == [0, 1]
    assert countdown_digits(0.0) == [0]
    assert countdown_digits(-1.0) == [0]


def test_render_countdown_badge_is_opaque_rgba():
    from bsi_robot_base.simulator.robot_direction.countdown_textures import render_countdown_badge

    image = render_countdown_badge(3)
    assert image.mode == "RGBA"
    assert image.size[0] > 0 and image.size[1] > 0
    alpha = image.getchannel("A")
    assert alpha.getextrema() == (0, 255)  # 有透明背景和不透明内容
    assert sum(1 for value in alpha.getdata() if value > 128) > 100  # 数字主体非空

    wide = render_countdown_badge(10)
    assert wide.size[0] > image.size[0]  # 两位数更宽


def test_generate_countdown_textures_writes_pngs(tmp_path):
    from bsi_robot_base.simulator.robot_direction.countdown_textures import generate_countdown_textures

    paths = generate_countdown_textures([1, 2, 3], tmp_path)
    assert {digit: path.is_file() for digit, path in paths.items()} == {1: True, 2: True, 3: True}


# ---------------------------------------------------------------- 场景注入


def test_build_countdown_scene_xml_loads_with_digits(tmp_path):
    pytest.importorskip("mujoco")
    import mujoco

    from bsi_robot_base.simulator.robot_direction.countdown_textures import (
        build_countdown_scene_xml,
        generate_countdown_textures,
    )

    tex_dir = tmp_path / "textures"
    generate_countdown_textures([0, 1, 2, 3], tex_dir)
    countdown_xml = tmp_path / "scene_countdown.xml"
    build_countdown_scene_xml(_SCENE_XML, [0, 1, 2, 3], tex_dir, countdown_xml)

    model = mujoco.MjModel.from_xml_path(str(countdown_xml))
    # 数字材质/纹理注入成功
    assert model.mat("countdown_3_mat").id >= 0
    assert model.tex("countdown_3").id >= 0
    # 原有提示材质不受影响
    assert model.mat("cue_forward_mat").id >= 0
    assert model.tex("cue_forward").id >= 0


def test_build_countdown_scene_xml_keeps_relative_assets_resolvable(tmp_path):
    """临时 XML 里所有 file= 都改写为绝对路径，mesh/include 依然可解析。"""
    pytest.importorskip("mujoco")
    import mujoco

    from bsi_robot_base.simulator.robot_direction.countdown_textures import (
        build_countdown_scene_xml,
        generate_countdown_textures,
    )

    generate_countdown_textures([1], tmp_path / "textures")
    countdown_xml = tmp_path / "scene_countdown.xml"
    build_countdown_scene_xml(_SCENE_XML, [1], tmp_path / "textures", countdown_xml)
    model = mujoco.MjModel.from_xml_path(str(countdown_xml))
    assert model.mesh("ground_cue_forward").id >= 0
    assert model.nu > 0  # g1 模型 include 链正常


# ---------------------------------------------------------------- 渲染平面


@pytest.fixture(scope="module")
def countdown_model_and_data():
    pytest.importorskip("mujoco")
    import mujoco
    import shutil
    import tempfile

    from bsi_robot_base.simulator.robot_direction.countdown_textures import (
        build_countdown_scene_xml,
        generate_countdown_textures,
    )

    work = Path(tempfile.mkdtemp(prefix="bsi_test_countdown_"))
    try:
        tex_dir = work / "textures"
        generate_countdown_textures([0, 1, 2, 3], tex_dir)
        countdown_xml = work / "scene_countdown.xml"
        build_countdown_scene_xml(_SCENE_XML, [0, 1, 2, 3], tex_dir, countdown_xml)
        model = mujoco.MjModel.from_xml_path(str(countdown_xml))
        data = mujoco.MjData(model)
        try:
            mujoco.mj_resetDataKeyframe(model, data, model.key("knees_bent").id)
        except KeyError:
            mujoco.mj_resetData(model, data)
        mujoco.mj_forward(model, data)
        yield model, data
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _viewer(model):
    import mujoco

    class Viewer:
        user_scn = mujoco.MjvScene(model, 16)
        cam = mujoco.MjvCamera()

    return Viewer()


def test_presenter_draws_countdown_plane_next_to_text(countdown_model_and_data):
    import numpy as np

    from bsi_robot_base.simulator.robot_direction.ground_cue_presenter import GroundCuePresenter

    model, data = countdown_model_and_data
    viewer = _viewer(model)
    presenter = GroundCuePresenter(model)

    # 准备阶段：文字提示 + 右侧倒计时数字，两个平面
    presenter.update(viewer, viewer.cam, data, DirectionCommand.FORWARD, active=False, countdown=3)
    assert viewer.user_scn.ngeom == 2
    assert viewer.user_scn.geoms[0].matid == model.mat("cue_forward_mat").id
    assert viewer.user_scn.geoms[1].matid == model.mat("countdown_3_mat").id
    # 数字平面与文字平面同一高度、紧贴文字右侧（无间隔）
    cue_tex_id = model.tex("cue_forward").id
    text_half_h = 0.45 * int(model.tex_height[cue_tex_id]) / int(model.tex_width[cue_tex_id])
    assert viewer.user_scn.geoms[1].pos[2] == pytest.approx(viewer.user_scn.geoms[0].pos[2])
    assert viewer.user_scn.geoms[1].size[1] == pytest.approx(text_half_h)  # 徽章高度一致
    cd_tex_id = model.tex("countdown_3").id
    half_w = text_half_h * int(model.tex_width[cd_tex_id]) / int(model.tex_height[cd_tex_id])
    separation = np.hypot(
        viewer.user_scn.geoms[1].pos[0] - viewer.user_scn.geoms[0].pos[0],
        viewer.user_scn.geoms[1].pos[1] - viewer.user_scn.geoms[0].pos[1],
    )
    # 中心距 = 文字半宽 + 数字半宽（两个徽章背景紧贴，无间隔）
    assert separation == pytest.approx(0.45 + half_w)
    # 方向：默认相机（azimuth=0）下镜头右侧 = 世界 -y（离屏渲染实测约定），
    # 数字必须位于提示文字右侧
    assert viewer.user_scn.geoms[1].pos[1] < viewer.user_scn.geoms[0].pos[1]

    # 活动阶段 + 0 闪烁：地面箭头 + 数字 0
    presenter.update(viewer, viewer.cam, data, DirectionCommand.FORWARD, active=True, countdown=0)
    assert viewer.user_scn.ngeom == 2
    assert viewer.user_scn.geoms[0].dataid == 2 * model.mesh("ground_cue_forward").id
    assert viewer.user_scn.geoms[1].matid == model.mat("countdown_0_mat").id

    # 无倒计时时保持原有行为：准备 1 个平面 / 活动 1 个箭头 / 无提示 0 个
    presenter.update(viewer, viewer.cam, data, DirectionCommand.FORWARD, active=False)
    assert viewer.user_scn.ngeom == 1
    presenter.update(viewer, viewer.cam, data, DirectionCommand.FORWARD, active=True)
    assert viewer.user_scn.ngeom == 1
    presenter.update(viewer, viewer.cam, data, None, active=False, countdown=3)
    assert viewer.user_scn.ngeom == 0


def test_presenter_skips_countdown_when_textures_absent():
    """未注入数字贴图的场景：传了 countdown 也不崩、不画数字平面。"""
    pytest.importorskip("mujoco")
    import mujoco

    from bsi_robot_base.simulator.robot_direction.ground_cue_presenter import GroundCuePresenter

    model = mujoco.MjModel.from_xml_path(str(_SCENE_XML))
    data = mujoco.MjData(model)
    try:
        mujoco.mj_resetDataKeyframe(model, data, model.key("knees_bent").id)
    except KeyError:
        mujoco.mj_resetData(model, data)
    mujoco.mj_forward(model, data)
    viewer = _viewer(model)
    presenter = GroundCuePresenter(model)

    presenter.update(viewer, viewer.cam, data, DirectionCommand.FORWARD, active=False, countdown=3)
    assert viewer.user_scn.ngeom == 1  # 只有文字平面，数字被跳过


# ---------------------------------------------------------------- 运行时逐秒倒计时


class _FakeRenderer:
    """Record-only stand-in for MujocoClipRenderer (no GL)."""

    def __init__(self) -> None:
        self.calls: list[tuple] = []
        self.countdown_seconds = 0.0

    def set_open_mode(self, enabled: bool) -> None:
        self.calls.append(("set_open_mode", enabled))

    def set_countdown_seconds(self, seconds: float) -> None:
        self.countdown_seconds = seconds
        self.calls.append(("set_countdown_seconds", seconds))

    def start(self) -> bool:
        self.calls.append(("start",))
        return True

    def stop(self) -> bool:
        self.calls.append(("stop",))
        return True

    def set_command(self, command) -> None:
        self.calls.append(("set_command", command))

    def set_trial_cue(self, cue, *, active: bool, countdown=None) -> None:
        self.calls.append(("set_trial_cue", cue, active, countdown))


def _run_runtime(preparation_seconds: float) -> list[tuple]:
    from bsi_robot_base.simulator.robot_direction.runtime import RobotDirectionRuntime

    renderer = _FakeRenderer()
    runtime = RobotDirectionRuntime(
        mode="sample",
        trial_count=1,
        trial_sequence=[DirectionCommand.FORWARD],
        preparation_seconds=preparation_seconds,
        active_seconds=0.05,
        renderer=renderer,
    )
    runtime.start()
    if runtime._thread is not None:
        runtime._thread.join(timeout=10)
    cues = [
        (call[1], call[2], call[3])
        for call in renderer.calls
        if call[0] == "set_trial_cue"
    ]
    runtime.stop()
    return cues


def test_runtime_ticks_countdown_each_second():
    cues = _run_runtime(preparation_seconds=2.2)
    # start() 清屏 -> 3,2 逐秒倒数 -> 最后 0.3s 显示 0 -> 动作开始（文字与倒计时同帧消失）
    assert cues == [
        (None, False, None),
        (DirectionCommand.FORWARD, False, 3),
        (DirectionCommand.FORWARD, False, 2),
        (DirectionCommand.FORWARD, False, 0),
        (DirectionCommand.FORWARD, True, None),
        (None, False, None),
        (None, False, None),
    ]


def test_runtime_without_countdown_keeps_old_behavior():
    cues = _run_runtime(preparation_seconds=0.0)
    assert cues == [
        (None, False, None),
        (DirectionCommand.FORWARD, False, None),
        (DirectionCommand.FORWARD, True, None),
        (None, False, None),
        (None, False, None),
    ]


def test_runtime_countdown_fractional_seconds():
    cues = _run_runtime(preparation_seconds=0.5)
    # ceil(0.5) == 1：1 短暂显示后进入 0 段，然后动作开始
    assert cues == [
        (None, False, None),
        (DirectionCommand.FORWARD, False, 1),
        (DirectionCommand.FORWARD, False, 0),
        (DirectionCommand.FORWARD, True, None),
        (None, False, None),
        (None, False, None),
    ]
