"""Regression test for continuous virtual-robot clip switching."""
import importlib.resources
from pathlib import Path

import pytest

pytest.importorskip("mujoco")

import mujoco
import numpy as np

from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.contracts import DirectionCommand
from bsi_robot_base.simulator.robot_direction.kinematic_tracker import KinematicTracker
from bsi_robot_base.simulator.robot_direction.motion_blender import ClipBlender
from bsi_robot_base.simulator.robot_direction.motion_clips import ClipLibrary

_ASSETS = Path(str(importlib.resources.files("bsi_robot_base.simulator.robot_direction"))) / "assets"


def test_motion_switches_without_restarting_or_teleporting_the_root():
    assets = _ASSETS
    model = mujoco.MjModel.from_xml_path(str(assets / "model" / "scene_direction_labelling.xml"))
    model.opt.gravity[:] = 0.0
    model.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_CONTACT)
    data = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(model, data, model.key("knees_bent").id)
    mujoco.mj_forward(model, data)

    library = ClipLibrary.load(assets / "recordings")
    library.assert_model_compatible(model.actuator(index).name for index in range(model.nu))
    blender = ClipBlender(library)
    tracker = KinematicTracker(mujoco, model, library.joint_names)
    tracker.reset(data)

    for _ in range(100):
        target = blender.update(DirectionCommand.FORWARD, 0.02)
        tracker.apply(data, target.joint_qpos, target.root_z_offset, target.root_roll, target.root_pitch, target.root_velocity_local, 0.02)
    before = data.qpos.copy()
    target = blender.update(DirectionCommand.LEFT, 0.02)
    tracker.apply(data, target.joint_qpos, target.root_z_offset, target.root_roll, target.root_pitch, target.root_velocity_local, 0.02)

    direct_switch = np.max(np.abs(library.clips["turn_left"].sample(blender.phase_s) - before[7:]))
    blended_switch = np.max(np.abs(data.qpos[7:] - before[7:]))
    assert before[0] > 1.0  # walking accumulated continuous root motion
    assert np.allclose(data.qpos[:2], before[:2])  # a turn never teleports translation
    assert blended_switch < direct_switch
    assert np.isfinite(data.qpos).all()


def test_all_four_robot_commands_keep_a_continuous_grounded_kinematic_pose():
    assets = _ASSETS
    model = mujoco.MjModel.from_xml_path(str(assets / "model" / "scene_direction_labelling.xml"))
    model.opt.gravity[:] = 0.0
    model.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_CONTACT)
    library = ClipLibrary.load(assets / "recordings")

    for command in DirectionCommand:
        data = mujoco.MjData(model)
        mujoco.mj_resetDataKeyframe(model, data, model.key("knees_bent").id)
        mujoco.mj_forward(model, data)
        blender = ClipBlender(library)
        tracker = KinematicTracker(mujoco, model, library.joint_names)
        tracker.reset(data)
        for _ in range(100):
            target = blender.update(command, 0.02)
            tracker.apply(data, target.joint_qpos, target.root_z_offset, target.root_roll, target.root_pitch, target.root_velocity_local, 0.02)
        lowest = min(
            _foot_lowest_z(model, data, "left_foot"),
            _foot_lowest_z(model, data, "right_foot"),
        )
        assert -1e-9 <= lowest <= 0.01
        assert np.isfinite(data.qpos).all()


def _foot_lowest_z(model, data, name: str) -> float:
    geom_id = model.geom(name).id
    rotation = data.geom_xmat[geom_id].reshape(3, 3)
    return float(data.geom_xpos[geom_id, 2] - np.sum(np.abs(rotation[2]) * model.geom_size[geom_id]))
