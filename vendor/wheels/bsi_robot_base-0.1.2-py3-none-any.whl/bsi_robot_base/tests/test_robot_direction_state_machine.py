from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.config import RobotStateMachineConfig
from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.contracts import DirectionCommand
from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.state_machine import RobotDirectionStateMachine


def _probability(command: DirectionCommand):
    values = [0.01] * 4
    values[int(command)] = 0.97
    return values


def test_direction_switch_requires_rest_between_directions():
    machine = RobotDirectionStateMachine(
        RobotStateMachineConfig(enter_probability=0.6, enter_frames=2, rest_frames=2)
    )
    machine.update(DirectionCommand.FORWARD, _probability(DirectionCommand.FORWARD), 1.0)
    assert machine.update(DirectionCommand.FORWARD, _probability(DirectionCommand.FORWARD), 2.0).command == DirectionCommand.FORWARD
    assert machine.update(DirectionCommand.LEFT, _probability(DirectionCommand.LEFT), 3.0).command == DirectionCommand.FORWARD
    assert machine.update(DirectionCommand.REST, _probability(DirectionCommand.REST), 4.0).command == DirectionCommand.FORWARD
    assert machine.update(DirectionCommand.REST, _probability(DirectionCommand.REST), 5.0).command == DirectionCommand.REST
    machine.update(DirectionCommand.LEFT, _probability(DirectionCommand.LEFT), 6.0)
    assert machine.update(DirectionCommand.LEFT, _probability(DirectionCommand.LEFT), 7.0).command == DirectionCommand.LEFT


def test_history_window_is_large_enough_for_confirmation():
    config = RobotStateMachineConfig(history_length=1, enter_frames=3, rest_frames=2)
    assert config.history_length == 3
    machine = RobotDirectionStateMachine(config)
    machine.update(DirectionCommand.RIGHT, _probability(DirectionCommand.RIGHT), 1.0)
    machine.update(DirectionCommand.RIGHT, _probability(DirectionCommand.RIGHT), 2.0)
    assert machine.update(DirectionCommand.RIGHT, _probability(DirectionCommand.RIGHT), 3.0).command == DirectionCommand.RIGHT
