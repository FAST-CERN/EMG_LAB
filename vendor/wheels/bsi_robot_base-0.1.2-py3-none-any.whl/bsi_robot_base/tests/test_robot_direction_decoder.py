import threading
import time

from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.config import (
    RobotDecoderConfig,
    RobotStateMachineConfig,
)
from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.contracts import DirectionCommand
from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.robot_direction_decoder import (
    RobotDirectionDecoder,
)
from bsi_robot_base.algorithm.topics import ROBOT_DIRECTION_COMMAND_TOPIC
from bsi_pykit_base.bus.event_bus import EventBus


def test_decoder_watchdog_forces_rest_when_eeg_becomes_stale():
    decoder = RobotDirectionDecoder(
        RobotDecoderConfig(model_dir="unused"),
        RobotStateMachineConfig(stale_timeout=0.1, heartbeat_period=1.0),
    )
    decoder._running = True
    decoder.state_machine.command = DirectionCommand.FORWARD
    decoder._last_eeg_timestamp = 100.0
    decoder._last_eeg_wall_time = time.monotonic() - 1.0
    received = []
    delivered = threading.Event()

    def listener(data):
        received.append(data.data)
        delivered.set()

    EventBus.subscribe(ROBOT_DIRECTION_COMMAND_TOPIC, listener)
    worker = threading.Thread(target=decoder._watchdog_loop, daemon=True)
    worker.start()
    try:
        assert delivered.wait(1.0)
        assert received[-1]["filtered_class"] == 0
        assert received[-1]["issued_command"] == "rest"
        assert received[-1]["command_reason"] == "EEG超时"
    finally:
        decoder._stop_event.set()
        worker.join(timeout=1.0)
        EventBus.unsubscribe(ROBOT_DIRECTION_COMMAND_TOPIC, listener)
