"""Headless validation of scene visuals migrated from direction_labelling_demo."""
import importlib.resources
from pathlib import Path

import pytest

pytest.importorskip("mujoco")

import mujoco
import numpy as np

from bsi_robot_base.simulator.robot_direction.camera import CameraController, CameraPreset
from bsi_robot_base.simulator.robot_direction.coin_presenter import CoinPresenter
from bsi_robot_base.simulator.robot_direction.command import DirectionCommand
from bsi_robot_base.simulator.robot_direction.ground_cue_presenter import GroundCuePresenter
from bsi_robot_base.simulator.robot_direction.open_mode import OpenSession, coin_is_visible_in_chase_camera

_ASSETS = Path(str(importlib.resources.files("bsi_robot_base.simulator.robot_direction"))) / "assets"


def test_robot_scene_keeps_demo_camera_cue_and_open_coin():
    model = mujoco.MjModel.from_xml_path(
        str(_ASSETS / "model" / "scene_direction_labelling.xml")
    )
    data = mujoco.MjData(model)
    mujoco.mj_resetDataKeyframe(model, data, model.key("knees_bent").id)
    mujoco.mj_forward(model, data)

    class Viewer:
        user_scn = mujoco.MjvScene(model, 16)
        cam = mujoco.MjvCamera()

    viewer = Viewer()
    presenter = GroundCuePresenter(model)
    presenter.update(viewer, viewer.cam, data, DirectionCommand.FORWARD, active=True)
    assert viewer.user_scn.ngeom == 1
    assert viewer.user_scn.geoms[0].dataid == 2 * model.mesh("ground_cue_forward").id
    # 准备阶段（active=False 但 cue 有值）现在画文字贴图平面，而不是什么都不画
    presenter.update(viewer, viewer.cam, data, DirectionCommand.FORWARD, active=False)
    assert viewer.user_scn.ngeom == 1
    assert viewer.user_scn.geoms[0].matid == model.mat("cue_forward_mat").id
    # complete 阶段（cue=None）不画任何东西
    presenter.update(viewer, viewer.cam, data, None, active=False)
    assert viewer.user_scn.ngeom == 0

    camera = mujoco.MjvCamera()
    CameraController(CameraPreset.THIRD_PERSON).update(camera, data.qpos, 0.02)
    np.testing.assert_allclose(camera.distance, 2.5)
    np.testing.assert_allclose(camera.elevation, -20.0)

    open_session = OpenSession()
    coin_xy = open_session.start_trial(data.qpos)
    assert coin_is_visible_in_chase_camera(coin_xy, data.qpos[:2], 0.0)
    CoinPresenter(model).update(mujoco, model, data, coin_xy, 0.0)
