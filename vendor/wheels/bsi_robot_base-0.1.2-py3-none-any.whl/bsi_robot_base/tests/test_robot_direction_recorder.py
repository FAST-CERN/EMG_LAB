import csv
import json

from bsi_robot_base.algorithm.topics import ROBOT_DIRECTION_COMMAND_TOPIC, ROBOT_DIRECTION_PARADIGM_TOPIC
from bsi_robot_base.data_process.robot_direction_recorder import RobotDirectionRecorder
from bsi_robot_base.hardware.topics import EEG_DATA_TOPIC
from bsi_pykit_base.bus.bus_data import BusData
from bsi_pykit_base.bus.event_bus import EventBus


def test_recorder_uses_eeg_time_for_trainable_intervals(tmp_path):
    recorder = RobotDirectionRecorder(
        str(tmp_path), mode="sample", virtual_robot_enabled=True, physical_robot_enabled=False
    )
    recorder.start()
    bus = EventBus()
    bus.publish(EEG_DATA_TOPIC, data=BusData(data={"timestamp": 100.0}))
    bus.publish(ROBOT_DIRECTION_PARADIGM_TOPIC, data=BusData(data={
        "event": "segment", "segment_id": "1", "phase": "active", "cue_class": 3,
        "cue_name": "forward", "trial_index": 0, "trainable": True, "duration_seconds": 2.0,
    }))
    bus.publish(ROBOT_DIRECTION_COMMAND_TOPIC, data=BusData(data={
        "raw_class": 3, "class_prob": [0.0, 0.0, 0.0, 1.0], "filtered_class": 3,
        "issued_command": "forward",
    }))
    recorder.stop()

    with (tmp_path / "Annotation" / "robot_direction_labels.csv").open(encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert rows[0]["cue_class"] == "3"
    assert rows[0]["cue_name"] == "forward"
    assert float(rows[0]["start_eeg_timestamp"]) == 98.0
    assert float(rows[0]["end_eeg_timestamp"]) == 100.0
    runtime = (tmp_path / "Annotation" / "robot_direction_runtime.jsonl").read_text(encoding="utf-8")
    assert json.loads(runtime)["issued_command"] == "forward"
