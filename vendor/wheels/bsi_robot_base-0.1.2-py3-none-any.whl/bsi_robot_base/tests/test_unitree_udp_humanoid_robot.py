"""Tests for the Unitree UDP humanoid-robot adapter (loopback only, no robot)."""
from __future__ import annotations

import json
import socket
import time

from bsi_pykit_base.communication.udp import UdpReceiver

from bsi_robot_base.hardware.robot.unitree_udp_humanoid_robot import (
    UnitreeUdpHumanoidRobotAdapter,
)


def _free_port() -> int:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()
    return port


def _make_adapter() -> UnitreeUdpHumanoidRobotAdapter:
    return UnitreeUdpHumanoidRobotAdapter(
        robot_ip="127.0.0.1",
        robot_port=_free_port(),
    )


def test_udp_adapter_sends_minimal_direction_frame():
    adapter = _make_adapter()
    received: list[str] = []
    recv = UdpReceiver(local_port=adapter.robot_port, on_frame=lambda frame, port: received.append(frame))
    recv.start()
    try:
        assert adapter.connect() is True
        assert adapter.connected is True
        assert adapter.get_status()["transport"] == "udp"

        ok = adapter.send_direction(
            {"filtered_class": 3, "issued_command": "forward", "active": True, "sequence": 1}
        )
        assert ok is True
        time.sleep(0.3)

        assert len(received) >= 1
        message = json.loads(received[0])
        # 线上只保留状态字段，其余解码器字段不出上位机
        assert message == {"kind": "direction", "filtered_class": 3}
        assert adapter.get_status()["send_count"] >= 1
    finally:
        recv.stop()
        adapter.disconnect()


def test_udp_adapter_requires_configuration():
    adapter = UnitreeUdpHumanoidRobotAdapter()
    assert adapter.connect() is False
    assert adapter.last_error  # 未配置 IP/端口


def test_udp_adapter_start_stop_send_nothing():
    """流的起止就是会话的起止：start/stop 只做订阅退订，不发任何帧。"""
    adapter = _make_adapter()
    received: list[str] = []
    recv = UdpReceiver(local_port=adapter.robot_port, on_frame=lambda frame, port: received.append(frame))
    recv.start()
    try:
        assert adapter.connect() is True
        assert adapter.start() is True
        time.sleep(0.2)
        assert received == []
        assert adapter.stop() is True
        time.sleep(0.2)
        assert received == []
        assert adapter.get_status()["send_count"] == 0
    finally:
        recv.stop()
        adapter.disconnect()
