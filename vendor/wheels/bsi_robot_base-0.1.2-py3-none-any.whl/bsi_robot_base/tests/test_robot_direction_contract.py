import importlib.resources
import json

import pytest

from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.contracts import (
    DIRECTION_LABELS,
    DirectionCommand,
    ROBOT_DIRECTION_TASK_TYPE,
    validate_model_metadata,
)
from bsi_robot_base.hardware.robot.noop_humanoid_robot import NoopHumanoidRobotAdapter
from bsi_robot_base.simulator.robot_direction.paradigm_scheduler import ParadigmScheduler


def test_robot_direction_label_contract_is_fixed():
    assert list(DIRECTION_LABELS) == ["rest", "left", "right", "forward"]
    assert [int(item) for item in DirectionCommand] == [0, 1, 2, 3]


def test_robot_metadata_rejects_wrong_order():
    valid = {
        "task_type": ROBOT_DIRECTION_TASK_TYPE,
        "n_classes": 4,
        "class_order": ["rest", "left", "right", "forward"],
    }
    validate_model_metadata(valid)
    valid["class_order"] = ["rest", "right", "left", "forward"]
    with pytest.raises(ValueError):
        validate_model_metadata(valid)


def test_noop_humanoid_adapter_is_startable_without_network():
    adapter = NoopHumanoidRobotAdapter()
    assert adapter.start() is True
    assert adapter.send_direction({"issued_command": "forward"}) is True
    assert adapter.stop() is True
    assert [item["event"] for item in adapter.events] == ["send_direction"]


def test_virtual_robot_assets_are_local_and_schedule_all_four_classes():
    root = importlib.resources.files("bsi_robot_base.simulator.robot_direction")
    manifest = json.loads((root / "assets_manifest.json").read_text(encoding="utf-8"))
    assert manifest["assets"]
    assert (root / "assets" / "model" / "scene_direction_labelling.xml").is_file()
    schedule = ParadigmScheduler(seed=1).build_balanced(8)
    assert set(schedule) == set(DirectionCommand)
