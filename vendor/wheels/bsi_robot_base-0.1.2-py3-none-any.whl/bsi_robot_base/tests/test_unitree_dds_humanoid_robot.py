"""Tests for the Unitree DDS humanoid-robot adapter (loopback only, no robot).

需要环境中已安装机器人侧的 bsi_dds 包（含 cyclonedds）；未安装时整文件
跳过，不影响库的其余测试。
"""
from __future__ import annotations

import time

import pytest

pytest.importorskip("bsi_dds")

from bsi_dds.dds_io import DiscreteCommandSubscriber
from bsi_dds.idl import DiscreteCommand

from bsi_robot_base.hardware.robot.unitree_dds_humanoid_robot import (
    UnitreeDdsHumanoidRobotAdapter,
)


@pytest.fixture()
def pair():
    adapter = UnitreeDdsHumanoidRobotAdapter()
    sub = DiscreteCommandSubscriber()
    assert adapter.connect() is True
    assert adapter.connected is True
    time.sleep(0.5)  # let discovery settle
    yield adapter, sub
    adapter.disconnect()
    sub.close()


def _drain_until(sub, expected, timeout=2.0):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if sub.poll() == expected:
            return True
        time.sleep(0.02)
    return False


def test_dds_adapter_maps_host_classes_onto_wire_enum(pair):
    """宿主 filtered_class -> 线上枚举。两边布局不同，错一行就是安全事故。"""
    adapter, sub = pair
    cases = [
        ({"filtered_class": 0}, DiscreteCommand.IDLE),
        ({"filtered_class": 1}, DiscreteCommand.TURN_LEFT),
        ({"filtered_class": 2}, DiscreteCommand.TURN_RIGHT),
        ({"filtered_class": 3}, DiscreteCommand.FORWARD),
        ({"filtered_class": 99}, DiscreteCommand.IDLE),  # 未知值 fail-safe
    ]
    for event, expected in cases:
        assert adapter.send_direction(event) is True
        assert _drain_until(sub, expected), (
            f"filtered_class={event['filtered_class']} 应映射为 {expected}"
        )
    assert adapter.get_status()["transport"] == "dds"
    assert adapter.get_status()["send_count"] == len(cases)


def test_dds_adapter_publishes_max_probability_as_confidence(pair):
    adapter, sub = pair
    assert adapter.send_direction(
        {"filtered_class": 1, "probabilities": [0.2, 0.7, 0.05, 0.05]}
    ) is True
    deadline = time.monotonic() + 2.0
    while time.monotonic() < deadline:
        sub.poll()
        sample = sub.last_sample
        if sample is not None and sample.command == DiscreteCommand.TURN_LEFT:
            # confidence 在线上是 float32，按容差比较
            assert sample.confidence == pytest.approx(0.7, abs=1e-6)
            break
        time.sleep(0.02)
    else:
        pytest.fail("未收到 TURN_LEFT 样本")


def test_dds_adapter_start_stop_only_subscribes(pair):
    """流的起止就是会话的起止：start/stop 只做订阅退订，不发任何样本。"""
    adapter, sub = pair
    assert adapter.start() is True
    assert adapter.stop() is True
    assert adapter.get_status()["send_count"] == 0
