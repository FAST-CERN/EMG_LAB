"""bsi_robot_base: 人形机器人四分类脑电解码 / 虚拟演示子系统。

依赖基础库 bsi_pykit_base（事件总线 EventBus/BusData、硬件接口 IHardware）。
本包自包含主题常量与全部资源，作为独立 wheel 安装使用。

公共 API:
    - RobotDirectionDecoder / RobotDecoderConfig / RobotStateMachineConfig: 实时脑电解码
    - RobotDirectionRecorder: 标签与运行事件记录
    - RobotDirectionRuntime / RobotDirectionSessionController: 虚拟机器人运行期
    - HumanoidRobotAdapter / NoopHumanoidRobotAdapter: 机器人硬件适配（占位）
    - UnitreeDdsHumanoidRobotAdapter: 宇树机器人 DDS 硬件适配（bsi_dds 四态意图流）
    - DirectionCommand / ROBOT_DIRECTION_TASK_TYPE / DIRECTION_LABELS: 契约常量
"""

from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.config import (
    RobotDecoderConfig,
    RobotStateMachineConfig,
)
from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.contracts import (
    DIRECTION_LABELS,
    ROBOT_DIRECTION_SCHEMA_VERSION,
    ROBOT_DIRECTION_TASK_TYPE,
    DirectionCommand,
    RobotCommandEvent,
    validate_model_metadata,
    validate_probabilities,
)
from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.robot_direction_decoder import (
    RobotDirectionDecoder,
)
from bsi_robot_base.data_process.robot_direction_recorder import RobotDirectionRecorder
from bsi_robot_base.hardware.robot.humanoid_robot_adapter import HumanoidRobotAdapter
from bsi_robot_base.hardware.robot.noop_humanoid_robot import NoopHumanoidRobotAdapter
from bsi_robot_base.hardware.robot.unitree_dds_humanoid_robot import (
    UnitreeDdsHumanoidRobotAdapter,
)
from bsi_robot_base.simulator.robot_direction.runtime import RobotDirectionRuntime
from bsi_robot_base.simulator.robot_direction.session_controller import (
    RobotDirectionSessionController,
)

__version__ = "0.1.2"

__all__ = [
    "RobotDirectionDecoder",
    "RobotDecoderConfig",
    "RobotStateMachineConfig",
    "RobotDirectionRecorder",
    "RobotDirectionRuntime",
    "RobotDirectionSessionController",
    "HumanoidRobotAdapter",
    "NoopHumanoidRobotAdapter",
    "UnitreeDdsHumanoidRobotAdapter",
    "DirectionCommand",
    "ROBOT_DIRECTION_TASK_TYPE",
    "ROBOT_DIRECTION_SCHEMA_VERSION",
    "DIRECTION_LABELS",
    "RobotCommandEvent",
    "validate_model_metadata",
    "validate_probabilities",
]
