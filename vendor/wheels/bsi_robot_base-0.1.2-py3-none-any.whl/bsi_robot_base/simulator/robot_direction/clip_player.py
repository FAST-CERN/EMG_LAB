"""Virtual robot action state holder with optional MuJoCo clip rendering."""
from __future__ import annotations

from typing import Callable

from .command import DirectionCommand


class ClipPlayer:
    def __init__(self, on_command: Callable[[DirectionCommand], None] | None = None) -> None:
        self.current_command = DirectionCommand.REST
        self._on_command = on_command

    def play(self, command: DirectionCommand) -> None:
        self.current_command = DirectionCommand.from_value(command)
        if self._on_command is not None:
            self._on_command(self.current_command)

    def reset(self) -> None:
        self.current_command = DirectionCommand.REST
        if self._on_command is not None:
            self._on_command(self.current_command)
