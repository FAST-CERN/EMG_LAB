"""Balanced four-class scheduling for collection and task sessions."""
from __future__ import annotations

import random

from .command import DirectionCommand


class ParadigmScheduler:
    def __init__(self, sequence: list[DirectionCommand] | None = None, seed: int | None = None) -> None:
        self._sequence = list(sequence or [])
        self._random = random.Random(seed)

    def build_balanced(self, trial_count: int) -> list[DirectionCommand]:
        if self._sequence:
            return self._sequence[:trial_count]
        base = list(DirectionCommand)
        result: list[DirectionCommand] = []
        while len(result) < trial_count:
            block = base.copy()
            self._random.shuffle(block)
            result.extend(block)
        return result[:trial_count]
