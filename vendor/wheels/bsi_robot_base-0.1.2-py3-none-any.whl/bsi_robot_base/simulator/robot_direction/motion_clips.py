"""Validated four-clip library imported from the direction-labelling demo."""
from __future__ import annotations

from dataclasses import dataclass
import json
import math
from pathlib import Path
from typing import Iterable

import numpy as np


CLIP_NAMES = ("idle", "walk_forward", "turn_left", "turn_right")


@dataclass(frozen=True, slots=True)
class MotionClip:
    name: str
    sample_hz: float
    joint_names: tuple[str, ...]
    joint_qpos: np.ndarray
    qpos: np.ndarray | None = None

    def __post_init__(self) -> None:
        samples = np.asarray(self.joint_qpos, dtype=np.float64)
        if samples.ndim != 2 or samples.shape[0] < 2:
            raise ValueError(f"{self.name}: joint_qpos must be [frames, joints]")
        if samples.shape[1] != len(self.joint_names) or not np.isfinite(samples).all() or self.sample_hz <= 0:
            raise ValueError(f"{self.name}: invalid recorded clip")
        object.__setattr__(self, "joint_qpos", samples)
        if self.qpos is not None:
            object.__setattr__(self, "qpos", np.asarray(self.qpos, dtype=np.float64))

    @property
    def duration_s(self) -> float:
        return self.joint_qpos.shape[0] / self.sample_hz

    def sample(self, phase_s: float) -> np.ndarray:
        frame = (phase_s % self.duration_s) * self.sample_hz
        lower = int(np.floor(frame)) % len(self.joint_qpos)
        upper = (lower + 1) % len(self.joint_qpos)
        fraction = frame - np.floor(frame)
        return self.joint_qpos[lower] * (1.0 - fraction) + self.joint_qpos[upper] * fraction

    def sample_qpos(self, phase_s: float) -> np.ndarray:
        if self.qpos is None:
            raise ValueError(f"{self.name}: full qpos required for visual playback")
        frame = (phase_s % self.duration_s) * self.sample_hz
        lower = int(np.floor(frame)) % len(self.qpos)
        upper = (lower + 1) % len(self.qpos)
        fraction = frame - np.floor(frame)
        qpos = self.qpos[lower] * (1.0 - fraction) + self.qpos[upper] * fraction
        qpos[3:7] /= np.linalg.norm(qpos[3:7])
        return qpos

    def root_velocity_local(self) -> np.ndarray:
        if self.qpos is None:
            return np.zeros(3)
        start, end = self.qpos[0], self.qpos[-1]
        start_yaw, end_yaw = _yaw_from_quat(start[3:7]), _yaw_from_quat(end[3:7])
        delta_world = end[:2] - start[:2]
        cosine, sine = math.cos(start_yaw), math.sin(start_yaw)
        delta_local = np.array([
            cosine * delta_world[0] + sine * delta_world[1],
            -sine * delta_world[0] + cosine * delta_world[1],
        ])
        return np.array([
            delta_local[0] / self.duration_s,
            delta_local[1] / self.duration_s,
            _wrap_angle(end_yaw - start_yaw) / self.duration_s,
        ])


@dataclass(frozen=True, slots=True)
class ClipLibrary:
    clips: dict[str, MotionClip]

    def __post_init__(self) -> None:
        missing = set(CLIP_NAMES).difference(self.clips)
        if missing:
            raise ValueError(f"motion library missing: {sorted(missing)}")
        names = self.clips["idle"].joint_names
        if any(clip.joint_names != names for clip in self.clips.values()):
            raise ValueError("motion clips use inconsistent actuator ordering")

    @property
    def joint_names(self) -> tuple[str, ...]:
        return self.clips["idle"].joint_names

    @classmethod
    def load(cls, recordings_dir: Path) -> "ClipLibrary":
        manifest = json.loads((recordings_dir / "manifest.json").read_text(encoding="utf-8"))
        if manifest.get("schema_version") != 1:
            raise ValueError("unsupported recording manifest schema")
        joint_names = tuple(manifest["joint_names"])
        sample_hz = float(manifest["sample_hz"])
        clips: dict[str, MotionClip] = {}
        for name in CLIP_NAMES:
            filename = manifest.get("clips", {}).get(name)
            if not filename:
                raise ValueError(f"recording manifest is missing {name}")
            with np.load(recordings_dir / filename, allow_pickle=False) as data:
                clips[name] = MotionClip(
                    name=name,
                    sample_hz=sample_hz,
                    joint_names=joint_names,
                    joint_qpos=data["joint_qpos"],
                    qpos=data["qpos"] if "qpos" in data else None,
                )
        return cls(clips)

    def assert_model_compatible(self, actuator_names: Iterable[str]) -> None:
        actual = tuple(actuator_names)
        if actual != self.joint_names:
            raise ValueError(f"recording/model actuator order mismatch: expected={self.joint_names}, actual={actual}")


def _yaw_from_quat(quaternion: np.ndarray) -> float:
    w, x, y, z = quaternion
    return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))


def _wrap_angle(angle: float) -> float:
    return (angle + math.pi) % (2.0 * math.pi) - math.pi
