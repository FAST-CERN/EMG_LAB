from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.contracts import DirectionCommand

__all__ = ["DirectionCommand"]
