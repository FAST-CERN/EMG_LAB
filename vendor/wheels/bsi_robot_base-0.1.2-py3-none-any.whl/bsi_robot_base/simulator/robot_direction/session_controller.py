"""Turns virtual paradigm phases into versioned EventBus records."""
from __future__ import annotations

from itertools import count

from bsi_robot_base.algorithm.topics import ROBOT_DIRECTION_PARADIGM_TOPIC
from bsi_pykit_base.bus.bus_data import BusData
from bsi_pykit_base.bus.event_bus import EventBus

from .command import DirectionCommand


class RobotDirectionSessionController:
    def __init__(self, mode: str) -> None:
        self.mode = mode
        self.event_bus = EventBus()
        self._ids = count(1)

    def publish_segment(
        self,
        command: DirectionCommand | None,
        phase: str,
        trial_index: int,
        *,
        trainable: bool,
        duration_seconds: float | None = None,
    ) -> None:
        command = DirectionCommand.REST if command is None else DirectionCommand.from_value(command)
        self.event_bus.publish(
            ROBOT_DIRECTION_PARADIGM_TOPIC,
            data=BusData(data={
                "event": "segment",
                "segment_id": next(self._ids),
                # The recorder resolves this event onto the EEG clock.  Do not
                # write wall-clock time here: the training server aligns only
                # against the timestamp carried by the EEG samples.
                "timestamp_source": "eeg",
                "duration_seconds": duration_seconds,
                "mode": self.mode,
                "trial_index": trial_index,
                "phase": phase,
                "cue_class": int(command),
                "cue_name": command.command_name,
                "trainable": bool(trainable),
            }),
        )
