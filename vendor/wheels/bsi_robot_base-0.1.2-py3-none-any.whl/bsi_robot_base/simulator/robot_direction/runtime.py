"""Lifecycle-managed virtual four-direction robot runtime.

The runtime has no dependency on the legacy MuJoCo simulator.  It owns its
command state and can be connected to a dedicated MuJoCo renderer/clip player.
"""
from __future__ import annotations

import math
import threading
from typing import Callable

from bsi_robot_base.algorithm.topics import ROBOT_DIRECTION_COMMAND_TOPIC
from bsi_pykit_base.bus.bus_data import BusData
from bsi_pykit_base.bus.event_bus import EventBus

from .clip_player import ClipPlayer
from .command import DirectionCommand
from .cue_presenter import CuePresenter
from .mujoco_clip_renderer import MujocoClipRenderer
from .paradigm_scheduler import ParadigmScheduler
from .session_controller import RobotDirectionSessionController

# 倒计时 0 的显示时长：准备阶段的最后一段显示 0（如 3->2->1->0），
# 动作开始时提示文字与倒计时在同一帧一起消失。
ZERO_DISPLAY_SECONDS = 0.3


class RobotDirectionRuntime:
    def __init__(
        self,
        *,
        mode: str,
        trial_count: int = 0,
        trial_sequence: list[DirectionCommand] | None = None,
        preparation_seconds: float = 1.0,
        active_seconds: float = 3.0,
        on_gate_change: Callable[[bool, str], None] | None = None,
        on_target_change: Callable[[DirectionCommand | None], None] | None = None,
        cue_presenter: CuePresenter | None = None,
        renderer: MujocoClipRenderer | None = None,
    ) -> None:
        self.mode = mode
        self.trial_count = max(0, int(trial_count))
        self.preparation_seconds = max(0.0, float(preparation_seconds))
        self.active_seconds = max(0.0, float(active_seconds))
        self.on_gate_change = on_gate_change
        self.on_target_change = on_target_change
        self.event_bus = EventBus()
        self.controller = RobotDirectionSessionController(mode)
        self.cue_presenter = cue_presenter or CuePresenter()
        self.renderer = renderer if renderer is not None else MujocoClipRenderer()
        self.clip_player = ClipPlayer(self.renderer.set_command)
        self.scheduler = ParadigmScheduler(sequence=trial_sequence)
        self._running = False
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> bool:
        if self._running:
            return True
        self._running = True
        self._stop.clear()
        self.renderer.set_open_mode(self.mode == "open")
        # 倒计时 = 准备阶段时长：sample/task 模式且准备时长 > 0 时启用（0 秒无内容可数）。
        self.renderer.set_countdown_seconds(
            self.preparation_seconds if self.mode in {"sample", "task"} else 0.0
        )
        self.renderer.start()
        self.renderer.set_trial_cue(None, active=False)
        self.event_bus.subscribe(ROBOT_DIRECTION_COMMAND_TOPIC, self._on_command)
        if self.mode in {"sample", "task"} and self.trial_count:
            self._thread = threading.Thread(target=self._run_trials, daemon=True, name="robot-direction-runtime")
            self._thread.start()
        elif self.on_gate_change is not None:
            self.on_gate_change(True, "开放模式")
        return True

    def stop(self) -> bool:
        if not self._running:
            return True
        self._stop.set()
        self.event_bus.unsubscribe(ROBOT_DIRECTION_COMMAND_TOPIC, self._on_command)
        if self._thread is not None:
            self._thread.join(timeout=3)
        self.clip_player.reset()
        self.renderer.set_trial_cue(None, active=False)
        self.renderer.stop()
        if self.on_gate_change is not None:
            self.on_gate_change(False, "实验停止")
        self._running = False
        return True

    def _run_trials(self) -> None:
        for trial_index, command in enumerate(self.scheduler.build_balanced(self.trial_count)):
            if self._stop.is_set():
                break
            self._set_gate(False, "准备阶段")
            self._set_target(command)
            self._show_cue(command, "prepare", countdown=self._initial_countdown())
            self.controller.publish_segment(command, "prepare", trial_index, trainable=False)
            if self._wait_preparation(command):
                break
            self._set_gate(self.mode == "task", "任务活动段")
            # 提示文字与倒计时在同一帧消失，动作开始
            self._show_cue(command, "active")
            if self.mode == "sample":
                self.clip_player.play(command)
            if self._stop.wait(self.active_seconds):
                break
            self.controller.publish_segment(
                command,
                "active",
                trial_index,
                trainable=True,
                duration_seconds=self.active_seconds,
            )
            self.clip_player.reset()
            self._show_cue(None, "complete")
        self._set_gate(False, "任务结束")
        self._set_target(None)
        self._show_cue(None, "complete")

    @property
    def _countdown_enabled(self) -> bool:
        return self.mode in {"sample", "task"} and self.preparation_seconds > 0.0

    def _initial_countdown(self) -> int | None:
        """准备阶段开始时显示的数字（ceil 语义：3 秒倒计时从 3 开始）。"""
        if not self._countdown_enabled:
            return None
        return max(1, math.ceil(self.preparation_seconds))

    def _wait_preparation(self, command: DirectionCommand) -> bool:
        """等待准备阶段结束，逐秒更新倒计时数字；返回 True 表示被停止。

        数字 = ceil(剩余秒数)，最后 ``ZERO_DISPLAY_SECONDS`` 秒显示 0；
        准备阶段结束即返回，提示文字与倒计时由调用方在同一帧清除。
        """
        if not self._countdown_enabled:
            return self._stop.wait(self.preparation_seconds)
        eps = 1e-9  # 浮点边界：避免 remaining 恰好跨过 ZERO_DISPLAY_SECONDS 时多闪一次数字
        remaining = float(self.preparation_seconds)
        while remaining - ZERO_DISPLAY_SECONDS > eps and not self._stop.wait(
            min(1.0, remaining - ZERO_DISPLAY_SECONDS)
        ):
            step = min(1.0, remaining - ZERO_DISPLAY_SECONDS)
            remaining -= step
            if remaining - ZERO_DISPLAY_SECONDS > eps:
                self._show_cue(command, "prepare", countdown=math.ceil(remaining))
        if remaining > 0.0:
            self._show_cue(command, "prepare", countdown=0)
            if self._stop.wait(remaining):
                return True
        return self._stop.is_set()

    def _set_gate(self, active: bool, reason: str) -> None:
        if self.on_gate_change is not None:
            self.on_gate_change(active, reason)

    def _set_target(self, command: DirectionCommand | None) -> None:
        if self.on_target_change is not None:
            self.on_target_change(command)

    def _show_cue(
        self,
        command: DirectionCommand | None,
        phase: str,
        countdown: int | None = None,
    ) -> None:
        """Keep the demo's active-only ground cue in the local viewer."""
        self.cue_presenter.show(command, phase)
        self.renderer.set_trial_cue(command, active=phase == "active", countdown=countdown)

    def _on_command(self, data: BusData) -> None:
        payload = getattr(data, "data", {}) or {}
        if not payload.get("active", False):
            self.clip_player.reset()
            return
        try:
            self.clip_player.play(DirectionCommand.from_value(payload.get("filtered_class", 0)))
        except (TypeError, ValueError):
            self.clip_player.reset()
