"""One-off, verified importer for the approved direction-labelling demo assets."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path


ASSET_ROOT = Path(__file__).resolve().parent / "assets"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _copy_tree(source: Path, destination: Path) -> list[dict[str, str]]:
    copied: list[dict[str, str]] = []
    for file_path in source.rglob("*"):
        if not file_path.is_file():
            continue
        relative = file_path.relative_to(source)
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(file_path, target)
        if _sha256(file_path) != _sha256(target):
            raise RuntimeError(f"checksum mismatch after copying {relative}")
        copied.append({"path": target.relative_to(ASSET_ROOT).as_posix(), "sha256": _sha256(target)})
    return copied


def import_demo_assets(source_root: str | Path) -> list[dict[str, str]]:
    """Import all runtime dependencies; the runtime never reads the source path."""
    source_root = Path(source_root)
    imports = (
        (source_root / "assets" / "models", ASSET_ROOT / "model"),
        (source_root / "assets" / "policy", ASSET_ROOT / "policy"),
        (source_root / "assets" / "textures", ASSET_ROOT / "textures"),
        (source_root / "assets" / "licenses", ASSET_ROOT / "licenses"),
        (source_root / "data" / "recordings", ASSET_ROOT / "recordings"),
    )
    result: list[dict[str, str]] = []
    for source, destination in imports:
        if not source.is_dir():
            raise FileNotFoundError(f"missing approved demo asset directory: {source}")
        result.extend(_copy_tree(source, destination))
    return result


def build_manifest(source_root: Path, copied: list[dict[str, str]]) -> dict:
    """Describe every imported file so source, integrity and ownership are auditable."""
    def purpose(path: str) -> str:
        if path.startswith("recordings/"):
            return "four-class virtual-robot action clip"
        if path.startswith("model/"):
            return "dedicated virtual-robot MuJoCo model or mesh dependency"
        if path.startswith("textures/"):
            return "virtual-robot scene texture"
        if path.startswith("policy/"):
            return "virtual-robot policy/runtime dependency retained from demo"
        if path.startswith("licenses/"):
            return "upstream asset license or attribution notice"
        return "approved virtual-robot demo dependency"

    return {
        "schema_version": 1,
        "source": str(source_root).replace("\\", "/"),
        "runtime": "dedicated robot_direction MuJoCo model/data/viewer; not shared with legacy mujoco_simulator",
        "license_notice": "See assets/licenses for imported upstream notices and redistribution terms.",
        "assets": [
            {
                "path": f"assets/{item['path']}",
                "sha256": item["sha256"],
                "purpose": purpose(item["path"]),
            }
            for item in sorted(copied, key=lambda item: item["path"])
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Import approved virtual robot demo assets")
    parser.add_argument("source_root", type=Path)
    parser.add_argument("--manifest", type=Path, default=None)
    args = parser.parse_args()
    copied = import_demo_assets(args.source_root)
    if args.manifest:
        args.manifest.write_text(
            json.dumps(build_manifest(args.source_root, copied), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    print(f"Imported and verified {len(copied)} virtual-robot assets into {ASSET_ROOT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
