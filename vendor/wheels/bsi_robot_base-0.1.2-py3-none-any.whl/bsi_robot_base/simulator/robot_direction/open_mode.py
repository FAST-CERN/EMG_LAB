"""Open-mode coin session copied from the direction-labelling demo contract."""
from __future__ import annotations

from dataclasses import dataclass
import math
import random

import numpy as np

from .camera import (
    THIRD_PERSON_DISTANCE_M,
    THIRD_PERSON_ELEVATION_DEG,
    THIRD_PERSON_LOOKAT_Z_M,
    yaw_from_quat,
)
from .coin_presenter import COIN_BASE_Z_M


COIN_COLLECTION_DISTANCE_M = 0.45
COIN_MIN_SPAWN_DISTANCE_M = 2.2
TRAINING_AREA_HALF_EXTENT_M = 7.5
COIN_TRAINING_AREA_MARGIN_M = 0.3
COIN_TRAINING_AREA_LIMIT_M = TRAINING_AREA_HALF_EXTENT_M - COIN_TRAINING_AREA_MARGIN_M
COIN_TRAINING_CANDIDATE_COUNT = 512
COIN_TRAINING_GRID_SIZE = 65
COIN_FALLBACK_CANDIDATE_COUNT = 256
COIN_VIEW_VERTICAL_FOV_DEG = 45.0
COIN_VIEW_ASPECT_RATIO = 16.0 / 9.0
COIN_VIEW_MARGIN_DEG = 5.0
COIN_VIEW_CENTER_CLEARANCE_DEG = 8.0
COIN_VIEW_USABLE_HORIZONTAL_HALF_ANGLE_DEG = math.degrees(
    math.atan(math.tan(math.radians(COIN_VIEW_VERTICAL_FOV_DEG) / 2.0) * COIN_VIEW_ASPECT_RATIO)
) - COIN_VIEW_MARGIN_DEG
COIN_VIEW_USABLE_VERTICAL_HALF_ANGLE_DEG = COIN_VIEW_VERTICAL_FOV_DEG / 2.0 - COIN_VIEW_MARGIN_DEG


@dataclass(frozen=True, slots=True)
class OpenConfig:
    trial_count: int = 6
    trial_timeout_s: float = 20.0
    random_seed: int = 20260721


class OpenSession:
    """Spawn demo-identical visible coins and track collection/timeout trials."""

    def __init__(self, config: OpenConfig | None = None) -> None:
        self.config = config or OpenConfig()
        self._rng = random.Random(self.config.random_seed)
        self._trial_index = 0
        self._trial_elapsed_s = 0.0
        self._session_time_s = 0.0
        self._coin_xy: np.ndarray | None = None
        self._complete = False

    @property
    def complete(self) -> bool:
        return self._complete

    @property
    def session_time_s(self) -> float:
        return self._session_time_s

    @property
    def coin_xy(self) -> np.ndarray | None:
        return None if self._coin_xy is None else self._coin_xy.copy()

    def start_trial(self, qpos: np.ndarray) -> np.ndarray:
        if self._complete:
            raise RuntimeError("cannot start an open trial after completion")
        root_xy = np.asarray(qpos[:2], dtype=np.float64)
        yaw = yaw_from_quat(qpos[3:7])
        for _ in range(COIN_TRAINING_CANDIDATE_COUNT):
            candidate = self._sample_training_area_candidate()
            if self._is_valid_candidate(candidate, root_xy, yaw):
                self._coin_xy = candidate
                break
        else:
            self._coin_xy = self._sample_training_grid_candidate(root_xy, yaw)
            if self._coin_xy is None:
                self._coin_xy = self._sample_visible_fallback(root_xy, yaw)
        self._trial_elapsed_s = 0.0
        return self._coin_xy.copy()

    def update(self, dt_s: float, root_xy: np.ndarray) -> bool:
        if self._complete or self._coin_xy is None:
            return False
        self._trial_elapsed_s += max(0.0, dt_s)
        self._session_time_s += max(0.0, dt_s)
        distance = float(np.linalg.norm(np.asarray(root_xy, dtype=np.float64) - self._coin_xy))
        if distance > COIN_COLLECTION_DISTANCE_M and self._trial_elapsed_s < self.config.trial_timeout_s:
            return False
        self._trial_index += 1
        self._coin_xy = None
        if self._trial_index >= self.config.trial_count:
            self._complete = True
        return True

    def _sample_training_area_candidate(self) -> np.ndarray:
        return np.array([
            self._rng.uniform(-COIN_TRAINING_AREA_LIMIT_M, COIN_TRAINING_AREA_LIMIT_M),
            self._rng.uniform(-COIN_TRAINING_AREA_LIMIT_M, COIN_TRAINING_AREA_LIMIT_M),
        ], dtype=np.float64)

    def _is_valid_candidate(self, candidate: np.ndarray, root_xy: np.ndarray, yaw: float) -> bool:
        return np.linalg.norm(candidate - root_xy) >= COIN_MIN_SPAWN_DISTANCE_M and coin_is_visible_in_chase_camera(candidate, root_xy, yaw)

    def _sample_training_grid_candidate(self, root_xy: np.ndarray, yaw: float) -> np.ndarray | None:
        coordinates = np.linspace(-COIN_TRAINING_AREA_LIMIT_M, COIN_TRAINING_AREA_LIMIT_M, COIN_TRAINING_GRID_SIZE)
        valid = [
            np.array([x, y], dtype=np.float64)
            for x in coordinates for y in coordinates
            if self._is_valid_candidate(np.array([x, y], dtype=np.float64), root_xy, yaw)
        ]
        return valid[self._rng.randrange(len(valid))] if valid else None

    def _sample_visible_fallback(self, root_xy: np.ndarray, yaw: float) -> np.ndarray:
        best_candidate: np.ndarray | None = None
        best_overflow_m = math.inf
        for _ in range(COIN_FALLBACK_CANDIDATE_COUNT):
            candidate = _sample_camera_ground_candidate(self._rng, root_xy, yaw)
            if candidate is None or not self._is_valid_candidate(candidate, root_xy, yaw):
                continue
            overflow_m = float(np.linalg.norm(np.maximum(np.abs(candidate) - COIN_TRAINING_AREA_LIMIT_M, 0.0)))
            if overflow_m < best_overflow_m:
                best_candidate, best_overflow_m = candidate, overflow_m
        if best_candidate is None:
            raise RuntimeError("camera view contains no valid coin spawn point")
        return best_candidate


def coin_is_visible_in_chase_camera(coin_xy: np.ndarray, root_xy: np.ndarray, yaw: float) -> bool:
    camera_pos, forward, right, up = _chase_camera_frame(root_xy, yaw)
    relative = np.array([coin_xy[0] - camera_pos[0], coin_xy[1] - camera_pos[1], COIN_BASE_Z_M - camera_pos[2]])
    depth_m = float(relative @ forward)
    horizontal_deg = math.degrees(math.atan2(float(relative @ right), depth_m))
    vertical_deg = math.degrees(math.atan2(float(relative @ up), depth_m))
    return (
        depth_m > 0.0
        and COIN_VIEW_CENTER_CLEARANCE_DEG <= abs(horizontal_deg) <= COIN_VIEW_USABLE_HORIZONTAL_HALF_ANGLE_DEG
        and abs(vertical_deg) <= COIN_VIEW_USABLE_VERTICAL_HALF_ANGLE_DEG
    )


def _sample_camera_ground_candidate(rng: random.Random, root_xy: np.ndarray, yaw: float) -> np.ndarray | None:
    horizontal = rng.uniform(COIN_VIEW_CENTER_CLEARANCE_DEG, COIN_VIEW_USABLE_HORIZONTAL_HALF_ANGLE_DEG)
    if rng.random() < 0.5:
        horizontal = -horizontal
    vertical = rng.uniform(-COIN_VIEW_USABLE_VERTICAL_HALF_ANGLE_DEG, COIN_VIEW_USABLE_VERTICAL_HALF_ANGLE_DEG)
    camera_pos, forward, right, up = _chase_camera_frame(root_xy, yaw)
    direction = forward + math.tan(math.radians(horizontal)) * right + math.tan(math.radians(vertical)) * up
    if direction[2] >= 0.0:
        return None
    scale = (COIN_BASE_Z_M - camera_pos[2]) / direction[2]
    return None if scale <= 0.0 else camera_pos[:2] + scale * direction[:2]


def _chase_camera_frame(root_xy: np.ndarray, yaw: float) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    elevation = math.radians(THIRD_PERSON_ELEVATION_DEG)
    robot_forward = np.array([math.cos(yaw), math.sin(yaw), 0.0])
    camera_pos = np.array([
        root_xy[0] - THIRD_PERSON_DISTANCE_M * math.cos(elevation) * robot_forward[0],
        root_xy[1] - THIRD_PERSON_DISTANCE_M * math.cos(elevation) * robot_forward[1],
        THIRD_PERSON_LOOKAT_Z_M - THIRD_PERSON_DISTANCE_M * math.sin(elevation),
    ])
    forward = np.array([math.cos(elevation) * robot_forward[0], math.cos(elevation) * robot_forward[1], math.sin(elevation)])
    right = np.array([math.sin(yaw), -math.cos(yaw), 0.0])
    up = np.array([-math.sin(elevation) * robot_forward[0], -math.sin(elevation) * robot_forward[1], math.cos(elevation)])
    return camera_pos, forward, right, up
