"""Continuous kinematic root tracking from the direction-labelling demo."""
from __future__ import annotations

import math
from typing import Iterable

import numpy as np


FOOT_SUPPORT_BLEND_M = 0.005


class KinematicTracker:
    """Apply blended joint targets while retaining a continuous free-root pose."""

    def __init__(self, mujoco: object, model: object, expected_actuators: Iterable[str]) -> None:
        self._mujoco = mujoco
        self._model = model
        self.actuator_names = tuple(model.actuator(index).name for index in range(model.nu))
        if self.actuator_names != tuple(expected_actuators) or model.nu != 29:
            raise ValueError("kinematic player requires the pinned 29-actuator G1 model")
        self._foot_geoms = tuple(model.geom(name).id for name in ("left_foot", "right_foot"))
        self._origin_xy = np.zeros(2)
        self._origin_z = 0.0
        self._yaw = 0.0

    def reset(self, data: object) -> None:
        self._origin_xy[:] = data.qpos[:2]
        self._origin_z = float(data.qpos[2])
        self._yaw = _yaw_from_quat(data.qpos[3:7])

    def apply(
        self,
        data: object,
        joint_targets: np.ndarray,
        root_z_offset: float,
        root_roll: float,
        root_pitch: float,
        root_velocity_local: np.ndarray,
        dt_s: float,
    ) -> None:
        targets = np.asarray(joint_targets, dtype=np.float64)
        if targets.shape != (self._model.nu,):
            raise ValueError(f"expected {self._model.nu} joint targets, got {targets.shape}")
        local_x, local_y, yaw_velocity = root_velocity_local
        cosine, sine = math.cos(self._yaw), math.sin(self._yaw)
        self._origin_xy += dt_s * np.array([
            cosine * local_x - sine * local_y,
            sine * local_x + cosine * local_y,
        ])
        self._yaw += dt_s * yaw_velocity
        data.qpos[:2] = self._origin_xy
        data.qpos[2] = self._origin_z + root_z_offset
        data.qpos[3:7] = _euler_to_quat(root_roll, root_pitch, self._yaw)
        data.qpos[7:] = targets
        data.qvel[:] = 0.0
        self._mujoco.mj_forward(self._model, data)
        self._align_feet_to_ground(data)

    def _align_feet_to_ground(self, data: object) -> None:
        foot_heights = np.array([
            _geom_lowest_z(self._model, data, geom_id)
            for geom_id in self._foot_geoms
        ])
        data.qpos[2] -= _soft_minimum(foot_heights, FOOT_SUPPORT_BLEND_M)
        self._mujoco.mj_forward(self._model, data)


def _geom_lowest_z(model: object, data: object, geom_id: int) -> float:
    half_size = model.geom_size[geom_id]
    rotation = data.geom_xmat[geom_id].reshape(3, 3)
    return float(data.geom_xpos[geom_id, 2] - np.sum(np.abs(rotation[2]) * half_size))


def _soft_minimum(values: np.ndarray, scale: float) -> float:
    minimum = float(np.min(values))
    return minimum - scale * math.log(float(np.exp(-(values - minimum) / scale).sum()))


def _yaw_from_quat(quaternion: np.ndarray) -> float:
    w, x, y, z = quaternion
    return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))


def _euler_to_quat(roll: float, pitch: float, yaw: float) -> np.ndarray:
    cr, sr = math.cos(roll / 2.0), math.sin(roll / 2.0)
    cp, sp = math.cos(pitch / 2.0), math.sin(pitch / 2.0)
    cy, sy = math.cos(yaw / 2.0), math.sin(yaw / 2.0)
    return np.array([
        cr * cp * cy + sr * sp * sy,
        sr * cp * cy - cr * sp * sy,
        cr * sp * cy + sr * cp * sy,
        cr * cp * sy - sr * sp * cy,
    ])
