"""Phase-synchronised clip mixing, adapted directly from the virtual demo."""
from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np

from .command import DirectionCommand
from .motion_clips import ClipLibrary


@dataclass(frozen=True, slots=True)
class PlaybackTarget:
    joint_qpos: np.ndarray
    command: DirectionCommand
    phase_s: float
    root_z_offset: float
    root_roll: float
    root_pitch: float
    root_velocity_local: np.ndarray


class ClipBlender:
    """Blend joint offsets and root motion without restarting a clip on switch."""

    def __init__(self, library: ClipLibrary, transition_s: float = 0.10) -> None:
        if transition_s <= 0:
            raise ValueError("transition_s must be positive")
        self._library = library
        self._transition_s = transition_s
        self._phase_s = 0.0
        self._target = library.clips["idle"].sample(0.0).copy()
        raw = {name: clip.root_velocity_local() for name, clip in library.clips.items()}
        self._root_velocities = {
            "idle": np.zeros(3),
            "walk_forward": np.array([raw["walk_forward"][0], 0.0, 0.0]),
            "turn_left": np.array([0.0, 0.0, raw["turn_left"][2]]),
            "turn_right": np.array([0.0, 0.0, raw["turn_right"][2]]),
        }

    @property
    def phase_s(self) -> float:
        return self._phase_s

    def reset(self) -> None:
        self._phase_s = 0.0
        self._target = self._library.clips["idle"].sample(0.0).copy()

    def update(self, command: DirectionCommand | int, dt_s: float) -> PlaybackTarget:
        if dt_s < 0:
            raise ValueError("dt_s must not be negative")
        command = DirectionCommand.from_value(command)
        forward, yaw = _command_vector(command)
        speed = max(forward, abs(yaw))
        if speed:
            self._phase_s += speed * dt_s
        idle = self._library.clips["idle"].sample(self._phase_s)
        desired = self._blend_active_offsets(forward, yaw, idle)
        alpha = 1.0 - np.exp(-dt_s / self._transition_s) if dt_s else 0.0
        self._target = self._target + alpha * (desired - self._target)
        root_z_offset, root_roll, root_pitch, velocity = self._blend_root_motion(forward, yaw, speed)
        return PlaybackTarget(
            self._target.copy(), command, self._phase_s,
            root_z_offset, root_roll, root_pitch, velocity,
        )

    def _blend_active_offsets(self, forward: float, yaw: float, idle: np.ndarray) -> np.ndarray:
        contributions: list[tuple[float, np.ndarray]] = []
        if forward > 0:
            contributions.append((forward, self._library.clips["walk_forward"].sample(self._phase_s)))
        if yaw > 0:
            contributions.append((yaw, self._library.clips["turn_left"].sample(self._phase_s)))
        if yaw < 0:
            contributions.append((-yaw, self._library.clips["turn_right"].sample(self._phase_s)))
        if not contributions:
            return idle
        total = sum(weight for weight, _ in contributions)
        amplitude = max(forward, abs(yaw))
        offset = sum((weight / total) * (sample - idle) for weight, sample in contributions)
        return idle + amplitude * offset

    def _blend_root_motion(self, forward: float, yaw: float, amplitude: float) -> tuple[float, float, float, np.ndarray]:
        idle_qpos = self._library.clips["idle"].sample_qpos(self._phase_s)
        contributions: list[tuple[float, str]] = []
        if forward > 0:
            contributions.append((forward, "walk_forward"))
        if yaw > 0:
            contributions.append((yaw, "turn_left"))
        if yaw < 0:
            contributions.append((-yaw, "turn_right"))
        if not contributions:
            return 0.0, 0.0, 0.0, np.zeros(3)
        total = sum(weight for weight, _ in contributions)
        pure_turn = forward <= 0 and abs(yaw) > 0
        z_offset = roll = pitch = 0.0
        velocity = np.zeros(3)
        for weight, name in contributions:
            sample = self._library.clips[name].sample_qpos(self._phase_s)
            sample_roll, sample_pitch = _roll_pitch_from_quat(sample[3:7])
            idle_roll, idle_pitch = _roll_pitch_from_quat(idle_qpos[3:7])
            fraction = weight / total
            z_offset += fraction * (sample[2] - idle_qpos[2])
            if pure_turn:
                roll += fraction * sample_roll
                pitch += fraction * sample_pitch
            else:
                roll += fraction * (sample_roll - idle_roll)
                pitch += fraction * (sample_pitch - idle_pitch)
            velocity += fraction * self._root_velocities[name]
        return amplitude * z_offset, amplitude * roll, amplitude * pitch, amplitude * velocity


def _command_vector(command: DirectionCommand) -> tuple[float, float]:
    return {
        DirectionCommand.REST: (0.0, 0.0),
        DirectionCommand.FORWARD: (1.0, 0.0),
        DirectionCommand.LEFT: (0.0, 1.0),
        DirectionCommand.RIGHT: (0.0, -1.0),
    }[command]


def _roll_pitch_from_quat(quaternion: np.ndarray) -> tuple[float, float]:
    w, x, y, z = quaternion
    return (
        math.atan2(2.0 * (w * x + y * z), 1.0 - 2.0 * (x * x + y * y)),
        math.asin(np.clip(2.0 * (w * y - z * x), -1.0, 1.0)),
    )
