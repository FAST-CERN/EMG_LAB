"""UI-independent cue publisher for the virtual robot workflow."""
from __future__ import annotations

from typing import Callable

from .command import DirectionCommand


class CuePresenter:
    def __init__(self, on_cue: Callable[[DirectionCommand | None, str], None] | None = None) -> None:
        self.on_cue = on_cue

    def show(self, command: DirectionCommand | None, phase: str) -> None:
        if self.on_cue is not None:
            self.on_cue(command, phase)
