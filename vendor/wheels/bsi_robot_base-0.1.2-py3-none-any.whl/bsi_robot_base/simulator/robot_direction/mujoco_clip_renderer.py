"""Dedicated MuJoCo viewer for the imported virtual-robot direction clips."""
from __future__ import annotations

import logging
import shutil
import tempfile
import threading
import time
from pathlib import Path

from .camera import CameraController, CameraPreset
from .coin_presenter import CoinPresenter
from .command import DirectionCommand
from .ground_cue_presenter import GroundCuePresenter
from .kinematic_tracker import KinematicTracker
from .motion_blender import ClipBlender
from .motion_clips import ClipLibrary
from .open_mode import OpenSession

_logger = logging.getLogger(__name__)


class MujocoClipRenderer:
    """Owns a model, MjData and viewer thread independent from legacy MuJoCo."""

    def __init__(self, asset_root: str | Path | None = None) -> None:
        self.asset_root = Path(asset_root or Path(__file__).resolve().parent / "assets")
        self._lock = threading.Lock()
        self._command = DirectionCommand.REST
        self._running = False
        self._thread: threading.Thread | None = None
        self._library: ClipLibrary | None = None
        self._trial_cue: DirectionCommand | None = None
        self._trial_active = False
        self._countdown: int | None = None
        self._countdown_seconds = 0.0
        self._open_mode = False
        self.last_error: Exception | None = None

    @property
    def available(self) -> bool:
        return (
            (self.asset_root / "model" / "scene_direction_labelling.xml").is_file()
            and (self.asset_root / "recordings" / "manifest.json").is_file()
        )

    def start(self) -> bool:
        if self._running:
            return True
        if not self.available:
            return True  # Logic/recording stays usable when graphical assets are absent.
        self.last_error = None
        self._load_clips()
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True, name="robot-direction-mujoco")
        self._thread.start()
        return True

    def stop(self) -> bool:
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=3.0)
        self._thread = None
        return True

    def set_command(self, command: DirectionCommand | int) -> None:
        with self._lock:
            self._command = DirectionCommand.from_value(command)

    def set_trial_cue(
        self,
        cue: DirectionCommand | int | None,
        *,
        active: bool,
        countdown: int | None = None,
    ) -> None:
        """Mirror the demo: display a root-following cue only while active.

        ``countdown`` optionally carries the current countdown digit (``None``
        hides it): during preparation the digit ticks beside the text cue, and
        ``0`` marks the action onset.
        """
        with self._lock:
            self._trial_cue = None if cue is None else DirectionCommand.from_value(cue)
            self._trial_active = bool(active)
            self._countdown = countdown

    def set_countdown_seconds(self, seconds: float) -> None:
        """Declare the preparation countdown length (0 disables the countdown).

        Must be called before :meth:`start`; the digit textures are generated
        once when the renderer thread loads the scene.
        """
        with self._lock:
            self._countdown_seconds = max(0.0, float(seconds))

    def set_open_mode(self, enabled: bool) -> None:
        """Enable the demo's coin-collection scene for open control."""
        with self._lock:
            self._open_mode = bool(enabled)

    def _load_clips(self) -> None:
        recordings = self.asset_root / "recordings"
        self._library = ClipLibrary.load(recordings)

    def _prepare_countdown_scene(self, scene_xml: Path) -> tuple[Path, Path | None]:
        """Generate countdown digit textures and return the XML to load.

        When a countdown is enabled the digit badges are rendered once (Pillow)
        into a temporary directory and injected into a temporary copy of the
        scene XML as extra textures/materials.  The returned work directory
        must stay alive until the model is loaded (caller removes it
        afterwards).  Any failure (missing Pillow, render error) degrades
        gracefully: the original scene is used and the countdown planes are
        simply not drawn.
        """
        with self._lock:
            countdown_seconds = self._countdown_seconds
        if countdown_seconds <= 0.0:
            return scene_xml, None
        try:
            from .countdown_textures import build_countdown_scene_xml, countdown_digits, generate_countdown_textures
        except ImportError:
            _logger.warning("Pillow 未安装，倒计时贴图不可用（%s）", scene_xml)
            return scene_xml, None
        work_dir = Path(tempfile.mkdtemp(prefix="bsi_rd_countdown_"))
        try:
            digits = countdown_digits(countdown_seconds)
            tex_dir = work_dir / "textures"
            generate_countdown_textures(digits, tex_dir)
            countdown_xml = work_dir / "scene_countdown.xml"
            build_countdown_scene_xml(scene_xml, digits, tex_dir, countdown_xml)
            return countdown_xml, work_dir
        except Exception:
            _logger.exception("倒计时贴图生成失败，本次会话使用无倒计时的场景")
            shutil.rmtree(work_dir, ignore_errors=True)
            return scene_xml, None

    def _run(self) -> None:
        try:
            import mujoco
            import mujoco.viewer

            scene_xml = self.asset_root / "model" / "scene_direction_labelling.xml"
            model_path, countdown_work_dir = self._prepare_countdown_scene(scene_xml)
            try:
                model = mujoco.MjModel.from_xml_path(str(model_path))
            finally:
                if countdown_work_dir is not None:
                    shutil.rmtree(countdown_work_dir, ignore_errors=True)
            data = mujoco.MjData(model)
            # These are demo scene invariants: playback is kinematic, with no
            # gravity/contact side effects, and begins from knees_bent.
            model.opt.gravity[:] = 0.0
            model.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_CONTACT)
            try:
                mujoco.mj_resetDataKeyframe(model, data, model.key("knees_bent").id)
            except KeyError:
                mujoco.mj_resetData(model, data)
            mujoco.mj_forward(model, data)
            if self._library is None:
                raise RuntimeError("robot motion clips were not loaded")
            self._library.assert_model_compatible(
                model.actuator(index).name for index in range(model.nu)
            )
            blender = ClipBlender(self._library)
            tracker = KinematicTracker(mujoco, model, self._library.joint_names)
            tracker.reset(data)
            camera_controller = CameraController(CameraPreset.THIRD_PERSON)
            ground_cue_presenter = GroundCuePresenter(model)
            with self._lock:
                open_mode = self._open_mode
            open_session = OpenSession() if open_mode else None
            coin_presenter = CoinPresenter(model) if open_session else None
            if open_session is not None:
                open_session.start_trial(data.qpos)
            with mujoco.viewer.launch_passive(model, data, show_left_ui=False, show_right_ui=False) as viewer:
                viewer.cam.type = mujoco.mjtCamera.mjCAMERA_FREE
                last_wall = time.perf_counter()
                while self._running and viewer.is_running():
                    now = time.perf_counter()
                    elapsed_wall = min(now - last_wall, 0.1)
                    last_wall = now
                    with self._lock:
                        command = self._command
                        trial_cue = self._trial_cue
                        trial_active = self._trial_active
                        countdown = self._countdown
                        open_mode = self._open_mode
                    target = blender.update(command, elapsed_wall)
                    tracker.apply(
                        data,
                        target.joint_qpos,
                        target.root_z_offset,
                        target.root_roll,
                        target.root_pitch,
                        target.root_velocity_local,
                        elapsed_wall,
                    )
                    if open_session is not None and coin_presenter is not None:
                        completed = open_session.update(elapsed_wall, data.qpos[:2])
                        if completed and not open_session.complete:
                            open_session.start_trial(data.qpos)
                        coin_presenter.update(
                            mujoco,
                            model,
                            data,
                            open_session.coin_xy,
                            open_session.session_time_s,
                        )
                    camera_controller.update(viewer.cam, data.qpos, elapsed_wall)
                    ground_cue_presenter.update(
                        viewer, viewer.cam, data, trial_cue, trial_active and not open_mode, countdown
                    )
                    viewer.sync()
                    time.sleep(0.01)
        except Exception as exc:
            # The simulator is a feedback endpoint.  A rendering failure must
            # not terminate EEG acquisition, decoding or label recording.
            self.last_error = exc
            self._running = False
            _logger.error("MujocoClipRenderer 渲染失败（线程=%s）: %s", threading.current_thread().name, exc, exc_info=True)
        finally:
            # launch_passive 的 GL 上下文清理（simulate.destroy）在其内部
            # daemon 线程异步执行；退出本线程前短暂等待其完成，避免与 Qt
            # 退出时的 GL 清理竞态导致偶发段错误。renderer.stop() 的 join
            # 只覆盖本线程，不覆盖 launch_passive 内部的清理线程。
            time.sleep(0.5)
