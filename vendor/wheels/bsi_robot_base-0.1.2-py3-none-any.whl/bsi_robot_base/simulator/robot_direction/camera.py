"""Camera behaviour kept in sync with the direction-labelling demo."""
from __future__ import annotations

from enum import StrEnum
import math

import numpy as np


THIRD_PERSON_DISTANCE_M = 2.5
THIRD_PERSON_ELEVATION_DEG = -20.0
THIRD_PERSON_LOOKAT_Z_M = 0.75


class CameraPreset(StrEnum):
    FIRST_PERSON = "first_person"
    THIRD_PERSON = "third_person"
    TOP_DOWN = "top_down"


class CameraController:
    """Demo-compatible root-following free camera.

    The robot screen always uses the demo's ``third_person`` preset.  It is
    fixed relative to the robot (distance/elevation) while its look-at and
    azimuth track the free-root pose smoothly, exactly as in the demo.
    """

    def __init__(self, preset: CameraPreset = CameraPreset.THIRD_PERSON) -> None:
        self.preset = CameraPreset(preset)
        self._lookat: np.ndarray | None = None
        self._yaw_deg: float | None = None

    def reset(self) -> None:
        self._lookat = None
        self._yaw_deg = None

    def update(self, camera: object, qpos: np.ndarray, dt_s: float) -> None:
        root = np.asarray(qpos[:3], dtype=np.float64)
        yaw_deg = math.degrees(_yaw_from_quat(qpos[3:7]))
        if self.preset is CameraPreset.FIRST_PERSON:
            forward = np.array(
                [math.cos(math.radians(yaw_deg)), math.sin(math.radians(yaw_deg)), 0.0]
            )
            target = root + np.array([0.0, 0.0, 0.85]) + forward * 0.8
            camera.distance = 0.8
            camera.elevation = 0.0
            desired_azimuth = 180.0 + yaw_deg
            time_constant = 0.08
        elif self.preset is CameraPreset.THIRD_PERSON:
            target = np.array([root[0], root[1], THIRD_PERSON_LOOKAT_Z_M])
            camera.distance = THIRD_PERSON_DISTANCE_M
            camera.elevation = THIRD_PERSON_ELEVATION_DEG
            desired_azimuth = yaw_deg
            time_constant = 0.20
        else:
            target = np.array([root[0], root[1], 0.0])
            camera.distance = 6.0
            camera.elevation = -89.0
            desired_azimuth = 0.0
            time_constant = 0.20

        alpha = 1.0 if self._lookat is None else 1.0 - math.exp(-max(dt_s, 0.0) / time_constant)
        self._lookat = target.copy() if self._lookat is None else self._lookat + alpha * (target - self._lookat)
        if self._yaw_deg is None:
            self._yaw_deg = desired_azimuth
        else:
            self._yaw_deg += alpha * _wrap_degrees(desired_azimuth - self._yaw_deg)
        camera.lookat[:] = self._lookat
        camera.azimuth = self._yaw_deg


def yaw_from_quat(quaternion: np.ndarray) -> float:
    return _yaw_from_quat(quaternion)


def _yaw_from_quat(quaternion: np.ndarray) -> float:
    w, x, y, z = quaternion
    return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))


def _wrap_degrees(angle: float) -> float:
    return (angle + 180.0) % 360.0 - 180.0
