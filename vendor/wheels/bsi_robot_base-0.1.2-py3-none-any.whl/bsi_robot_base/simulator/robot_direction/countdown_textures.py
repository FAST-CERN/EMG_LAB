"""Runtime-generated countdown digit textures for the virtual-robot cue.

MuJoCo's built-in font is ASCII-only and its ``mjvGeom.label`` text is drawn
with a fixed, very small screen-space font, so a patient-facing countdown
cannot be rendered as scene text.  Instead the countdown digits are rendered
once at renderer startup with Pillow (same badge style as the pre-rendered
"准备：…" cue textures) and injected into a temporary copy of the scene XML
as extra ``<texture>/<material>`` pairs.  During the trial the presenter only
swaps ``matid`` once per second, so the per-frame cost is one integer write.

Digit images are generated for every value that can appear, ``0..ceil(seconds)``
(the digits ``N..1`` tick during preparation and ``0`` marks action onset), so
arbitrary page-provided durations — including multi-digit ones — work without
any pre-baked assets.
"""
from __future__ import annotations

import math
import re
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

__all__ = ["render_countdown_badge", "generate_countdown_textures", "build_countdown_scene_xml"]

# 徽章样式与 tools/generate_cue_textures.render_label 对齐：半透明深色圆角底 + 亮色文字。
BADGE_BACKGROUND = (20, 20, 24, 170)
BADGE_TEXT_COLOR = (255, 255, 255, 255)
DIGIT_FONT_SIZE = 96


def countdown_digits(seconds: float) -> list[int]:
    """Return the digit set needed for a countdown of ``seconds``: 0..ceil(seconds)."""
    return list(range(0, max(0, math.ceil(seconds)) + 1))


def _measure_canvas(digits: list[int], font_size: int) -> tuple[int, int]:
    """Measure a fixed canvas that fits every digit (width driven by the widest one).

    All digits of one session share the same canvas so the rendered badge size
    (and therefore the on-screen plane size) stays constant while counting.
    """
    font = ImageFont.load_default(font_size)
    probe = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    pad = int(font_size * 0.25)
    max_glyph_w = 0
    glyph_h = 0
    for digit in digits:
        left, top, right, bottom = probe.textbbox((0, 0), str(digit), font=font)
        max_glyph_w = max(max_glyph_w, right - left)
        glyph_h = max(glyph_h, bottom - top)
    return max_glyph_w + pad * 2, glyph_h + pad * 2


def render_countdown_badge(
    digit: int | str,
    canvas_size: tuple[int, int] | None = None,
    font_size: int = DIGIT_FONT_SIZE,
) -> Image.Image:
    """Render one countdown digit as a pre-mirrored RGBA badge image.

    The image is horizontally pre-mirrored (like the cue textures) to cancel
    the left-right mirroring MuJoCo applies to ``user_scn`` plane textures.

    The badge has sharp corners on the right and rounded corners on the left
    (before mirroring), which after the render-side mirror becomes sharp on
    the left: the side that sits flush against the "准备：…" cue badge, so the
    two backgrounds join along a straight line instead of two colliding
    rounded corners.
    """
    text = str(digit)
    if canvas_size is None:
        canvas_size = _measure_canvas([digit], font_size)
    width, height = canvas_size
    font = ImageFont.load_default(font_size)
    probe = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
    left, top, right, bottom = probe.textbbox((0, 0), text, font=font)
    glyph_w = right - left
    glyph_h = bottom - top

    image = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    radius = height // 5
    # corners=(左上, 右上, 右下, 左下)：右上/右下直角（镜像后成为拼接侧的直角边）
    draw.rounded_rectangle(
        (0, 0, width - 1, height - 1),
        radius=radius,
        fill=BADGE_BACKGROUND,
        corners=(True, False, False, True),
    )
    # 数字在固定画布中水平/垂直居中
    draw.text(
        ((width - glyph_w) // 2 - left, (height - glyph_h) // 2 - top),
        text,
        font=font,
        fill=BADGE_TEXT_COLOR,
    )
    return image.transpose(Image.FLIP_LEFT_RIGHT)


def generate_countdown_textures(digits: list[int], out_dir: Path) -> dict[int, Path]:
    """Render and save one badge PNG per digit; return ``{digit: png_path}``.

    All badges of one call share one fixed canvas (sized to the widest digit),
    so the countdown plane keeps a constant size while the digit changes.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    canvas_size = _measure_canvas(digits, DIGIT_FONT_SIZE)
    paths: dict[int, Path] = {}
    for digit in digits:
        path = out_dir / f"countdown_{digit}.png"
        render_countdown_badge(digit, canvas_size).save(path)
        paths[digit] = path
    return paths


def build_countdown_scene_xml(source_xml: Path, digits: list[int], tex_dir: Path, out_path: Path) -> None:
    """Copy ``source_xml`` with countdown texture/material declarations injected.

    All ``file="…"`` references are rewritten to absolute paths so the
    temporary XML can live outside ``assets/model`` (the original relative
    paths resolve against the XML location, which would otherwise break).
    """
    text = source_xml.read_text(encoding="utf-8")
    text = re.sub(
        r'file="([^"]+)"',
        lambda match: f'file="{(source_xml.parent / match.group(1)).resolve().as_posix()}"',
        text,
    )
    declarations: list[str] = []
    for digit in digits:
        png = (tex_dir / f"countdown_{digit}.png").resolve().as_posix()
        declarations.append(f'    <texture name="countdown_{digit}" type="2d" file="{png}"/>')
        declarations.append(f'    <material name="countdown_{digit}_mat" texture="countdown_{digit}" rgba="1 1 1 1"/>')
    injected = "\n".join(declarations)
    if "</asset>" not in text:
        raise ValueError(f"scene XML has no </asset> tag: {source_xml}")
    text = text.replace("</asset>", injected + "\n  </asset>")
    out_path.write_text(text, encoding="utf-8")
