"""PyInstaller 钩子：自动收集 bsi_robot_base 的 data 文件（assets）。

PyInstaller 构建时经 `pyinstaller40` entry point（见 `_pyinstaller_hooks.py`）
自动发现本目录并运行本钩子，把 assets 等非 Python 数据文件一并打进 exe。
宿主侧无需任何 --collect-data / --add-data / --additional-hooks-dir 配置。
"""

from PyInstaller.utils.hooks import collect_data_files, collect_dynamic_libs

# 收集本包及子包下所有非 Python 数据文件（assets 约 21MB：网格/纹理/模型/onnx/npz/license）。
datas = collect_data_files("bsi_robot_base")

# glfw 的 glfw3.dll / msvcr120.dll 由 ctypes 在运行时按路径加载，
# PyInstaller 静态分析看不到，需显式收为二进制；否则 mujoco.viewer 打包后静默失败。
# glfw 未安装时 collect_dynamic_libs 只返回空列表，不会报错。
binaries = collect_dynamic_libs("glfw")
