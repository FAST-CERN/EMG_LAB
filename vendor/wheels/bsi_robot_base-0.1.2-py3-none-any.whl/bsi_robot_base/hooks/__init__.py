"""PyInstaller 打包钩子所在目录（经 pyinstaller40 入口点自动发现）。"""
