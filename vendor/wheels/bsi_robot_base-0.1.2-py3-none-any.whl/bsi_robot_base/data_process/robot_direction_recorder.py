"""Asynchronous recording for virtual-robot labels and robot runtime events."""
from __future__ import annotations

import csv
import json
import queue
import threading
from pathlib import Path
from typing import Any

from bsi_robot_base.algorithm.topics import (
    ROBOT_DIRECTION_COMMAND_TOPIC,
    ROBOT_DIRECTION_HARDWARE_TOPIC,
    ROBOT_DIRECTION_PARADIGM_TOPIC,
)
from bsi_robot_base.algorithm.eeg.RobotDirectionDecodeSystem.contracts import (
    ROBOT_DIRECTION_SCHEMA_VERSION,
)
from bsi_robot_base.hardware.topics import EEG_DATA_TOPIC
from bsi_pykit_base.bus.bus_data import BusData
from bsi_pykit_base.bus.event_bus import EventBus


class RobotDirectionRecorder:
    """Writes labels only for virtual-robot sample/task sessions.

    EventBus callbacks only enqueue rows; all disk IO happens in the writer
    thread, so EEG/decoder callbacks remain non-blocking.
    """

    LABEL_HEADER = (
        "schema_version", "segment_id", "start_eeg_timestamp", "end_eeg_timestamp",
        "mode", "trial_index", "phase", "cue_class", "cue_name", "trainable", "label_source",
    )
    EVENT_HEADER = ("eeg_timestamp", "event", "mode", "phase", "details")

    def __init__(
        self,
        session_dir: str,
        *,
        mode: str,
        virtual_robot_enabled: bool,
        physical_robot_enabled: bool,
    ) -> None:
        self.session_dir = Path(session_dir)
        self.mode = mode
        self.virtual_robot_enabled = bool(virtual_robot_enabled)
        self.physical_robot_enabled = bool(physical_robot_enabled)
        self.labels_enabled = self.virtual_robot_enabled and mode in {"sample", "task"}
        self.event_bus = EventBus()
        self._latest_eeg_timestamp: float | None = None
        self._queue: queue.Queue[tuple[str, Any] | None] = queue.Queue()
        self._thread: threading.Thread | None = None
        self._running = False
        self._label_file = None
        self._runtime_file = None
        self._event_file = None
        self._label_writer = None
        self._event_writer = None
        self._class_duration = {index: 0.0 for index in range(4)}
        self._event_count = 0
        self._abnormal_events = 0

    def start(self) -> bool:
        if self._running:
            return True
        annotation_dir = self.session_dir / "Annotation"
        timestamp_dir = self.session_dir / "TimeStamps"
        annotation_dir.mkdir(parents=True, exist_ok=True)
        timestamp_dir.mkdir(parents=True, exist_ok=True)
        if self.labels_enabled:
            self._label_file = (annotation_dir / "robot_direction_labels.csv").open("w", newline="", encoding="utf-8")
            self._label_writer = csv.DictWriter(self._label_file, fieldnames=self.LABEL_HEADER)
            self._label_writer.writeheader()
        self._runtime_file = (annotation_dir / "robot_direction_runtime.jsonl").open("w", encoding="utf-8")
        self._event_file = (timestamp_dir / "robot_direction_events.csv").open("w", newline="", encoding="utf-8")
        self._event_writer = csv.DictWriter(self._event_file, fieldnames=self.EVENT_HEADER)
        self._event_writer.writeheader()
        self._running = True
        self._thread = threading.Thread(target=self._writer_loop, daemon=True, name="robot-direction-recorder")
        self._thread.start()
        self.event_bus.subscribe(EEG_DATA_TOPIC, self._on_eeg)
        self.event_bus.subscribe(ROBOT_DIRECTION_PARADIGM_TOPIC, self._on_paradigm)
        self.event_bus.subscribe(ROBOT_DIRECTION_COMMAND_TOPIC, self._on_command)
        self.event_bus.subscribe(ROBOT_DIRECTION_HARDWARE_TOPIC, self._on_hardware)
        return True

    def stop(self) -> bool:
        if not self._running:
            return True
        self.event_bus.unsubscribe(EEG_DATA_TOPIC, self._on_eeg)
        self.event_bus.unsubscribe(ROBOT_DIRECTION_PARADIGM_TOPIC, self._on_paradigm)
        self.event_bus.unsubscribe(ROBOT_DIRECTION_COMMAND_TOPIC, self._on_command)
        self.event_bus.unsubscribe(ROBOT_DIRECTION_HARDWARE_TOPIC, self._on_hardware)
        self._running = False
        self._queue.put(None)
        if self._thread is not None:
            self._thread.join(timeout=5)
        self._write_summary()
        for handle in (self._label_file, self._runtime_file, self._event_file):
            if handle is not None:
                handle.flush()
                handle.close()
        self._label_file = self._runtime_file = self._event_file = None
        return True

    def _on_eeg(self, data: BusData) -> None:
        payload = getattr(data, "data", {}) or {}
        if isinstance(payload, dict) and payload.get("timestamp") is not None:
            try:
                self._latest_eeg_timestamp = float(payload["timestamp"])
            except (TypeError, ValueError):
                pass

    def _on_paradigm(self, data: BusData) -> None:
        payload = dict(getattr(data, "data", {}) or {})
        # Segment producers deliberately do not send OS timestamps.  Anchor
        # the segment end to the latest received EEG timestamp and derive the
        # start from the planned duration, keeping labels in the EEG clock.
        end = self._latest_eeg_timestamp
        duration = payload.get("duration_seconds")
        try:
            duration = max(0.0, float(duration)) if duration is not None else 0.0
        except (TypeError, ValueError):
            duration = 0.0
        if end is not None:
            payload["end_eeg_timestamp"] = end
            payload["start_eeg_timestamp"] = end - duration
        else:
            # Do not create a trainable label until EEG time is available.
            payload["timestamp_error"] = "no_eeg_timestamp"
        payload.setdefault("mode", self.mode)
        self._queue.put(("paradigm", payload))

    def _on_command(self, data: BusData) -> None:
        payload = dict(getattr(data, "data", {}) or {})
        payload.setdefault("timestamp", self._latest_eeg_timestamp)
        payload.setdefault("eeg_timestamp", payload.get("timestamp"))
        payload.update({
            "mode": self.mode,
            "virtual_robot_enabled": self.virtual_robot_enabled,
            "physical_robot_enabled": self.physical_robot_enabled,
        })
        self._queue.put(("runtime", payload))

    def _on_hardware(self, data: BusData) -> None:
        payload = dict(getattr(data, "data", {}) or {})
        payload.update({
            "mode": self.mode,
            "virtual_robot_enabled": self.virtual_robot_enabled,
            "physical_robot_enabled": self.physical_robot_enabled,
        })
        self._queue.put(("runtime", payload))

    def _writer_loop(self) -> None:
        while self._running or not self._queue.empty():
            try:
                item = self._queue.get(timeout=0.1)
            except queue.Empty:
                continue
            if item is None:
                break
            kind, payload = item
            if kind == "runtime" and self._runtime_file is not None:
                self._event_count += 1
                self._runtime_file.write(json.dumps(payload, ensure_ascii=False) + "\n")
            elif kind == "paradigm":
                self._write_paradigm(payload)

    def _write_paradigm(self, payload: dict[str, Any]) -> None:
        timestamp = payload.get("end_eeg_timestamp") or payload.get("start_eeg_timestamp")
        if self._event_writer is not None:
            self._event_writer.writerow({
                "eeg_timestamp": timestamp,
                "event": payload.get("event", "segment"),
                "mode": payload.get("mode", self.mode),
                "phase": payload.get("phase", ""),
                "details": json.dumps(payload, ensure_ascii=False),
            })
        if not self.labels_enabled or self._label_writer is None:
            return
        if not payload.get("trainable", False) or payload.get("timestamp_error"):
            if payload.get("timestamp_error"):
                self._abnormal_events += 1
            return
        start = payload.get("start_eeg_timestamp")
        end = payload.get("end_eeg_timestamp")
        cue_class = payload.get("cue_class")
        try:
            duration = float(end) - float(start)
            if duration <= 0:
                raise ValueError
            self._class_duration[int(cue_class)] += duration
        except (TypeError, ValueError, KeyError, IndexError):
            self._abnormal_events += 1
            return
        self._label_writer.writerow({
            "schema_version": ROBOT_DIRECTION_SCHEMA_VERSION,
            "segment_id": payload.get("segment_id", ""),
            "start_eeg_timestamp": payload.get("start_eeg_timestamp"),
            "end_eeg_timestamp": payload.get("end_eeg_timestamp"),
            "mode": payload.get("mode", self.mode),
            "trial_index": payload.get("trial_index", -1),
            "phase": payload.get("phase", "active"),
            "cue_class": payload.get("cue_class"),
            "cue_name": payload.get("cue_name"),
            "trainable": 1,
            "label_source": "virtual_robot",
        })

    def _write_summary(self) -> None:
        """Persist session-level data quality metrics for training selection."""
        annotation_dir = self.session_dir / "Annotation"
        total_duration = sum(self._class_duration.values())
        summary = {
            "schema_version": ROBOT_DIRECTION_SCHEMA_VERSION,
            "mode": self.mode,
            "labels_enabled": self.labels_enabled,
            "valid_duration_seconds": {str(key): value for key, value in self._class_duration.items()},
            "estimated_valid_windows_at_50ms_step": int(total_duration / 0.05),
            "label_coverage": 1.0 if total_duration > 0 else 0.0,
            "runtime_event_count": self._event_count,
            "abnormal_event_count": self._abnormal_events,
        }
        (annotation_dir / "robot_direction_summary.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )
